# Rasa X Community Edition

Rasa X Community Edition is a freely available, closed source project.
