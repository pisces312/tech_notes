import logging
from typing import Tuple, Dict, Text, Any, List

import jwt
from sanic import Sanic
from sanic_cors import CORS
from sanic_jwt import Initialize, Responses
from sanic_jwt import exceptions

from rasax.community import config
from rasax.community.api.blueprints import (
    stack,
    nlg,
    nlu,
    models,
    intents,
    project,
    interface,
)
from rasax.community.constants import API_URL_PREFIX
from rasax.community.database.utils import setup_db
from rasax.community.services.role_service import normalise_permissions
from rasax.community.services.user_service import UserService, has_role, GUEST
from rasax.community.utils import default_arg, update_log_level

logger = logging.getLogger(__name__)


class ExtendedResponses(Responses):
    @staticmethod
    def extend_verify(request, user=None, payload=None):
        return {"username": jwt.decode(request.token, verify=False)["username"]}


async def authenticate(request, *args, **kwargs):
    """Set up JWT auth."""

    user_service = UserService(request["db_session"])
    rjs = request.json

    # enterprise SSO single-use-token login
    if rjs and rjs.get("single_use_token") is not None:
        user = user_service.single_use_token_login(
            rjs["single_use_token"], return_api_token=True
        )
        if user:
            return user
        else:
            raise exceptions.AuthenticationFailed("Wrong authentication token.")

    if not rjs:
        raise exceptions.AuthenticationFailed("Missing username or password.")

    # standard auth with username and password in request
    username = rjs.get("username", None)
    password = rjs.get("password", None)

    if username and password:
        return user_service.login(username, password, return_api_token=True)

    raise exceptions.AuthenticationFailed("Missing username or password.")


def remove_unused_payload_keys(user_dict: Dict[Text, Any]):
    """Removes unused keys from `user` dictionary in JWT payload.

    Removes keys `permissions`, `authentication_mechanism`, `projects` and  `team`."""

    for key in ["permissions", "authentication_mechanism", "projects", "team"]:
        del user_dict[key]


async def scope_extender(user: Dict[Text, Any], *args, **kwargs) -> List[Text]:
    permissions = user["permissions"]
    remove_unused_payload_keys(user)
    return normalise_permissions(permissions)


async def payload_extender(payload, user):
    payload.update({"user": user})
    return payload


async def retrieve_user(
    request, payload, allow_api_token, extract_user_from_jwt, *args, **kwargs
):
    if extract_user_from_jwt and payload and has_role(payload.get("user"), GUEST):
        return payload["user"]

    user_service = UserService(request["db_session"])

    if allow_api_token:
        api_token = default_arg(request, "api_token")
        if api_token:
            return user_service.api_token_auth(api_token)

    if payload:
        username = payload.get("username", None)
        if username is not None:
            return user_service.fetch_user(username)
        else:
            # user is first-time enterprise user and has username None
            # in this case we'll fetch the profile using name_id
            name_id = payload.get("user", {}).get("name_id", None)
            return user_service.fetch_user(name_id)

    return None


def initialize_app(app: Sanic, class_views: Tuple = ()) -> None:
    Initialize(
        app,
        authenticate=authenticate,
        add_scopes_to_payload=scope_extender,
        extend_payload=payload_extender,
        class_views=class_views,
        responses_class=ExtendedResponses,
        retrieve_user=retrieve_user,
        secret=config.jwt_secret,
        url_prefix="/api/auth",
        user_id="username",
    )


def configure_app() -> Sanic:
    # Start the Rasa Platform API Server
    update_log_level()

    # sanic-cors shows a DEBUG message for every request which we want to
    # suppress
    logging.getLogger("sanic_cors").setLevel(logging.INFO)
    logging.getLogger("spf.framework").setLevel(logging.INFO)

    app = Sanic(__name__, configure_logging=config.debug_mode)

    # allow CORS and OPTIONS on every endpoint
    app.config.CORS_AUTOMATIC_OPTIONS = True
    CORS(app, expose_headers=["X-Total-Count"])

    # set JWT expiration time (in s) to 8 h
    app.config.SANIC_JWT_EXPIRATION_DELTA = 60 * 60 * 8

    # Set up Blueprints
    app.blueprint(interface.blueprint())
    app.blueprint(project.blueprint(), url_prefix=API_URL_PREFIX)
    app.blueprint(stack.blueprint(), url_prefix=API_URL_PREFIX)
    app.blueprint(models.blueprint(), url_prefix=API_URL_PREFIX)
    app.blueprint(nlg.blueprint(), url_prefix=API_URL_PREFIX)
    app.blueprint(nlu.blueprint(), url_prefix=API_URL_PREFIX)
    app.blueprint(intents.blueprint(), url_prefix=API_URL_PREFIX)

    app.register_listener(setup_db, "before_server_start")

    return app
