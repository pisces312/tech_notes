import logging
import os

from aiohttp import ClientError
from sanic import Blueprint, response
from sanic.request import Request

from rasa.cli.utils import create_output_path
from rasax.community import utils, config
from rasax.community.api.decorators import rasa_x_scoped
from rasax.community.services.model_service import ModelService
from rasax.community.services.settings_service import SettingsService
from rasax.community.utils import error, write_bytes_to_file

logger = logging.getLogger(__name__)


def _model_service(request: Request) -> ModelService:
    session = request["db_session"]
    return ModelService(config.rasa_model_dir, session, "production")


def blueprint() -> Blueprint:
    endpoints = Blueprint("model_endpoints")

    @endpoints.route("/projects/<project_id>/models", methods=["GET", "HEAD"])
    @rasa_x_scoped("models.list", allow_api_token=True, allow_rasa_x_token=True)
    async def get_models(request, project_id):
        limit = utils.int_arg(request, "limit", None)
        offset = utils.int_arg(request, "offset", None)

        models, total_models = await _model_service(request).get_models(
            project_id, limit, offset
        )

        return response.json(models, headers={"X-Total-Count": total_models})

    @endpoints.route("/projects/<project_id>/models", methods=["POST"])
    @rasa_x_scoped("models.create", allow_api_token=True, allow_rasa_x_token=True)
    async def upload_model(request, project_id):
        model_service = _model_service(request)
        try:
            tpath = model_service.save_model_to_disk(request)
        except (FileNotFoundError, ValueError) as e:
            return error(404, "ModelSaveError", "Could not save model.\n{}".format(e))

        minimum_version = await model_service.minimum_compatible_version()

        if not model_service.is_model_compatible(minimum_version, fpath=tpath):
            return error(404, "ModelVersionError", "Model version unsupported.")

        try:
            filename = os.path.basename(tpath)
            model_name = filename.split(".tar.gz")[0]
            saved = await model_service.save(project_id, model_name, tpath)
            if saved:
                return response.text("", 204)
            return error(
                404,
                "ModelSaveError",
                "Model could not be saved.\nModel name '{}'."
                "File path '{}'.".format(model_name, tpath),
            )
        except FileExistsError:
            return error(
                404, "ModelExistsError", "A model with that name already exists."
            )

    @endpoints.route(
        "/projects/<project_id>/models/tags/<tag>", methods=["GET", "HEAD"]
    )
    @rasa_x_scoped(
        "models.modelByTag.get", allow_api_token=True, allow_rasa_x_token=True
    )
    async def get_model_for_tag(request, project_id, tag):
        model = _model_service(request).model_for_tag(project_id, tag)
        if not model:
            return error(
                404,
                "TagNotFound",
                "Tag '{}' not found for project '{}'.".format(tag, project_id),
            )
        model_hash = model["hash"]
        try:
            if model_hash == request.headers.get("If-None-Match"):
                return response.text("", 204)

            return await response.file_stream(
                location=model["path"],
                headers={
                    "ETag": model_hash,
                    "filename": os.path.basename(model["path"]),
                },
                mime_type="application/gzip",
            )
        except FileNotFoundError:
            logger.warning(
                "Tried to download model file '{}', "
                "but file does not exist.".format(model["path"])
            )
            return error(
                404,
                "ModelDownloadFailed",
                "Failed to find model file '{}'.".format(model["path"]),
            )

        except Exception as e:
            logger.exception(e)
            return error(
                500, "ModelDownloadError", "Failed to download file.\n{}".format(e)
            )

    @endpoints.route("/projects/<project_id>/models/<model>", methods=["GET", "HEAD"])
    @rasa_x_scoped("models.get", allow_api_token=True, allow_rasa_x_token=True)
    async def get_model_by_name(request, project_id, model):
        model = _model_service(request).get_model_by_name(project_id, model)
        if not model:
            return error(
                404,
                "ModelNotFound",
                "Model '{}' not found for project '{}'.".format(model, project_id),
            )
        model_hash = model["hash"]
        try:
            if model_hash == request.headers.get("If-None-Match"):
                return response.text("", 204)

            return await response.file_stream(
                location=model["path"],
                headers={
                    "ETag": model_hash,
                    "filename": os.path.basename(model["path"]),
                },
                mime_type="application/gzip",
            )
        except Exception as e:
            logger.exception(e)
            return error(
                404, "ModelDownloadFailed", "Failed to download file.\n{}".format(e)
            )

    # noinspection PyUnusedLocal
    @endpoints.route("/projects/<project_id>/models/<model>", methods=["DELETE"])
    @rasa_x_scoped("models.delete", allow_api_token=True)
    async def delete_model(request, project_id, model):
        deleted = _model_service(request).delete_model(project_id, model)
        if deleted:
            return response.text("", 204)
        else:
            return error(
                404, "ModelDeleteFailed", "Failed to delete model '{}'.".format(model)
            )

    @endpoints.route("/projects/<project_id>/models/jobs", methods=["POST"])
    @rasa_x_scoped("models.jobs.create")
    async def train_model(request, project_id):
        stack_services = SettingsService(request["db_session"]).stack_services(
            project_id
        )
        environment = utils.deployment_environment_from_request(request, "worker")
        stack_service = stack_services[environment]

        try:
            content = await stack_service.start_training_process()
            # save new model in model service
            model_path = create_output_path(config.rasa_model_dir)
            write_bytes_to_file(model_path, content)

            model_name = os.path.basename(model_path).split(".tar.gz")[0]
            await _model_service(request).save(project_id, model_name, model_path)

            return response.json({"info": "new model trained", "model": model_name})
        except ClientError as e:
            return error(
                500, "StackTrainingFailed", "Failed to train a Rasa model.", details=e
            )

    # noinspection PyUnusedLocal
    @endpoints.route(
        "/projects/<project_id>/models/<model>/tags/<tag>", methods=["PUT"]
    )
    @rasa_x_scoped("models.tags.update", allow_api_token=True)
    async def tag_model(request, project_id, model, tag):
        tagged_model = _model_service(request).tag_model(project_id, model, tag)
        if tagged_model:
            return response.text("", 204)
        return error(
            404,
            "ModelTagError",
            "Failed to tag model '{}'. Model not found.".format(model),
        )

    # noinspection PyUnusedLocal
    @endpoints.route(
        "/projects/<project_id>/models/<model>/tags/<tag>", methods=["DELETE"]
    )
    @rasa_x_scoped("models.tags.delete", allow_api_token=True)
    async def untag(request, project_id, model, tag):
        try:
            _model_service(request).delete_tag(project_id, model, tag)
            return response.text("", 204)
        except ValueError as e:
            return error(
                404, "TagDeletionFailed", "Failed to delete model tag", details=e
            )

    return endpoints
