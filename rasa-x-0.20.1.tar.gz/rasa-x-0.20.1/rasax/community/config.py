import json
import os
import uuid

LOCAL_MODE = os.environ.get("LOCAL_MODE", "true").lower() == "true"
SYSTEM_USER = "system_user"

# Platform-wide variables
rasa_x_password = os.environ.get("RASA_X_PASSWORD")
rasa_x_hostname = os.environ.get("RASA_X_HOSTNAME")
rasa_x_token = os.environ.get("RASA_X_TOKEN") or uuid.uuid4().hex
password_salt = os.environ.get("PASSWORD_SALT", "salt")
project_name = os.environ.get("PROJECT_ID", "default")
self_port = int(os.environ.get("SELF_PORT", "5002"))
jwt_secret = os.environ.get("JWT_SECRET") or uuid.uuid4().hex
debug_mode = os.environ.get("DEBUG_MODE", "false") == "true"
log_level = "DEBUG" if debug_mode else os.environ.get("LOG_LEVEL", "INFO")
team_name = os.environ.get("TEAM_ID", "rasa")
saml_path = os.environ.get("SAML_PATH", "/app/auth/saml")
saml_default_role = os.environ.get("SAML_DEFAULT_ROLE", "tester")
event_logfile = os.environ.get("EVENT_LOGFILE", "rasa_event.log")
rasa_model_dir = os.environ.get("RASA_MODEL_DIR", "/app/models")
data_dir = os.environ.get("DATA_DIR", "data")
default_environments_config_path = os.environ.get(
    "DEFAULT_ENVIRONMENT_CONFIG_PATH", "environments.yml"
)
default_nlu_filename = os.environ.get("DEFAULT_NLU_FILENAME", "nlu.md")
default_stories_filename = os.environ.get("DEFAULT_STORIES_FILENAME", "stories.md")
default_domain_path = os.environ.get("DEFAULT_DOMAIN_PATH", "domain.yml")
default_config_path = os.environ.get("DEFAULT_CONFIG_PATH", "config.yml")
default_username = os.environ.get("DEFAULT_USERNAME", "me")
development_mode = os.environ.get("DEVELOPMENT_MODE", "false").lower() == "true"

# user metrics collection
metrics_collection_config = {}

# by default data based on platform users will be excluded from the analytics
# set to "1" if you wish to include them
rasa_x_user_analytics = bool(int(os.environ.get("RASA_X_USER_ANALYTICS", "0")))

# the number of bins in the analytics results if `window` is not specified
# in the query
default_analytics_bins = int(os.environ.get("DEFAULT_ANALYTICS_BINS", "10"))

# APscheduler config defining the update behaviour of the analytics cache. See
# https://apscheduler.readthedocs.io/en/latest/modules/triggers/cron.html
# the default value of {"hour": "*"} will run the caching once per hour
analytics_update_kwargs = json.loads(
    os.environ.get("ANALYTICS_UPDATE_KWARGS", '{"hour": "*"}')
)

# Stack variables
rasa_token = os.environ.get("RASA_TOKEN", "")
rasa_worker_token = os.environ.get("RASA_WORKER_TOKEN", "")
rasa_worker_host = os.environ.get("RASA_WORKER_HOST", "")

# RabbitMQ variables
rabbitmq_username = os.environ.get("RABBITMQ_USERNAME", "user")
rabbitmq_password = os.environ.get("RABBITMQ_PASSWORD", "bitnami")
rabbitmq_host = os.environ.get("RABBITMQ_HOST", "localhost")
rabbitmq_queue = os.environ.get("RABBITMQ_QUEUE", "rasa_production_events")

# Features
DEFAULT_FEATURE_FLAGS = []
