# URL to Rasa license agreement
RASA_TERMS_URL = (
    "https://storage.cloud.google.com/rasa-x-releases/"
    "rasa_x_ce_license_agreement.pdf"
)

# Key in global config file which contains whether the user agreed to the Rasa license
CONFIG_FILE_TERMS_KEY = "terms_accepted"

# Key in global config file which contains whether the user agreed to tracking
CONFIG_FILE_METRICS_KEY = "metrics"
CONFIG_METRICS_USER = "rasa_user_id"
CONFIG_METRICS_ENABLED = "enabled"
CONFIG_METRICS_DATE = "date"

# mixpanel configuration
MIXPANEL_TOKEN = "ac0addcfa6036776440c464d80e94868"

API_URL_PREFIX = "/api"

COMMUNITY_PROJECT_NAME = "default"
COMMUNITY_TEAM_NAME = "rasa"
COMMUNITY_USERNAME = "me"

DEFAULT_CHANNEL_NAME = "rasa"
SHARE_YOUR_BOT_CHANNEL_NAME = "Tester"

JWT_METHOD = "HS256"
