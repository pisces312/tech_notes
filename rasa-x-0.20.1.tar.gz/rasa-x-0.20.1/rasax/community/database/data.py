import json
from typing import Dict, Text, Any

from sqlalchemy import Integer, Column, String, Float, ForeignKey, Boolean
from sqlalchemy.orm import relationship

from rasax.community.database.base import Base

# keys that are used for template annotations
# these keys are removed from the template dictionary when dumped as part of a
# domain file
TEMPLATE_ANNOTATION_KEYS = {
    "template",
    "project_id",
    "annotator_id",
    "id",
    "annotated_at",
}


class Template(Base):
    """Stores the response templates."""

    __tablename__ = "template"

    id = Column(Integer, primary_key=True)
    template = Column(String, nullable=False)
    text = Column(String)
    content = Column(String)
    annotator_id = Column(String, ForeignKey("rasa_x_user.username"))
    annotated_at = Column(Float)  # annotation time as unix timestamp
    project_id = Column(String, ForeignKey("project.project_id"))

    domain = relationship("Domain", back_populates="templates")
    domain_id = Column(Integer, ForeignKey("domain.id"))

    def as_dict(self) -> Dict[Text, Any]:
        result = json.loads(self.content)
        result["template"] = self.template
        result["id"] = self.id
        result["annotator_id"] = self.annotator_id
        result["annotated_at"] = self.annotated_at
        result["project_id"] = self.project_id

        return result


class Story(Base):
    """Stores Rasa Core training stories."""

    __tablename__ = "story"

    id = Column(Integer, primary_key=True)
    name = Column(String)
    story = Column(String)
    user = Column(String, ForeignKey("rasa_x_user.username"))
    annotated_at = Column(Float)  # annotation time as unix timestamp
    filename = Column(String)

    def as_dict(self) -> Dict[Text, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "story": self.story,
            "annotation": {"user": self.user, "time": self.annotated_at},
            "filename": self.filename,
        }


class TrainingData(Base):
    """Stores the annotated NLU training data."""

    __tablename__ = "nlu_training_data"

    id = Column(Integer, primary_key=True)
    hash = Column(String, index=True)
    text = Column(String)
    intent = Column(String)
    annotator_id = Column(String, ForeignKey("rasa_x_user.username"))
    project_id = Column(String, ForeignKey("project.project_id"))
    annotated_at = Column(Float)  # annotation time as unix timestamp
    filename = Column(String)
    entities = relationship(
        "TrainingDataEntity", cascade="all, delete-orphan", back_populates="example"
    )

    def as_dict(self) -> Dict[Text, Any]:
        return {
            "id": self.id,
            "text": self.text,
            "intent": self.intent,
            "entities": [e.as_dict() for e in self.entities],
            "hash": self.hash,
            "annotation": {"user": self.annotator_id, "time": self.annotated_at},
        }


class TrainingDataEntity(Base):
    """Stores annotated entities of the NLU training data."""

    __tablename__ = "nlu_training_data_entity"

    id = Column(Integer, primary_key=True)
    example_id = Column(Integer, ForeignKey("nlu_training_data.id"))
    example = relationship("TrainingData", back_populates="entities")
    entity = Column(String)
    value = Column(String)
    start = Column(Integer)
    end = Column(Integer)
    extractor = Column(String)

    def as_dict(self) -> Dict[Text, Text]:
        entity_dict = {
            "start": self.start,
            "end": self.end,
            "entity": self.entity,
            "value": self.value,
        }

        if self.extractor:
            entity_dict["extractor"] = self.extractor

        return entity_dict


class RegexFeature(Base):
    """Stores annotated regex features of the NLU training data."""

    __tablename__ = "regex_feature"

    id = Column(Integer, primary_key=True)
    project_id = Column(String, ForeignKey("project.project_id"))
    name = Column(String)
    pattern = Column(String)
    filename = Column(String)

    def as_dict(self) -> Dict[Text, Text]:
        return {"name": self.name, "pattern": self.pattern}


class LookupTable(Base):
    """Stores annotated lookup tables of the NLU training data."""

    __tablename__ = "lookup_table"

    id = Column(Integer, primary_key=True)
    project_id = Column(String, ForeignKey("project.project_id"))
    name = Column(String)
    elements = Column(String)
    filename = Column(String)

    def as_dict(self) -> Dict[Text, Text]:
        return {"name": self.name, "elements": json.loads(self.elements)}


class EntitySynonym(Base):
    """Stores annotated entity synonyms of the NLU training data."""

    __tablename__ = "entity_synonym"

    name = Column(String, primary_key=True)
    synonym = Column(String, primary_key=True)
    project_id = Column(String, ForeignKey("project.project_id"), primary_key=True)
    filename = Column(String)
