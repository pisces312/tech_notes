import json
from collections import defaultdict
from typing import Any, Text, Dict, Union

from sqlalchemy import Column, Integer, String, ForeignKey, Boolean
from sqlalchemy.orm import relationship

from rasax.community.database.base import Base
from rasax.community.database.data import TEMPLATE_ANNOTATION_KEYS


class Domain(Base):
    """Stores the domain of the currently deployed Core model."""

    __tablename__ = "domain"

    id = Column(Integer, primary_key=True)
    project_id = Column(String, ForeignKey("project.project_id"))
    store_entities_as_slots = Column(Boolean, default=True)
    path = Column(String, nullable=True)

    actions = relationship(
        "DomainAction", cascade="all, delete-orphan", back_populates="domain"
    )
    intents = relationship(
        "DomainIntent", cascade="all, delete-orphan", back_populates="domain"
    )
    entities = relationship(
        "DomainEntity", cascade="all, delete-orphan", back_populates="domain"
    )
    slots = relationship(
        "DomainSlot", cascade="all, delete-orphan", back_populates="domain"
    )
    templates = relationship(
        "Template", cascade="all, delete-orphan", back_populates="domain"
    )

    def remove_annotations(self, template_dict):
        """Removes keys from templates that are irrelevant for the dumped
        domain."""

        for key in TEMPLATE_ANNOTATION_KEYS:
            if key in template_dict:
                del template_dict[key]

        return template_dict

    def dump_templates(self):
        template_list = [
            {t.template: self.remove_annotations(json.loads(t.content))}
            for t in self.templates
        ]

        template_dict = defaultdict(list)
        for template in template_list:
            for k, v in template.items():
                template_dict[k].append(v)

        return dict(template_dict)

    def as_dict(self) -> Dict[Text, Any]:
        slots = {}
        for s in self.slots:
            name = s.slot
            slots[name] = {"auto_fill": s.auto_fill, "type": s.type}

            if s.initial_value:
                slots[name]["initial_value"] = json.loads(s.initial_value)

            if "categorical" in s.type.lower() and s.values:
                slots[name]["values"] = json.loads(s.values)

        domain_dict = {
            "config": {"store_entities_as_slots": self.store_entities_as_slots},
            "actions": [e.action for e in self.actions if not e.is_form],
            "forms": [e.action for e in self.actions if e.is_form],
            "entities": [e.entity for e in self.entities],
            "intents": [i.as_dict() for i in self.intents],
            "slots": slots,
            "templates": self.dump_templates(),
        }

        if self.path:
            domain_dict["path"] = self.path

        return domain_dict

    def is_empty(self):
        return not any(
            [self.actions, self.templates, self.entities, self.intents, self.slots]
        )


class DomainAction(Base):
    """Stores the actions which are defined in the domain."""

    __tablename__ = "domain_action"

    action_id = Column(Integer, primary_key=True)
    domain_id = Column(Integer, ForeignKey("domain.id"))
    action = Column(String)
    is_form = Column(Boolean, default=False)

    domain = relationship("Domain", back_populates="actions")

    def as_dict(self) -> Dict[Text, Union[Text, bool]]:
        return {
            "id": self.action_id,
            "domain_id": self.domain_id,
            "name": self.action,
            "is_form": self.is_form,
        }


class DomainIntent(Base):
    """Stores the intents which are defined in the domain."""

    __tablename__ = "domain_intent"

    intent_id = Column(Integer, primary_key=True)
    domain_id = Column(Integer, ForeignKey("domain.id"))
    intent = Column(String)
    triggered_action = Column(String)
    use_entities = Column(String)
    ignore_entities = Column(String)

    domain = relationship("Domain", back_populates="intents")

    def as_dict(self) -> Dict[Text, Any]:
        config = {
            "use_entities": json.loads(self.use_entities or "true"),
            "ignore_entities": json.loads(self.ignore_entities or str([])),
        }

        if self.triggered_action:
            config["triggers"] = self.triggered_action

        return {self.intent: config}


class DomainEntity(Base):
    """Stores the entities which are defined in the domain."""

    __tablename__ = "domain_entity"

    entity_id = Column(Integer, primary_key=True)
    domain_id = Column(Integer, ForeignKey("domain.id"))
    entity = Column(String)

    domain = relationship("Domain", back_populates="entities")


class DomainSlot(Base):
    """Stores the slots which are defined in the domain."""

    __tablename__ = "domain_slot"

    slot_id = Column(Integer, primary_key=True)
    domain_id = Column(Integer, ForeignKey("domain.id"))
    slot = Column(String)
    auto_fill = Column(Boolean, default=True)
    initial_value = Column(String)
    type = Column(String, default="rasa.core.slots.UnfeaturizedSlot")
    values = Column(String)

    domain = relationship("Domain", back_populates="slots")
