from typing import Any, Text, Dict, Union

from sqlalchemy import Column, String, ForeignKey, Integer, Float
from sqlalchemy.orm import relationship

from rasax.community.database.base import Base


class Model(Base):
    """Stores metadata about trained models."""

    __tablename__ = "model"

    id = Column(Integer, primary_key=True)
    hash = Column(String, nullable=False)
    name = Column(String, nullable=False, unique=True)
    path = Column(String, nullable=False, unique=True)
    project_id = Column(String, ForeignKey("project.project_id"))
    project = relationship("Project", back_populates="models")
    version = Column(String)
    # time when the training was performed as unix timestamp
    trained_at = Column(Float)
    tags = relationship(
        "ModelTag", cascade="all, delete-orphan", back_populates="model"
    )
    nlu_evaluations = relationship(
        "NluEvaluation", back_populates="model", cascade="all, delete-orphan"
    )
    # no `cascade="delete"` so that the message logs don't get removed when the models
    # gets removed
    message_logs = relationship("MessageLog", back_populates="model")

    def as_dict(self) -> Dict[Text, Any]:
        return {
            "hash": self.hash,
            "model": self.name,
            "path": self.path,
            "project": self.project_id,
            "trained_at": self.trained_at,
            "version": self.version,
            "tags": [t.tag for t in self.tags],
        }


class ModelTag(Base):
    """Stores tags which have been assigned to certain models."""

    __tablename__ = "model_tag"

    model_id = Column(Integer, ForeignKey("model.id"), primary_key=True)
    tag = Column(String, primary_key=True)
    model = relationship("Model", back_populates="tags")


class NluEvaluation(Base):
    """Stores the results of NLU evaluations."""

    __tablename__ = "nlu_evaluation"

    id = Column(Integer, primary_key=True)
    model_id = Column(String, ForeignKey("model.name"))
    model = relationship("Model", back_populates="nlu_evaluations")
    report = Column(String)
    precision = Column(Float)
    f1 = Column(Float)
    accuracy = Column(Float)
    timestamp = Column(Float)  # time of the evaluation as unix timestamp
    predictions = relationship(
        "NluEvaluationPrediction", cascade="all", back_populates="evaluation"
    )

    def as_dict(self) -> Dict[Text, Dict[Text, Any]]:
        return {
            "intent_evaluation": {
                "report": self.report,
                "f1_score": self.f1,
                "accuracy": self.accuracy,
                "precision": self.precision,
                "predictions": [p.as_dict() for p in self.predictions],
                "timestamp": self.timestamp,
            },
            "model": self.model_id,
        }


class NluEvaluationPrediction(Base):
    """Stores the predictions which were done as part of the NLU evaluation."""

    __tablename__ = "nlu_evaluation_prediction"

    id = Column(Integer, primary_key=True)
    evaluation_id = Column(Integer, ForeignKey("nlu_evaluation.id"))
    evaluation = relationship("NluEvaluation", back_populates="predictions")
    text = Column(String)
    intent = Column(String)
    predicted = Column(String)
    confidence = Column(Float)

    def as_dict(self) -> Dict[Text, Union[Text, Float]]:
        return {
            "text": self.text,
            "intent": self.intent,
            "predicted": self.predicted,
            "confidence": self.confidence,
        }
