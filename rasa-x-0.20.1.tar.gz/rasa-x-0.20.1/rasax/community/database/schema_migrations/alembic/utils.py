from typing import Text

import sqlalchemy
from alembic import op
from sqlalchemy import engine_from_config, Column
from sqlalchemy.engine import reflection


def table_has_column(table: Text, column: Text) -> bool:
    """Checks whether a table with a given column exists."""

    alembic_config = op.get_context().config
    engine = engine_from_config(
        alembic_config.get_section(alembic_config.config_ini_section),
        prefix="sqlalchemy.",
    )
    insp = reflection.Inspector.from_engine(engine)
    has_column = False
    try:
        for col in insp.get_columns(table):
            if column not in col["name"]:
                continue
            has_column = True
    except sqlalchemy.exc.NoSuchTableError:
        return False
    return has_column


def create_column(table: Text, column: Column) -> None:
    """Adds `column` to `table`."""

    with op.batch_alter_table(table) as batch_op:
        batch_op.add_column(column)


def drop_column(table: Text, column: Text) -> None:
    """Drops `column` from `table`."""

    with op.batch_alter_table(table) as batch_op:
        batch_op.drop_column(column)
