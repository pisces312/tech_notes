"""Support for individually unfeaturized entities in domain.

Reason:
https://github.com/RasaHQ/rasa/pull/3655 adds the option to featurize entities
individually for each intent. This led to changes in the format of the intent
configuration which have to be reflected in the database.

Revision ID: 1dfbf67d6ae2
Revises: 59b7be3ad5fc

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "1dfbf67d6ae2"
down_revision = "59b7be3ad5fc"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("domain_intent") as batch_op:
        batch_op.add_column(sa.Column("ignore_entities", sa.String, nullable=True))
        batch_op.alter_column("use_entities", type_=sa.String, existing_type=sa.Boolean)


def downgrade():
    with op.batch_alter_table("domain_intent") as batch_op:
        batch_op.drop_column("ignore_entities")
        batch_op.alter_column("use_entities", type_=sa.Boolean, existing_type=sa.String)
