"""Add a column for `triggers` to the domain intents.

Reason:
When using the `MappingPolicy` users can define triggers for each intent which are
used to trigger certain actions. Rasa X has to store this information.

Revision ID: ffddc4250349
Revises: 45546b047abe

"""
import sqlalchemy as sa
import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "ffddc4250349"
down_revision = "45546b047abe"
branch_labels = None
depends_on = None


def upgrade():
    migration_utils.create_column(
        "domain_intent", sa.Column("triggered_action", sa.String, nullable=True)
    )


def downgrade():
    migration_utils.drop_column("domain_intent", "triggered_action")
