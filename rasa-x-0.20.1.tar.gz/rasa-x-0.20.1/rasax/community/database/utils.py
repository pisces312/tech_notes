import logging
import os
from contextlib import contextmanager
from typing import Union, Text, Any, List

import sqlalchemy
from rasax.community import config
from sanic import Sanic
from sanic.request import Request
from sqlalchemy import create_engine
from sqlalchemy import event
from sqlalchemy.engine import Engine
from sqlalchemy.engine.url import URL
from sqlalchemy.orm import Session
from sqlalchemy.orm import sessionmaker
from time import sleep

from rasax.community.services.user_service import ADMIN

logger = logging.getLogger(__name__)


def setup_db(app: Sanic, _, is_local=config.LOCAL_MODE) -> None:
    """Creates and initializes database."""

    url = get_db_url(is_local)
    app.session_maker = create_session_maker(url)
    configure_session_attachment(app)


def configure_session_attachment(app: Sanic) -> None:
    """Connects the database management to the sanic lifecyle."""
    app.register_middleware(set_session, "request")
    app.register_middleware(remove_session, "response")


def get_db_url(is_local: bool = config.LOCAL_MODE) -> Union[Text, URL]:
    """Return the database connection url from the environment variables."""

    if is_local and os.environ.get("DB_DRIVER") is None:
        return "sqlite:///rasa.db"

    return URL(
        drivername=os.environ.get("DB_DRIVER", "postgresql"),
        username=os.environ.get("DB_USER", ADMIN),
        password=os.environ.get("DB_PASSWORD", "password"),
        host=os.environ.get("DB_HOST", "db"),
        port=os.environ.get("DB_PORT", 5432),
        database=os.environ.get("DB_DATABASE", "rasa"),
    )


@event.listens_for(Engine, "connect")
def _set_sqlite_pragma(dbapi_connection, _):
    """Enforces the foreign key constraint on sqlite databases."""
    enforce_sqlite_foreign_key_constraints(dbapi_connection, True)


def enforce_sqlite_foreign_key_constraints(
    connection: Any, enforce_foreign_keys: bool = True
) -> None:
    """Turns on / off the enforcement of foreign key constraints for SQLite."""

    from sqlite3 import Connection as SQLite3Connection

    if isinstance(connection, SQLite3Connection):
        enforce_setting = "ON" if enforce_foreign_keys else "OFF"
        cursor = connection.cursor()
        cursor.execute("PRAGMA foreign_keys={};".format(enforce_setting))
        cursor.close()
        logger.debug(
            "Turned SQLite foreign key enforcement {}.".format(enforce_setting.lower())
        )


def create_session_maker(url: Union[Text, URL]) -> sessionmaker:
    """Create a new sessionmaker factory.

    A sessionmaker factory generates new Sessions when called.
    """

    # Database might take a while to come up
    while True:
        try:
            engine = create_engine(url)
            return sessionmaker(bind=engine)
        except sqlalchemy.exc.OperationalError as e:
            logger.warning(e)
            sleep(5)


@contextmanager
def session_scope():
    """Provide a transactional scope around a series of operations."""

    url = get_db_url(config.LOCAL_MODE)
    session = create_session_maker(url)()

    try:
        yield session
        session.commit()
    except Exception as _:
        session.rollback()
        raise
    finally:
        session.close()


def get_database_session(is_local: bool = False) -> Session:
    db_url = get_db_url(is_local)
    session_maker = create_session_maker(db_url)
    return session_maker()


async def set_session(request: Request) -> None:
    """Create a new session for the request."""
    request["db_session"] = request.app.session_maker()


async def remove_session(request: Request, _) -> None:
    """Closes the database session after the request."""
    db_session = request.get("db_session")
    if db_session:
        db_session.commit()
        db_session.close()
