import logging
import os
import typing
import webbrowser
from typing import Text, Tuple, Generator, Dict, List, Set, Any, Optional

from sanic import Sanic
from sqlalchemy.orm import Session

from rasa.cli.utils import print_success
from rasa.core.domain import InvalidDomain
from rasa.nlu.training_data import TrainingData
from rasa.utils.io import read_yaml_file, read_file
from rasax.community import config
from rasax.community.services.role_service import RoleService
from rasax.community.services.user_service import UserService
from rasax.community.utils import (
    random_password,
    run_operation_in_single_sanic_worker,
    print_error_and_exit,
)

if typing.TYPE_CHECKING:
    from rasax.community.services.settings_service import SettingsService

logger = logging.getLogger(__name__)


def inject_config(
    config_path: Text, settings_service: "SettingsService"
) -> Optional[Dict[Text, Any]]:
    """Load a configuration file from `path` and save it to the database.

    Quits the application if config cannot be loaded.
    """

    if not os.path.exists(config_path):
        print_error_and_exit(
            "Failed to inject Rasa configuration. The file '{}' "
            "does not exist."
            "".format(os.path.abspath(config_path))
        )

    yaml_config = read_yaml_file(config_path)
    if not yaml_config:
        print_error_and_exit(
            "Failed to inject Rasa configuration:\n"
            "Reading of yaml '{}' file failed. Most likely the "
            "file was not found or uses the wrong syntax."
            "".format(os.path.abspath(config_path))
        )

    _config = settings_service.save_config(
        config.team_name, "default", yaml_config, config_path
    )
    if not _config:
        print_error_and_exit(
            "Failed to inject Rasa configuration. The file '{}'"
            "was found but could not be saved to the database."
            "".format(os.path.abspath(config_path))
        )

    logger.debug(
        "Loaded local configuration from '{}' into "
        "database".format(os.path.abspath(config_path))
    )
    return _config


def _read_data(paths: List[Text]) -> Generator[Tuple[Text, Text], None, None]:
    for filename in paths:
        yield read_file(filename), filename


def inject_nlu_data(
    nlu_files: Set[Text], project_id: Text, username: Text, data_service: "DataService"
) -> TrainingData:
    """Load Rasa NLU training data from `path` and save it to the database."""

    # delete existing data in db if files are provided
    if nlu_files:
        data_service.delete_data()

    training_data = data_service.save_bulk_data_from_files(
        nlu_files, project_id, username
    )

    logger.debug(
        "Injected {} NLU training data examples."
        "".format(len(training_data.training_examples))
    )

    return training_data


async def inject_stories(
    story_files: Set[Text],
    story_service: "StoryService",
    username: Text,
    team: Text = config.team_name,
) -> List[Dict[Text, Any]]:
    """Load Core stories from `data_directory` and save to the database."""

    story_blocks = []

    if story_files:
        # delete existing data in db if files are provided
        await story_service.delete_stories(team)
        # store provided stories in db
        story_blocks = await story_service.save_stories_from_files(
            story_files, team, username
        )

    logger.debug("Injected {} Core stories.".format(len(story_blocks)))
    return story_blocks


def inject_domain(
    domain_path: Text,
    domain_service: "DomainService",
    project_id: Text = config.project_name,
    username: Text = config.default_username,
) -> Dict[Text, Any]:
    """Load Rasa Core domain at `path` and save it to database.

    Quits the application if domain cannot be loaded.
    """

    if not os.path.exists(domain_path):
        print_error_and_exit(
            "domain.yml could not be found at '{}'. Rasa X requires a "
            "domain in the project root directory."
            "".format(os.path.abspath(domain_path))
        )

    try:
        domain_service.validate_and_store_domain_yaml(
            domain_yaml=read_file(domain_path),
            project_id=project_id,
            path=domain_path,
            store_templates=True,
            username=username,
        )
    except InvalidDomain as e:
        print_error_and_exit("Could not inject domain. Details:\n{}".format(e))

    return domain_service.get_domain(project_id)


def create_project_and_settings(
    _settings_service: "SettingsService", _role_service: "RoleService", team: Text
) -> None:
    """Create project and settings."""

    project_id = config.project_name

    existing = _settings_service.get(team, project_id)

    if existing is None:
        _settings_service.init_project(team, project_id)

    _role_service.init_roles(project_id=project_id)


def create_community_user(session: Session, app: Sanic) -> None:
    from rasax.community.constants import COMMUNITY_USERNAME
    from rasax.community.constants import COMMUNITY_TEAM_NAME
    from rasax.community.constants import COMMUNITY_PROJECT_NAME
    from rasax.community.services.settings_service import SettingsService

    role_service = RoleService(session)
    role_service.init_roles(project_id=COMMUNITY_PROJECT_NAME)

    settings_service = SettingsService(session)

    password = settings_service.get_local_password()

    # only re-assign password in local mode or if it doesn't exist
    if config.LOCAL_MODE or not password:
        password = _initialize_local_password(settings_service)

    user_service = UserService(session)
    user_service.insert_or_update_user(
        COMMUNITY_USERNAME, password, COMMUNITY_TEAM_NAME
    )

    run_operation_in_single_sanic_worker(app, _startup_info)


def _initialize_local_password(settings_service: "SettingsService") -> Text:
    """Update Rasa X password.

    Check if `RASA_X_PASSWORD` environment variable is set, and use it as password.
    Generate new password if it is not set.
    """

    password = os.environ.get("RASA_X_PASSWORD", random_password())

    # update password in config
    config.rasa_x_password = password

    # commit password to db
    settings_service.save_local_password(password)

    return password


def _startup_info() -> None:
    """Shows the login credentials."""

    from rasax.community.constants import COMMUNITY_USERNAME

    if not config.LOCAL_MODE:
        print_success("Your login password is '{}'.".format(config.rasa_x_password))
    else:
        server_url = "http://localhost:{}".format(config.self_port)
        login_url = "{}/login?username={}&password={}" "".format(
            server_url, COMMUNITY_USERNAME, config.rasa_x_password
        )

        print_success("\nThe server is running at {}\n".format(login_url))
        webbrowser.open_new_tab(login_url)
