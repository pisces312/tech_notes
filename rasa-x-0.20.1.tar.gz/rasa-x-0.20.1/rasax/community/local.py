import asyncio
import hashlib
import logging
import os
import signal
from multiprocessing import get_context
from typing import Text, Tuple, Dict, Any, List, Union

from sqlalchemy.orm import Session

import rasax.community.initialise as initialise
from rasa.cli.utils import print_success
from rasa.data import get_core_nlu_files
from rasa.nlu.training_data import TrainingData
from rasax.community import config, metrics, sql_migrations, __version__
from rasax.community.api.app import initialize_app
from rasax.community.constants import (
    COMMUNITY_PROJECT_NAME,
    COMMUNITY_TEAM_NAME,
    COMMUNITY_USERNAME,
)
from rasax.community.database.utils import session_scope
from rasax.community.server import configure_app
from rasax.community.services.data_service import DataService
from rasax.community.services.domain_service import DomainService
from rasax.community.services.model_service import ModelService
from rasax.community.services.settings_service import (
    SettingsService,
    default_environments_config_local,
)
from rasax.community.services.story_service import StoryService
from rasax.community.utils import (
    accept_terms_or_quit,
    are_terms_accepted,
    is_enterprise_installed,
    metrics_collection_config,
    update_log_level,
)

logger = logging.getLogger(__name__)

LOCAL_DATA_DIR = "data"
LOCAL_DEFAULT_NLU_FILENAME = "nlu.md"
LOCAL_DEFAULT_STORIES_FILENAME = "stories.md"
LOCAL_DOMAIN_PATH = "domain.yml"
LOCAL_CONFIG_PATH = "config.yml"
LOCAL_MODELS_DIR = "models"


def _configure_for_local_server(data_path, token):
    """Create `models` directory and set variables for local mode.

    Sets the API-wide token if provided.
    """

    if not os.path.isdir(LOCAL_MODELS_DIR):
        os.makedirs(LOCAL_MODELS_DIR)

    if token is not None:
        config.rasa_x_token = token

    config.data_dir = data_path
    config.rasa_model_dir = LOCAL_MODELS_DIR
    config.project_name = COMMUNITY_PROJECT_NAME
    config.team_name = COMMUNITY_TEAM_NAME
    config.data_dir = LOCAL_DATA_DIR
    config.default_nlu_filename = LOCAL_DEFAULT_NLU_FILENAME
    config.default_stories_filename = LOCAL_DEFAULT_STORIES_FILENAME
    config.default_username = COMMUNITY_USERNAME
    config.default_domain_path = LOCAL_DOMAIN_PATH
    config.default_config_path = LOCAL_CONFIG_PATH


def check_license_and_metrics(args):
    """Ask the user to accept terms and conditions. If already accepted, skip it."""
    if not are_terms_accepted():
        accept_terms_or_quit(args)

    config.metrics_collection_config = metrics_collection_config(args)


def _enable_development_mode(app):
    if config.development_mode:
        if not is_enterprise_installed():
            raise Exception(
                "Rasa X EE is not installed. Using enterprise endpoints in "
                "local development mode requires an installation of "
                "Rasa X Enterprise Edition."
            )

        from rasax.enterprise.server import configure_enterprise_endpoints

        configure_enterprise_endpoints(app)


def _event_service():
    """Start the event service."""
    # noinspection PyUnresolvedReferences
    from rasax.community.services import event_service

    def signal_handler(sig, frame):
        print("Stopping event service.")
        os.kill(os.getpid(), signal.SIGTERM)

    signal.signal(signal.SIGINT, signal_handler)
    event_service.main()


def _start_event_service():
    """Run the event service in a separate process."""

    ctx = get_context("spawn")
    p = ctx.Process(target=_event_service)
    p.daemon = True
    p.start()


def _initialize_with_local_data(
    project_path: Text, data_path: Text, session: Session, rasa_port: Union[int, Text]
) -> Tuple[Dict[Text, Any], List[Dict[Text, Any]], TrainingData]:
    domain_service = DomainService(session)

    domain = initialise.inject_domain(
        os.path.join(project_path, LOCAL_DOMAIN_PATH),
        domain_service,
        COMMUNITY_PROJECT_NAME,
        COMMUNITY_USERNAME,
    )

    settings_service = SettingsService(session)

    default_env = default_environments_config_local(rasa_port)
    settings_service.save_environments_config(
        COMMUNITY_PROJECT_NAME, default_env.get("environments")
    )

    domain_path = os.path.join(project_path, LOCAL_DOMAIN_PATH)
    initialise.inject_domain(
        domain_path, domain_service, COMMUNITY_PROJECT_NAME, COMMUNITY_USERNAME
    )

    initialise.inject_config(
        os.path.join(project_path, LOCAL_CONFIG_PATH), settings_service
    )

    # discover model
    model_service = ModelService(LOCAL_MODELS_DIR, session, "production")
    model_service.discover_models_on_init(sleep_in_seconds=1)
    model_service.mark_latest_as_production()

    story_files, nlu_files = get_core_nlu_files([data_path])

    loop = asyncio.get_event_loop()
    story_service = StoryService(session)
    story_blocks = loop.run_until_complete(
        initialise.inject_stories(
            story_files, story_service, COMMUNITY_USERNAME, COMMUNITY_TEAM_NAME
        )
    )

    data_service = DataService(session)
    nlu_data = initialise.inject_nlu_data(
        nlu_files, COMMUNITY_PROJECT_NAME, COMMUNITY_USERNAME, data_service
    )

    # dump domain once
    domain_service.dump_domain_in_local_mode()
    return domain, story_blocks, nlu_data


def main(args, project_path: Text, data_path: Text, token: Text = None):
    """Start Rasa X in local mode."""

    print_success("Starting Rasa X in local mode... 🚀")

    config.self_port = args.rasa_x_port

    _configure_for_local_server(data_path, token)

    app = configure_app()

    with session_scope() as session:
        _enable_development_mode(app)
        initialize_app(app)
        sql_migrations.run_migrations(session)

        initialise.create_community_user(session, app)

        domain, story_blocks, nlu_data = _initialize_with_local_data(
            project_path, data_path, session, args.port
        )

    # this needs to run after initial database structures are created
    # otherwise projects assigned to events won't be present
    _start_event_service()

    metrics.track(
        "Local X Start",
        {
            "project": hashlib.md5(project_path.encode("utf-8")).hexdigest(),
            "rasa_x": __version__,
            "num_intent_examples": len(nlu_data.intent_examples),
            "num_entity_examples": len(nlu_data.entity_examples),
            "num_actions": len(domain.get("actions", [])),
            "num_templates": len(domain.get("templates", [])),
            "num_slots": len(domain.get("slots", [])),
            "num_forms": len(domain.get("forms", [])),
            "num_intents": len(domain.get("intents", [])),
            "num_entities": len(domain.get("entities", [])),
            "num_stories": len(story_blocks),
        },
    )

    app.run(
        host="0.0.0.0",
        port=config.self_port,
        auto_reload=os.environ.get("SANIC_AUTO_RELOAD"),
        access_log=False,
    )
