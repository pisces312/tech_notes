import logging
from typing import Any, Dict, Optional, Text

from rasax.community import config
from rasax.community.constants import (
    CONFIG_METRICS_ENABLED,
    CONFIG_METRICS_USER,
    MIXPANEL_TOKEN,
)

logger = logging.getLogger(__name__)


def _mixpanel():
    """Create a mixpanel API instance."""
    from mixpanel import Mixpanel

    return Mixpanel(MIXPANEL_TOKEN)


def are_metrics_enabled() -> bool:
    """Did the user consent to the metrics collection."""
    return config.metrics_collection_config.get(CONFIG_METRICS_ENABLED, False)


def metrics_id() -> Optional[Text]:
    """Random unique consistent id."""
    return config.metrics_collection_config.get(CONFIG_METRICS_USER, None)


def _safe_track(
    distinct_id: Optional[Text],
    event_name: Text,
    properties: Optional[Dict[Text, Any]] = None,
    meta: Optional[Dict[Text, Any]] = None,
):
    try:
        _mixpanel().track(distinct_id, event_name, properties, meta)
    except Exception as e:
        logger.debug("Skipping metrics collection. {}".format(e))


def track_metrics_consent(
    user_id: Text, allow_metrics: bool, auto_accept: bool = False
):
    """Track metric consent."""
    _safe_track(
        user_id,
        "Metrics Consent",
        {"allow_metrics_collection": allow_metrics, "auto_accept": auto_accept},
    )


def track(
    event_name: Text,
    properties: Optional[Dict[Text, Any]] = None,
    meta: Optional[Dict[Text, Any]] = None,
):
    """If enabled, track certain statistical metrics."""

    if not are_metrics_enabled():
        return

    if properties:
        properties["metrics_id"] = metrics_id()

    _safe_track(metrics_id(), event_name, properties, meta)
