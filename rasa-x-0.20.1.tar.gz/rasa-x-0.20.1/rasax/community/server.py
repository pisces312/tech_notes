import logging
import os
from multiprocessing import Process

import rasa.cli.utils
import rasax.community.initialise as initialise
import rasax.community.sql_migrations as sql_migrations
from rasax.community import config
from rasax.community.api.app import configure_app, initialize_app
from rasax.community.database.utils import session_scope
from rasax.community.services.model_service import ModelService
from rasax.community.services.settings_service import SettingsService
from rasax.community.utils import update_log_level

logger = logging.getLogger(__name__)


def main():
    app = configure_app()
    initialize_app(app)
    with session_scope() as session:
        sql_migrations.run_migrations(session)
        initialise.create_community_user(session, app)

        # Initialize environments before they are used in the model discovery process
        settings_service = SettingsService(session)
        settings_service.inject_environments_config_from_file(
            config.project_name, config.default_environments_config_path
        )

        model_service = ModelService(config.rasa_model_dir, session, "production")
        model_service.discover_models_on_init()
        model_service.mark_latest_as_production()

    update_log_level()

    rasa.cli.utils.print_success("Starting Rasa X server... 🚀")
    app.run(
        host="0.0.0.0",
        port=config.self_port,
        auto_reload=os.environ.get("SANIC_AUTO_RELOAD"),
        workers=4,
    )


if __name__ == "__main__":
    from rasax.community.services.event_service import main as event_service_main

    update_log_level()

    # launch event service as background process
    logger.debug("Starting event service.")
    p = Process(target=event_service_main)
    p.daemon = True
    p.start()

    logger.debug("Starting API service.")
    # start API
    main()
