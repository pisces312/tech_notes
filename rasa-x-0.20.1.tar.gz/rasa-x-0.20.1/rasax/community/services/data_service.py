import json
import logging
import os
from collections import OrderedDict
from typing import Text, Dict, List, Union, Any, Optional, Tuple, Set

import time
from sqlalchemy import and_, func

import rasa.nlu.training_data.training_data as nlu_data
from rasa.nlu.training_data import TrainingData as NluTrainingData
from rasa.nlu.training_data.formats import MarkdownReader
from rasa.nlu.training_data.formats.rasa import RasaReader
from rasa.nlu.training_data.loading import RASA, MARKDOWN, _guess_format
from rasax.community import config
from rasax.community.database.data import (
    TrainingData,
    TrainingDataEntity,
    RegexFeature,
    LookupTable,
    EntitySynonym,
)
from rasax.community.database.service import DbService
from rasax.community.initialise import _read_data
from rasax.community.services.stack_service import nlu_format
from rasax.community.utils import get_text_hash, filter_fields_from_dict, QueryResult

logger = logging.getLogger(__name__)


def unique_dictionaries(dicts: List[Dict[Text, Any]]) -> List[Dict[Text, Any]]:
    """Given a list of dictionaries, return a list of unique dictionaries."""

    out = []
    unique_json = set()
    ordered_dicts = [OrderedDict(d) for d in dicts]

    for d in ordered_dicts:
        dict_json = json.dumps(d)
        if dict_json not in unique_json:
            out.append(dict(d))
            unique_json.add(dict_json)

    return out


class DataService(DbService):
    def get_training_data(
        self,
        project_id: Text,
        sort_by_id: bool = False,
        text_query: Optional[Text] = None,
        intent_query: Optional[Text] = None,
        entity_query: bool = False,
        fields_query: List[Tuple[Text, bool]] = None,
        filename: Optional[Text] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        distinct: bool = True,
    ) -> QueryResult:
        if entity_query:
            entities = sorted(self.get_entities(project_id))
            return entities, len(entities)

        if intent_query:
            query = TrainingData.intent.in_(intent_query.split(","))
        else:
            query = True

        if text_query:
            query = and_(query, TrainingData.text.ilike("%{}%".format(text_query)))

        if filename:
            query = and_(query, TrainingData.filename == filename)

        examples = (
            self.query(TrainingData)
            .filter(TrainingData.project_id == project_id)
            .filter(query)
        )

        total_number_examples = examples.count()

        if sort_by_id:
            examples = examples.order_by(TrainingData.id.desc())

        examples = examples.offset(offset).limit(limit)
        if distinct:
            examples = examples.distinct()
        examples = [t.as_dict() for t in examples]

        if fields_query:
            # Field queries can specify relationship items hence we rather get
            # the full objects and then filter out the fields we want.
            examples = [filter_fields_from_dict(e, fields_query) for e in examples]
            if distinct:
                examples = unique_dictionaries(examples)

        return QueryResult(examples, total_number_examples)

    def create_formatted_training_data(
        self, fname: Optional[Text], project: Text
    ) -> Dict[Text, Dict[Text, Any]]:
        """Return training data in NLU format.

        Combines the contents of `training_data`, `regex_features`,
        `entity_synonyms` and `lookup_tables`.
        """

        training_examples, _ = self.get_training_data(project, filename=fname)
        regex_features = self.get_regex_features(project, filename=fname)
        lookup_tables = self.get_lookup_tables(project, filename=fname)
        entity_synonyms = self.get_entity_synonyms(project, filename=fname)
        return nlu_format(
            training_examples, regex_features, lookup_tables, entity_synonyms
        )

    def get_all_filenames(self, project_id: Text) -> List[Text]:
        """Return a list of all values of `filename`."""

        filenames = (
            self.query(TrainingData.filename)
            .filter(TrainingData.project_id == project_id)
            .distinct()
            .all()
        )

        return [f for f, in filenames]

    def get_training_data_for_filename(
        self, project_id: Text, filename: Text
    ) -> List[Dict[Text, Any]]:
        return self.get_training_data(project_id, filename=filename)[0]

    # TODO: in a more advanced version, let's
    # find the filename in which the intent is present most frequently
    def assign_filename(self, project_id: Text) -> Text:
        """Finds the filename of the oldest document in `collection`.

        Returns config.default_nlu_filename if no filename was found."""

        result = (
            self.query(TrainingData.filename)
            .filter(TrainingData.project_id == project_id)
            .order_by(TrainingData.id.asc())
            .first()
        )

        if result:
            return result[0]
        else:
            return os.path.join(config.data_dir, config.default_nlu_filename)

    def get_training_data_warnings(self, project_id: Text) -> List:
        min_examples = 4
        min_intents = 2
        min_examples_per_intent = NluTrainingData.MIN_EXAMPLES_PER_INTENT

        warnings = []

        # actual training data
        default_query = self.query(TrainingData).filter(
            TrainingData.project_id == project_id
        )

        n_examples = default_query.count()

        if n_examples < min_examples:
            warnings.append({"type": "data", "min": min_examples, "count": n_examples})

        ex_per_intent = (
            self.query(func.count(TrainingData.id), TrainingData.intent)
            .filter(TrainingData.project_id == project_id)
            .group_by(TrainingData.intent)
            .all()
        )

        if len(ex_per_intent) < min_intents:
            warnings.append(
                {
                    "type": "intent",
                    "min": min_intents,
                    "count": len(ex_per_intent),
                    "meta": None,
                }
            )

        for examples_for_intent, intent_name in ex_per_intent:
            if examples_for_intent < min_examples_per_intent:
                warnings.append(
                    {
                        "type": "dataPerIntent",
                        "min": min_examples_per_intent,
                        "count": examples_for_intent,
                        "meta": intent_name,
                    }
                )
            # blank intent
            if intent_name == "":
                warnings.append(
                    {"type": "blankIntent", "max": 0, "count": 1, "meta": None}
                )

        return warnings

    def save_example(
        self,
        username: Text,
        project_id: Text,
        example: Dict[Text, Any],
        filename: Optional[Text] = None,
        dump_data_in_local_mode: bool = True,
        add_example_items_to_domain: bool = True,
    ) -> Dict[Text, Any]:
        """Saves a training example or updates it if the example already exists."""

        if not filename:
            filename = self.assign_filename(project_id)

        existing_id = example.get("id")

        if not existing_id:
            text_hash = get_text_hash(example.get("text", ""))
            _example = self.get_example_by_hash(project_id, text_hash)
            existing_id = _example["id"] if _example else None

        if existing_id is not None:
            # if this example already exists we update the existing one
            _example = self.replace_example(
                {"username": username}, project_id, example, existing_id
            )
        else:
            _example = _training_data_object_from_dict(
                example, project_id, filename, username
            )
            self.add(_example)
            self.flush()  # flush to get the example id
            _example = _example.as_dict()

        if dump_data_in_local_mode:
            self._dump_data_in_local_mode()
        if add_example_items_to_domain:
            self._add_intents_and_entities_to_domain([example], project_id)

        return _example

    def save_user_event_as_example(
        self, user: Dict[Text, Text], project_id: Text, event: Dict[Text, Any]
    ) -> Dict[Text, Any]:
        """Adds a training example based on a tracker event.

        Args:
            user: User of the training data.
            project_id: Project id of the new training example.
            event: The tracker event of the user message.

        Returns:
            If successful the stored example, otherwise `None`.
        """

        parse_data = event["parse_data"]
        example = {
            "intent": parse_data["intent"]["name"],
            "entities": parse_data.get("entities", []),
            "text": event.get("text"),
        }
        return self.save_example(user["username"], project_id, example)

    def replace_example(
        self,
        user: Dict[Text, Text],
        project_id: Text,
        example: Dict[Text, Any],
        example_id: Text,
    ) -> Optional[Dict[Text, Any]]:

        existing = (
            self.query(TrainingData).filter(TrainingData.id == example_id).first()
        )

        if not existing:
            return None

        updated = _training_data_object_from_dict(
            example, project_id, existing.filename, user["username"]
        )
        updated.id = existing.id

        self.merge(updated)

        self._dump_data_in_local_mode()

        self._add_intents_and_entities_to_domain([example], project_id)

        return updated.as_dict()

    def _add_intents_and_entities_to_domain(
        self, examples: [List[Dict[Text, Any]]], project_id: Text
    ) -> None:

        intents = [ex.get("intent") for ex in examples]
        entities = [e.get("entity") for ex in examples for e in ex.get("entities", [])]
        self._add_items_to_domain(entities, intents, project_id)

    def add_all_intents_and_entities_to_domain(self, project_id: Text) -> None:
        """Adds intents and entities to domain from all training data."""

        intents = [i["intent"] for i in self.get_intents(project_id)]
        entities = [
            e["entity"]
            for e in self.get_entities(
                project_id, should_exclude_extractor_entities=True
            )
        ]
        self._add_items_to_domain(entities, intents, project_id)

    def _add_items_to_domain(
        self, entities: Set[Text], intents: Set[Text], project_id: Text
    ):
        from rasax.community.services.domain_service import DomainService

        DomainService(self.session).add_items_to_domain(
            intents=intents,
            entities=entities,
            project_id=project_id,
            dump_in_local_mode=False,
            origin="NLU training data",
        )

    def _dump_data_in_local_mode(self):
        if config.LOCAL_MODE:
            self._dump_nlu_data(config.project_name)

    def _dump_nlu_data(self, project: Text = config.project_name) -> None:
        """Dump Rasa NLU data in database to file at `path`."""

        data_filenames = self.get_all_filenames(project)
        for file_name in data_filenames:
            logger.debug("Dumping NLU data to file '{}'.".format(file_name))
            training_data = self.get_nlu_training_data_object(file_name, project)
            training_data.persist(
                os.path.dirname(file_name), os.path.basename(file_name)
            )

    def get_example_by_hash(
        self, project_id: Text, _hash: Text
    ) -> Optional[Dict[Text, Any]]:
        result = (
            self.query(TrainingData)
            .filter(
                and_(TrainingData.project_id == project_id, TrainingData.hash == _hash)
            )
            .first()
        )
        if result:
            return result.as_dict()
        else:
            return None

    def delete_example(self, _id: Text) -> bool:
        result = self.query(TrainingData).filter(TrainingData.id == _id).first()

        if result:
            self.delete(result)
            self._dump_data_in_local_mode()

        return result

    def delete_example_by_hash(self, project_id: Text, _hash: Text) -> bool:
        """Deletes an example based on its text hash.

        Args:
            project_id: Project id of the training example.
            _hash: Text hash of the training example.

        Returns:
            `True` if an example was deleted, otherwise `False`.
        """

        result = (
            self.query(TrainingData)
            .filter(
                and_(TrainingData.project_id == project_id, TrainingData.hash == _hash)
            )
            .all()
        )

        self.delete_all(result)

        return result

    def replace_additional_training_features(
        self,
        project_id: Text,
        training_data: nlu_data.TrainingData,
        filename: Optional[Text] = None,
    ):
        """Persists regex features, lookup tables and entity synonyms.

        Overwrites existing entries."""

        # delete old entries
        self.query(RegexFeature).filter(RegexFeature.project_id == project_id).delete()

        self.query(LookupTable).filter(LookupTable.project_id == project_id).delete()

        self.query(EntitySynonym).filter(
            EntitySynonym.project_id == project_id
        ).delete()

        # Create new ones
        regex_features = [
            RegexFeature(
                name=r.get("name"),
                pattern=r.get("pattern"),
                project_id=project_id,
                filename=filename,
            )
            for r in training_data.regex_features
        ]

        lookup_tables = [
            LookupTable(
                name=l.get("name"),
                elements=json.dumps(l.get("elements", [])),
                project_id=project_id,
                filename=filename,
            )
            for l in training_data.lookup_tables
        ]

        entity_synonyms = [
            EntitySynonym(name=k, synonym=v, project_id=project_id, filename=filename)
            for k, v in training_data.entity_synonyms.items()
        ]

        # insert new entries
        self.bulk_save_objects(regex_features)
        self.bulk_save_objects(lookup_tables)
        self.bulk_save_objects(entity_synonyms)

    def get_regex_features(
        self, project_id: Text, filename: Optional[Text] = None
    ) -> List[Dict[Text, Any]]:
        regex_features = self.query(RegexFeature).filter(project_id == project_id)

        if filename:
            regex_features = regex_features.filter(RegexFeature.filename == filename)

        return [r.as_dict() for r in regex_features.all()]

    @staticmethod
    def _format_entity_synonyms(
        entity_synonyms: Dict[Text, Text]
    ) -> List[Dict[Text, Any]]:
        """Format entity synonyms into shape expected by `RasaReader`.

        `RasaReader` expects a list of dictionaries of the form

        {
            "synonyms": [
              "Chines",
              "chines",
              "Chinese"
            ],
            "value": "chinese"
        }
        """

        unique_names = set(entity_synonyms.values())
        formatted_entity_synonyms = []
        for name in unique_names:
            synonyms = [k for k, v in entity_synonyms.items() if v == name]
            formatted_entity_synonyms.append({"value": name, "synonyms": synonyms})

        return formatted_entity_synonyms

    def get_entity_synonyms(
        self, project_id: Text, filename: Optional[Text] = None
    ) -> List[Dict[Text, Text]]:
        entity_synonyms = self.query(EntitySynonym).filter(project_id == project_id)

        if filename:
            entity_synonyms = entity_synonyms.filter(EntitySynonym.filename == filename)

        entity_synonyms = {e.name: e.synonym for e in entity_synonyms.all()}

        return self._format_entity_synonyms(entity_synonyms)

    def get_lookup_tables(
        self, project_id: Text, filename: Optional[Text] = None
    ) -> List[Dict[Text, Any]]:
        lookup_tables = self.query(LookupTable).filter(project_id == project_id)

        if filename:
            lookup_tables = lookup_tables.filter(LookupTable.filename == filename)

        return [r.as_dict() for r in lookup_tables.all()]

    def get_entities(
        self, project_id: Text, should_exclude_extractor_entities: bool = False
    ) -> List[Dict[Text, Text]]:
        """Fetch entities in training data.

        Exclude entities that have an `extractor` attribute if
        `should_exclude_extractor_entities` is True.
        """

        query = TrainingData.project_id == project_id
        if should_exclude_extractor_entities:
            query = and_(query, TrainingDataEntity.extractor.is_(None))

        entities = (
            self.query(TrainingDataEntity.entity)
            .join(TrainingData)
            .filter(query)
            .distinct()
            .all()
        )

        return [{"entity": e} for e, in entities]

    def get_intents(
        self, project_id: Text, include_example_hashes: bool = True
    ) -> List[Dict[Text, Union[Text, List[Text]]]]:
        """Returns list of intents which appear in the training data.

        Args:
            project_id: Project id of the training data.
            include_example_hashes: If `True` include the hashes of the examples for
                                    each intent.

        Returns:
            List of intent objects which appear in the training data including
            the hashes of the related examples.
        """
        from rasax.community.services.intent_service import INTENT_EXAMPLES_KEY

        intents = (
            self.query(TrainingData.intent)
            .filter(TrainingData.project_id == project_id)
            .distinct()
            .all()
        )

        results = []
        for (i,) in intents:
            intent = {"intent": i}
            if include_example_hashes:
                intent[INTENT_EXAMPLES_KEY] = self._get_example_hashes_for_intent(i)

            results.append(intent)

        return results

    def _get_example_hashes_for_intent(self, intent: Text) -> List[Text]:
        example_hashes = (
            self.query(TrainingData.hash)
            .filter(TrainingData.intent == intent)
            .distinct()
            .all()
        )

        return [e for (e,) in example_hashes]

    def delete_data(self):
        """Deletes all examples."""

        old_training_data = self.query(TrainingData).all()
        self.delete_all(old_training_data)

    def replace_data(
        self,
        project_id: Text,
        data,
        data_format,
        username=None,
        filename=None,
        dump_data_in_local_mode=True,
    ):
        """Deletes all examples and adds examples from `data` in json or
        markdown format instead."""

        self.delete_data()
        self.save_bulk_data(
            project_id, data, data_format, username, filename, dump_data_in_local_mode
        )

    def _save_bulk_data(
        self,
        examples: List[Dict[Text, Any]],
        username: Optional[Text],
        filename: Optional[Text],
        project_id: Text = config.project_name,
    ) -> None:
        objects = [
            _training_data_object_from_dict(e, project_id, filename, username)
            for e in examples
        ]
        self.add_all(objects)

    def save_bulk_data_from_files(
        self,
        nlu_files: Union[List[Text], Set[Text]],
        project_id: Text = config.project_name,
        username: Text = config.default_username,
    ) -> NluTrainingData:
        """Saves NLU data from `nlu_files` to database."""

        training_data = NluTrainingData()

        for data, path in _read_data(list(nlu_files)):
            logger.debug("Injecting NLU data from file '{}' to database.".format(path))

            data_format = _guess_format(path)
            if data_format not in {RASA, MARKDOWN}:
                logger.debug(
                    "Invalid data format for file '{}'. "
                    "Accepting '{}' and '{}' but found "
                    "'{}'.".format(path, RASA, MARKDOWN, data_format)
                )
                continue

            additional_data = self.save_bulk_data(
                project_id,
                data,
                data_format,
                username=username,
                filename=path,
                dump_data_in_local_mode=False,
                add_data_items_to_domain=False,
            )

            if additional_data:
                training_data = training_data.merge(additional_data)

        # add intents and entities to domain
        self.add_all_intents_and_entities_to_domain(project_id)

        return training_data

    def save_bulk_data(
        self,
        project_id: Text,
        data: Union[Text, Dict[Text, Any]],
        data_format: Text,
        username: Optional[Text] = None,
        filename: Optional[Text] = None,
        dump_data_in_local_mode: bool = True,
        add_data_items_to_domain: bool = True,
    ) -> Optional[TrainingData]:
        """Adds examples from `data` in json or markdown format."""

        if not filename:
            filename = self.assign_filename(project_id)

        from rasa.nlu.training_data.loading import RASA, MARKDOWN

        if data_format == RASA:
            if isinstance(data, str):
                data = json.loads(data)
            training_data = RasaReader().read_from_json(data)
        elif data_format == MARKDOWN:
            if isinstance(data, (bytes, bytearray)):
                data = data.decode("utf-8")
            training_data = MarkdownReader().reads(data)
        else:
            return None

        # save regex features, entity synonyms and lookup tables if present
        self.replace_additional_training_features(project_id, training_data, filename)

        examples = [m.as_dict() for m in training_data.training_examples]
        self._save_bulk_data(examples, username, filename, project_id)

        if dump_data_in_local_mode:
            self._dump_data_in_local_mode()

        if add_data_items_to_domain:
            self._add_intents_and_entities_to_domain(examples, project_id)

        return training_data

    def update_intent(
        self, new_intent: Text, example_hashes: List[Text], project_id: Text
    ) -> None:
        """Updates the intent of training examples.

        Args:
            new_intent: Name of the new intent.
            example_hashes: Hashes of the training examples which should be
                            updated.
            project_id: Project id of the training data.
        """

        examples = (
            self.query(TrainingData)
            .filter(
                and_(
                    TrainingData.project_id == project_id,
                    TrainingData.hash.in_(example_hashes),
                )
            )
            .all()
        )

        for e in examples:
            e.intent = new_intent

    def get_nlu_training_data_object(
        self, filename: Optional[Text] = None, project_id: Text = config.project_name
    ) -> NluTrainingData:
        """Get an NLU `TrainingData` object from training data stored in the database.

        Args:
            filename: file name associated with the training data.
            project_id: Project id of the training data.
        """

        combined_nlu_data = self.create_formatted_training_data(filename, project_id)
        return RasaReader().read_from_json(combined_nlu_data)


def _training_data_object_from_dict(
    data: Dict[Text, Any], project_id: Text, filename: Text, username: Text
) -> TrainingData:
    _hash = get_text_hash(data.get("text"))
    entities = data.get("entities", [])
    entities = [
        TrainingDataEntity(
            start=e.get("start"),
            end=e.get("end"),
            entity=e.get("entity"),
            value=e.get("value"),
            extractor=e.get("extractor"),
        )
        for e in entities
    ]
    return TrainingData(
        hash=_hash,
        text=data.get("text"),
        intent=data.get("intent"),
        annotator_id=username,
        annotated_at=time.time(),
        project_id=project_id,
        filename=filename,
        entities=entities,
    )
