import json
import logging
import time
from contextlib import ExitStack
from typing import Text, Optional, List, Dict, Any, Set
from uuid import uuid4

import pika
import sqlalchemy
from sqlalchemy import and_, false

from rasa.core.actions.action import ACTION_LISTEN_NAME
from rasa.core.events import UserUttered, BotUttered, ActionExecuted, deserialise_events
from rasa.core.policies import SimplePolicyEnsemble
from rasa.core.broker import SQLProducer
from rasa.core.trackers import DialogueStateTracker, EventVerbosity
from rasa.core.training.structures import Story
from rasax.community import config, utils
from rasax.community.constants import SHARE_YOUR_BOT_CHANNEL_NAME
from rasax.community.database.analytics import (
    ConversationActionStatistic,
    ConversationPolicyStatistic,
    ConversationIntentStatistic,
    ConversationEntityStatistic,
    ConversationStatistic,
    conversation_statistics_dict,
)
from rasax.community.database.conversation import (
    Conversation,
    ConversationEvent,
    ConversationIntentMetadata,
    ConversationActionMetadata,
    ConversationPolicyMetadata,
    ConversationMessageCorrection,
    ConversationEntityMetadata,
    MessageLog,
)
from rasax.community.database.service import DbService
from rasax.community.database.utils import session_scope
from rasax.community.services.analytics_service import AnalyticsService
from rasax.community.services.data_service import DataService
from rasax.community.services.intent_service import (
    INTENT_MAPPED_TO_KEY,
    INTENT_NAME_KEY,
    IntentService,
)
from rasax.community.services.logs_service import LogsService
from rasax.community.utils import get_text_hash, update_log_level, QueryResult

logger = logging.getLogger(__name__)

FLAGGED_MESSAGES_KEY = "flagged_messages"
UNFLAGGED_MESSAGES_KEY = "unflagged_messages"
CORRECTED_MESSAGES_KEY = "corrected_messages"


class EventService(DbService):
    def get_conversation_events(
        self,
        conversation_id: Text,
        until_time: Optional[float] = None,
        since_time: Optional[float] = None,
    ) -> List[ConversationEvent]:

        since_time = since_time or 0
        filter_query = [
            ConversationEvent.conversation_id == conversation_id,
            ConversationEvent.timestamp >= since_time,
        ]
        if until_time:
            filter_query.append(ConversationEvent.timestamp <= until_time)

        return (
            self.query(ConversationEvent)
            .filter(and_(*filter_query))
            .order_by(ConversationEvent.timestamp.asc())
            .all()
        )

    def get_tracker_for_conversation(
        self,
        conversation_id: Text,
        until_time: Optional[float] = None,
        since_time: Optional[float] = None,
    ) -> Optional[DialogueStateTracker]:
        conversation_events = self.get_conversation_events(
            conversation_id, until_time, since_time
        )
        if conversation_events:
            return DialogueStateTracker.from_dict(
                conversation_id, [json.loads(e.data) for e in conversation_events]
            )
        else:
            logger.debug(
                "Tracker for conversation '{}' not found.".format(conversation_id)
            )
            return None

    def save_event(
        self,
        body_string: Text,
        sender_id: Optional[Text] = None,
        event_number: Optional[int] = None,
    ) -> ConversationEvent:
        logger.debug("Saving event to event service:\n{}".format(body_string))
        event = json.loads(body_string)
        if sender_id:
            event["sender_id"] = sender_id
        self._update_conversation_metadata(event)
        new_event = self._save_conversation_event(event)
        self.update_statistics_from_event(event, event_number)

        # flush so that returned event has an id
        self.flush()

        return new_event

    def _save_conversation_event(self, event: Dict[Text, Any]) -> ConversationEvent:
        sender_id = event.get("sender_id")
        intent = event.get("parse_data", {}).get("intent", {}).get("name")
        action = event.get("name")
        policy = self.extract_policy_base_from_event(event)
        timestamp = event.get("timestamp")

        new_event = ConversationEvent(
            conversation_id=sender_id,
            type_name=event.get("event"),
            timestamp=timestamp,
            intent_name=intent,
            action_name=action,
            data=json.dumps(event),
            policy=policy,
        )

        self.add(new_event)
        self.commit()

        return new_event

    def _update_conversation_metadata(self, event: Dict[Text, Any]) -> None:
        sender_id = event.get("sender_id")

        conversation = (
            self.query(Conversation).filter(Conversation.sender_id == sender_id).first()
        )

        if not conversation:
            conversation = self._insert_conversation_from(event)
            # Flush to obtain row id
            self.flush()

        conversation.latest_event_time = event.get("timestamp")

        event_confidence = event.get("confidence")
        if event_confidence is None:
            event_confidence = 1

        conversation.minimum_action_confidence = min(
            event_confidence, conversation.minimum_action_confidence
        )

        event_type = event.get("event")

        policy = self.extract_policy_base_from_event(event)
        if conversation.in_training_data:
            if policy is None:
                is_memo_policy = True
            else:
                is_memo_policy = not SimplePolicyEnsemble.is_not_memo_policy(policy)
            conversation.in_training_data = is_memo_policy

        intent_name = event.get("parse_data", {}).get("intent", {}).get("name")
        unique_intents = (i.intent for i in conversation.unique_intents)
        if intent_name and intent_name not in unique_intents:
            self.add(
                ConversationIntentMetadata(
                    conversation_id=conversation.sender_id, intent=intent_name
                )
            )

        if event_type == UserUttered.type_name:
            conversation.number_user_messages += 1
            conversation.latest_input_channel = event.get("input_channel")
            entities = event.get("parse_data", {}).get("entities", [])
            entities = [e.get("entity") for e in entities]
            for e in entities:
                existing = (
                    self.query(ConversationEntityMetadata)
                    .filter(
                        and_(
                            ConversationEntityMetadata.conversation_id
                            == conversation.sender_id,
                            ConversationEntityMetadata.entity == e,
                        )
                    )
                    .first()
                )
                if not existing:
                    self.add(
                        ConversationEntityMetadata(
                            conversation_id=conversation.sender_id, entity=e
                        )
                    )

        action_name = event.get("name")
        unique_actions = (a.action for a in conversation.unique_actions)
        if action_name and action_name not in unique_actions:
            self.add(
                ConversationActionMetadata(
                    conversation_id=conversation.sender_id, action=action_name
                )
            )

        if policy and policy not in [p.policy for p in conversation.unique_policies]:
            self.add(
                ConversationPolicyMetadata(
                    conversation_id=conversation.sender_id, policy=policy
                )
            )

        self.commit()

    def _insert_conversation_from(self, _dict: Dict[Text, Any]) -> Conversation:
        sender_id = _dict.get("sender_id", uuid4().hex)
        new = Conversation(
            sender_id=sender_id,
            interactive=_dict.get("interactive", False),
            latest_event_time=time.time(),
        )
        try:
            self.add(new)
            self.commit()
        except sqlalchemy.exc.IntegrityError:
            logger.warning(
                "Conversation for '{}' could not be created since "
                "it already exists.".format(sender_id)
            )
            raise ValueError("Sender id '{}' already exists.".format(sender_id))

        return new

    def create_conversation_from(self, _dict: Dict[Text, Any]) -> Dict[Text, Any]:
        return self._insert_conversation_from(_dict).as_dict()

    @staticmethod
    def extract_policy_base_from_event(event: Dict[Text, Any]) -> Optional[Text]:
        """Given an ActionExecuted event, extracts the base name of

        the policy used. Example: event with `"policy": "policy_1_KerasPolicy"`
        will return `KerasPolicy`."""
        if event.get("policy"):
            return event["policy"].split("_")[-1]

        return None

    def update_statistics_from_event(
        self, event: Dict[Text, Any], event_number: Optional[int]
    ):
        event_name = event.get("event")
        statistic = self.query(ConversationStatistic).first()

        if not statistic:
            statistic = ConversationStatistic(project_id=config.project_name)
            self.add(statistic)
            self.commit()

        statistic.latest_event_timestamp = event["timestamp"]
        statistic.latest_event_id = event_number or statistic.latest_event_id
        if event_name == UserUttered.type_name:
            statistic.total_user_messages += 1
            self._update_user_event_statistic(event)
        elif event_name == BotUttered.type_name:
            statistic.total_bot_messages += 1
        elif (
            event_name == ActionExecuted.type_name
            and event["name"] != ACTION_LISTEN_NAME
        ):
            self._update_action_event_statistic(event)

        self.commit()

    def _update_user_event_statistic(self, event: Dict[Text, Any]):
        intent = event.get("parse_data", {}).get("intent", {}).get("name")
        if intent:
            existing = (
                self.query(ConversationIntentStatistic)
                .filter(ConversationIntentStatistic.intent == intent)
                .first()
            )
            if existing:
                existing.count += 1
            else:
                self.add(
                    ConversationIntentStatistic(
                        project_id=config.project_name, intent=intent
                    )
                )

        entities = event.get("parse_data", {}).get("entities", [])
        for entity in entities:
            entity_name = entity.get("entity")
            existing = (
                self.query(ConversationEntityStatistic)
                .filter(ConversationEntityStatistic.entity == entity_name)
                .first()
            )
            if existing:
                existing.count += 1
            else:
                self.add(
                    ConversationEntityStatistic(
                        project_id=config.project_name, entity=entity_name
                    )
                )

    def _update_action_event_statistic(self, event: Dict[Text, Any]):
        existing = (
            self.query(ConversationActionStatistic)
            .filter(ConversationActionStatistic.action == event["name"])
            .first()
        )
        if existing:
            existing.count += 1
        else:
            self.add(
                ConversationActionStatistic(
                    project_id=config.project_name, action=event["name"]
                )
            )
        policy = self.extract_policy_base_from_event(event)
        if policy:
            existing = (
                self.query(ConversationPolicyStatistic)
                .filter(ConversationPolicyStatistic.policy == policy)
                .first()
            )
            if existing:
                existing.count += 1
            else:
                self.add(
                    ConversationPolicyStatistic(
                        project_id=config.project_name, policy=policy
                    )
                )

    def get_evaluation(self, sender_id: Text) -> Dict[Text, Any]:
        conversation = self._get_conversation(sender_id)

        if conversation and conversation.evaluation:
            return json.loads(conversation.evaluation)
        else:
            return {}

    def _get_conversation(self, sender_id: Text) -> Optional[Conversation]:
        return (
            self.query(Conversation).filter(Conversation.sender_id == sender_id).first()
        )

    def update_evaluation(self, sender_id: Text, evaluation: Dict[Text, Any]) -> None:
        conversation = self._get_conversation(sender_id)

        if conversation:
            conversation.evaluation = json.dumps(evaluation)
            conversation.in_training_data = (
                evaluation.get("in_training_data_fraction", 0) == 1
            )
            self.commit()
        else:
            raise ValueError(
                "No conversation found for sender id '{}'.".format(sender_id)
            )

    def delete_evaluation(self, sender_id: Text) -> None:
        conversation = (
            self.query(Conversation).filter(Conversation.sender_id == sender_id).first()
        )

        if conversation:
            conversation.evaluation = None
            self.commit()

    def get_statistics(self) -> Dict[Text, int]:
        statistic = self.query(ConversationStatistic).first()
        if statistic:
            return statistic.as_dict()
        else:
            return self.user_statistics_dict()

    @staticmethod
    def user_statistics_dict(
        n_user_messages: Optional[int] = None,
        n_bot_messages: Optional[int] = None,
        top_intents: Optional[List[Text]] = None,
        top_actions: Optional[List[Text]] = None,
        top_entities: Optional[List[Text]] = None,
        top_policies: Optional[List[Text]] = None,
    ):
        return conversation_statistics_dict(
            n_user_messages,
            n_bot_messages,
            top_intents,
            top_actions,
            top_entities,
            top_policies,
        )

    def get_conversation_metadata_for_client(
        self, sender_id: Text
    ) -> Optional[Dict[Text, Any]]:
        conversation = self._get_conversation(sender_id)
        if conversation:
            return conversation.as_dict()
        else:
            return None

    def get_unique_actions(self) -> List[str]:
        actions = self.query(ConversationActionStatistic.action).distinct().all()

        return [a for (a,) in actions]

    def get_unique_policies(self) -> List[str]:
        policies = self.query(ConversationPolicyStatistic.policy).distinct().all()

        return [p for (p,) in policies]

    def get_unique_intents(self) -> List[str]:
        intents = self.query(ConversationIntentStatistic.intent).distinct().all()

        return [i for (i,) in intents]

    def get_unique_entities(self) -> List[str]:
        entities = self.query(ConversationEntityStatistic.entity).distinct().all()

        return [e for (e,) in entities]

    def get_conversation_metadata_for_all_clients(
        self,
        start: Optional[float] = None,
        until: Optional[float] = None,
        maximum_confidence: Optional[float] = None,
        minimum_user_messages: Optional[int] = None,
        policies: Optional[Text] = None,
        in_training_data: Optional[bool] = None,
        intent_query: Optional[Text] = None,
        entity_query: Optional[Text] = None,
        action_query: Optional[Text] = None,
        sort_by_date: bool = True,
        sort_by_confidence: bool = False,
        text_query: Optional[Text] = None,
        only_flagged: bool = False,
        include_interactive: bool = False,
        exclude: Optional[List[Text]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> QueryResult:
        conversations = self.query(Conversation)

        query = True
        if start:
            query = Conversation.latest_event_time >= start
        if until:
            query = and_(query, Conversation.latest_event_time <= until)
        if minimum_user_messages:
            query = and_(
                query, Conversation.number_user_messages >= minimum_user_messages
            )
        if in_training_data is not None:
            query = and_(query, Conversation.in_training_data.is_(in_training_data))
        if only_flagged:
            query = and_(query, Conversation.events.any(ConversationEvent.is_flagged))
        if maximum_confidence is not None:
            query = and_(
                query, Conversation.minimum_action_confidence <= maximum_confidence
            )
        if policies:
            policies = policies.split(",")
            query = and_(
                query,
                Conversation.unique_policies.any(
                    ConversationPolicyMetadata.policy.in_(policies)
                ),
            )

        if intent_query:
            intents = intent_query.split(",")
            query = and_(
                query,
                Conversation.unique_intents.any(
                    ConversationIntentMetadata.intent.in_(intents)
                ),
            )

        if action_query:
            actions = action_query.split(",")
            query = and_(
                query,
                Conversation.unique_actions.any(
                    ConversationActionMetadata.action.in_(actions)
                ),
            )

        if entity_query:
            entities = entity_query.split(",")
            query = and_(
                query,
                Conversation.unique_entities.any(
                    ConversationEntityMetadata.entity.in_(entities)
                ),
            )

        if text_query:
            text_query = "%{}%".format(text_query)
            query = and_(
                query,
                Conversation.events.any(
                    ConversationEvent.message_log.has(MessageLog.text.ilike(text_query))
                ),
            )

        if not include_interactive:
            query = and_(query, Conversation.interactive == false())

        if exclude:
            query = and_(query, ~Conversation.sender_id.in_(exclude))

        conversations = conversations.filter(query)
        number_conversations = conversations.count()

        if in_training_data is False and sort_by_confidence:
            conversations = conversations.order_by(
                Conversation.minimum_action_confidence.desc()
            )
        elif sort_by_date:
            conversations = conversations.order_by(
                Conversation.latest_event_time.desc()
            )

        conversations = conversations.offset(offset).limit(limit).all()

        return QueryResult([c.as_dict() for c in conversations], number_conversations)

    def sender_ids(self) -> List[Text]:
        sender_ids = self.query(Conversation.sender_id).distinct().all()

        return [i for i, in sender_ids]

    def story_for_sender_id(self, sender_id: Text) -> Text:
        events = (
            self.query(ConversationEvent.data)
            .filter(ConversationEvent.conversation_id == sender_id)
            .order_by(ConversationEvent.id.asc())
            .all()
        )

        events = deserialise_events([json.loads(e) for e, in events])

        story = Story.from_events(events, sender_id)
        return story.as_story_string(flat=True)

    def add_flagged_message(self, sender_id: Text, message_timestamp: float) -> None:
        event = (
            self.query(ConversationEvent)
            .filter(
                and_(
                    ConversationEvent.conversation_id == sender_id,
                    ConversationEvent.timestamp == message_timestamp,
                )
            )
            .first()
        )

        if not event:
            logger.warning(
                "Event with timestamp '{}' for sender id '{}' was "
                "not found.".format(message_timestamp, sender_id)
            )
        else:
            event.is_flagged = True
            event.is_unflagged = False
            self.commit()

    def delete_flagged_message(self, sender_id: Text, message_timestamp: float) -> None:
        event = (
            self.query(ConversationEvent)
            .filter(
                and_(
                    ConversationEvent.conversation_id == sender_id,
                    ConversationEvent.timestamp == message_timestamp,
                )
            )
            .first()
        )

        if not event:
            logger.warning(
                "Event with timestamp '{}' for sender id '{}' was "
                "not found.".format(message_timestamp, sender_id)
            )
        else:
            event.is_flagged = False
            event.is_unflagged = True
            self.commit()

    def get_flagged_message_timestamps(self, sender_id: Text) -> Set[float]:
        flagged_timestamps = (
            self.query(ConversationEvent.timestamp)
            .filter(
                and_(
                    ConversationEvent.conversation_id == sender_id,
                    ConversationEvent.is_flagged.is_(True),
                )
            )
            .distinct()
            .all()
        )

        return set([t for t, in flagged_timestamps])

    def correct_message(
        self,
        sender_id: Text,
        message_timestamp: float,
        new_intent: Dict[str, str],
        user: Dict[str, str],
        project_id: Text,
    ):
        """Corrects a message and adds it to the training data.

        Args:
            sender_id: The sender id of the conversation.
            message_timestamp: The timestamp of the user message which should
                               be corrected.
            new_intent: Intent object which describes the new intent of the
                        message.
            user: The user who owns the training data.
            project_id: The project id of the training data.
        """
        intent_service = IntentService(self.session)
        existing_intents = intent_service.get_permanent_intents(project_id)
        intent_id = new_intent[INTENT_NAME_KEY]
        is_temporary = intent_id not in existing_intents
        mapped_to = None

        if is_temporary:
            intent_service.add_temporary_intent(new_intent, project_id)
            temporary_intent = intent_service.get_temporary_intent(
                intent_id, project_id
            )
            mapped_to = temporary_intent.get(INTENT_MAPPED_TO_KEY)

        event = (
            self.query(ConversationEvent)
            .filter(
                and_(
                    ConversationEvent.conversation_id == sender_id,
                    ConversationEvent.type_name == UserUttered.type_name,
                    ConversationEvent.timestamp == message_timestamp,
                )
            )
            .first()
        )

        if event is None:
            raise ValueError("A user event for this timestamp does not exist.")

        event = json.loads(event.data)
        if not is_temporary or mapped_to is not None:
            data_service = DataService(self.session)
            event["parse_data"]["intent"]["name"] = mapped_to or intent_id
            example = data_service.save_user_event_as_example(user, project_id, event)
            example_hash = example.get("hash")
            intent_service.add_example_to_temporary_intent(
                new_intent[INTENT_NAME_KEY], example_hash, project_id
            )
        else:
            logger.debug(
                "Message correction was not added to training data, "
                "since the intent was temporary and not mapped to "
                "an existing intent."
            )

        correction = ConversationMessageCorrection(
            conversation_id=sender_id,
            message_timestamp=message_timestamp,
            intent=intent_id,
        )
        self.add(correction)
        self.commit()

    def delete_message_correction(
        self, sender_id: Text, message_timestamp: float, project_id: Text
    ):
        """Deletes a message correction and the related training data.

        Args:
            sender_id: The sender id of the conversation.
            message_timestamp: The timestamp of the corrected user message.
            project_id: The project id of the stored training data.
        """

        correction = (
            self.query(ConversationMessageCorrection)
            .filter(
                and_(
                    ConversationMessageCorrection.conversation_id == sender_id,
                    ConversationMessageCorrection.message_timestamp
                    == message_timestamp,
                )
            )
            .first()
        )

        if correction:
            event = (
                self.query(ConversationEvent)
                .filter(
                    and_(
                        ConversationEvent.conversation_id == sender_id,
                        ConversationEvent.type_name == UserUttered.type_name,
                        ConversationEvent.timestamp == message_timestamp,
                    )
                )
                .first()
            )

            # delete example from training data
            event = json.loads(event.data)
            message_text = event.get("parse_data", {}).get("text")
            message_hash = get_text_hash(message_text)

            data_service = DataService(self.session)
            data_service.delete_example_by_hash(project_id, message_hash)

            # delete example from possible temporary intent
            intent_service = IntentService(self.session)
            intent_service.remove_example_from_temporary_intent(
                correction.intent, message_hash, project_id
            )

            self.delete(correction)
            self.commit()

    @classmethod
    def modify_event_time_to_be_later_than(
        cls,
        minimal_timestamp: float,
        events: List[Dict[Text, Any]],
        minimal_timedelta: float = 0.05,
    ) -> List[Dict[Text, Any]]:
        """Changes the event times to be after a certain timestamp."""

        if not events:
            return events

        events = sorted(events, key=lambda e: e["timestamp"])
        oldest_event = events[0].get("timestamp", minimal_timestamp)
        # Make sure that the new timestamps are greater than the minimal
        difference = minimal_timestamp - oldest_event + minimal_timedelta

        if difference > 0:
            for event in events:
                event["timestamp"] += difference

        return events

    @classmethod
    def remove_leading_action_listen(
        cls, events: List[Dict[Text, Any]]
    ) -> List[Dict[Text, Any]]:
        """Strips a leading `ACTION_LISTEN` from a series of events."""

        if events and events[0].get("name") == ACTION_LISTEN_NAME:
            return events[1:]
        else:
            return events

    def get_messages_for(
        self,
        conversation_id: Text,
        until_time: Optional[float] = None,
        event_verbosity: EventVerbosity = EventVerbosity.ALL,
    ) -> Optional[Dict[Text, Any]]:
        """Gets tracker including a field `messages` which lists user / bot events."""

        flagged_timestamps = self.get_truncated_timestamps(conversation_id)
        tracker = self._get_flagged_tracker_dict(
            conversation_id,
            until_time,
            event_verbosity=event_verbosity,
            flagged_timestamps=flagged_timestamps,
        )

        if tracker is None:
            return None

        messages = []
        for i, e in enumerate(tracker["events"]):
            if e.get("event") in {"user", "bot", "agent"}:
                m = e.copy()
                m["data"] = m.get("data", m.get("parse_data", None))
                m["type"] = m["event"]
                del m["event"]
                messages.append(m)

        tracker["messages"] = messages

        return tracker

    def get_tracker_with_message_flags(
        self,
        conversation_id: Text,
        until_time: Optional[float] = None,
        since_time: Optional[float] = None,
        event_verbosity: EventVerbosity = EventVerbosity.ALL,
    ) -> Optional[Dict[Text, Any]]:
        """Gets tracker including message flags.

        Args:
            conversation_id: Name of the conversation tracker.
            until_time: Include only events until the given time.
            since_time: Include only events after the given time.
            event_verbosity: Verbosity of the returned tracker.

        Returns:
            Tracker for the conversation id.
        """

        flagged_timestamps = self.get_truncated_timestamps(conversation_id)
        tracker = self._get_flagged_tracker_dict(
            conversation_id, until_time, since_time, event_verbosity, flagged_timestamps
        )
        if tracker is not None:
            tracker[FLAGGED_MESSAGES_KEY] = flagged_timestamps

        return tracker

    def _get_flagged_tracker_dict(
        self,
        conversation_id: Text,
        until_time: Optional[float] = None,
        since_time: Optional[float] = None,
        event_verbosity: EventVerbosity = EventVerbosity.AFTER_RESTART,
        flagged_timestamps: Optional[List[float]] = None,
    ) -> Optional[Dict[Text, Any]]:
        tracker = self.get_tracker_for_conversation(
            conversation_id, until_time, since_time
        )

        if not tracker:
            return None

        tracker_dict = tracker.current_state(event_verbosity)

        flagged_timestamps = flagged_timestamps or []
        for i, e in enumerate(tracker_dict["events"]):
            event_timestamp = utils.truncate_float(
                float(e.get("timestamp", -1)), decimal_places=4
            )
            is_flagged = event_timestamp in flagged_timestamps
            tracker_dict["events"][i] = self._flag_event(e, is_flagged)

        return tracker_dict

    @staticmethod
    def _flag_event(event: Dict[Text, Any], is_flagged: bool) -> Dict[Text, Any]:
        tmp = event.copy()
        tmp["is_flagged"] = is_flagged
        return tmp

    def get_truncated_timestamps(
        self, conversation_id: Text, decimal_places: int = 4
    ) -> List[float]:
        """Create a list of flagged timestamps for `conversation_id` truncated to
            `decimal_places` after the decimal separator."""

        flagged_timestamps = self.get_flagged_message_timestamps(conversation_id)
        return [
            utils.truncate_float(timestamp, decimal_places=decimal_places)
            for timestamp in flagged_timestamps
        ]

    @staticmethod
    def get_sender_name(conversation: Conversation) -> Text:
        if conversation.latest_input_channel == SHARE_YOUR_BOT_CHANNEL_NAME:
            return SHARE_YOUR_BOT_CHANNEL_NAME
        else:
            return conversation.sender_id


class PikaEventConsumer:
    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        event_store: EventService,
        analytics_service: AnalyticsService,
        logs_service: LogsService,
        queue="rasa_production_events",
    ):
        credentials = pika.PlainCredentials(username, password)
        parameters = pika.ConnectionParameters(
            host,
            credentials=credentials,
            connection_attempts=20,
            # Wait between retries since
            # it can take some time until
            # RabbitMQ comes up.
            retry_delay=20,
        )

        connection = pika.BlockingConnection(parameters)

        self.logs_service = logs_service
        self.queue = queue
        self.event_store = event_store
        self.analytics_service = analytics_service
        self.channel = connection.channel()
        self.channel.queue_declare(queue, durable=True)

    def consume(self):
        self.channel.basic_consume(self.queue, self._callback, auto_ack=True)
        self.channel.start_consuming()

    # noinspection PyUnusedLocal
    def _callback(self, ch, method, properties, body):
        event = self.event_store.save_event(body)
        self.logs_service.save_nlu_logs_from_event(body, event.id)
        self.analytics_service.save_analytics(body)


class SQLiteEventConsumer:
    def __init__(
        self,
        event_store: EventService,
        analytics_service: AnalyticsService,
        logs_service: LogsService,
    ):
        self.logs_service = logs_service
        self.event_store = event_store
        self.analytics_service = analytics_service
        self.producer = SQLProducer()

    def consume(self):
        while True:
            new_events = (
                self.producer.session.query(self.producer.SQLBrokerEvent)
                .order_by(self.producer.SQLBrokerEvent.id.asc())
                .all()
            )

            for event in new_events:
                saved_event = self.event_store.save_event(
                    event.data, sender_id=event.sender_id, event_number=event.id
                )
                self.logs_service.save_nlu_logs_from_event(event.data, saved_event.id)

                self.analytics_service.save_analytics(
                    event.data, sender_id=event.sender_id
                )

                self.producer.session.delete(event)
                self.producer.session.commit()

            time.sleep(0.1)


def continuously_consume(
    _event_service, _analytics_service, _logs_service, wait_between_failures=5
):
    while True:
        # noinspection PyBroadException
        try:
            if config.LOCAL_MODE:
                consumer = SQLiteEventConsumer(
                    event_store=_event_service,
                    analytics_service=_analytics_service,
                    logs_service=_logs_service,
                )
                logger.info("Start consuming SQLite events.db")
            else:
                consumer = PikaEventConsumer(
                    host=config.rabbitmq_host,
                    username=config.rabbitmq_username,
                    password=config.rabbitmq_password,
                    event_store=_event_service,
                    analytics_service=_analytics_service,
                    logs_service=_logs_service,
                    queue=config.rabbitmq_queue,
                )
                logger.info(
                    "Start consuming pika host '{}'".format(config.rabbitmq_host)
                )

            consumer.consume()
        except Exception:
            logger.exception(
                "Caught an exception while consuming events. "
                "Will retry in {}s".format(wait_between_failures)
            )
            time.sleep(wait_between_failures)


def main():
    logging.getLogger("pika").setLevel(logging.WARNING)
    update_log_level()

    # Create services and give them separate db sessions so that the don't
    # affect each other.
    with ExitStack() as context_stack:
        # create three `session_scope()` contexts
        scopes = [context_stack.enter_context(session_scope()) for _ in range(3)]

        # these three services commit frequently due to using different sessions
        _event_service = EventService(scopes[0])
        _analytics_service = AnalyticsService(scopes[1])
        _logs_service = LogsService(scopes[2])

        continuously_consume(_event_service, _analytics_service, _logs_service)


if __name__ == "__main__":
    main()
