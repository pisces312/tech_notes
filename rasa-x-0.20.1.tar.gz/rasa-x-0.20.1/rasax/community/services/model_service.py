import asyncio
import datetime
import glob
import logging
import os
import shutil
import tarfile
import tempfile
import time
from typing import Optional, Text, Dict, Any, List

from aiohttp import ClientConnectorError
from packaging import version
from sanic.request import Request, File
from sqlalchemy import and_
from sqlalchemy.orm import Session

from rasa.cli.utils import print_warning
from rasa.utils import endpoints
from rasa.model import unpack_model, FINGERPRINT_FILE_PATH
import rasa.utils.io
from rasax.community import config
from rasax.community import utils
from rasax.community.database import Model, ModelTag
from rasax.community.database.service import DbService
from rasax.community.utils import QueryResult

logger = logging.getLogger(__name__)


class ModelService(DbService):
    version_key = "version"

    def __init__(
        self, model_directory: Text, session: Session, environment: Text = "production"
    ):
        self.model_directory = model_directory
        self.environment = environment
        super(ModelService, self).__init__(session)

    def mark_latest_as_production(self):
        latest = self._latest_model()

        if latest:
            self.tag_model(latest["project"], latest["model"], "production")

    def _latest_model(self) -> Optional[Dict[Text, Any]]:
        latest = self.query(Model).order_by(Model.trained_at.desc()).first()

        if not latest:
            return None
        else:
            return latest.as_dict()

    def discover_models_on_init(
        self, max_retries: int = 10, sleep_in_seconds: int = 2
    ) -> None:
        """Synchronize model metadata with models stored on disk."""

        loop = asyncio.get_event_loop()

        while max_retries:
            try:
                loop.run_until_complete(self._discover_models())
                return
            except ClientConnectorError:
                max_retries -= 1
                time.sleep(sleep_in_seconds)
                # Increment sleep after each iteration in server mode as the
                # rasa-production service might take a while to come up.
                # This is not necessary in local mode due to faster startup
                # times.
                if not config.LOCAL_MODE:
                    sleep_in_seconds += 2

        logger.warning("Could not run model discovery.")

    async def minimum_compatible_version(self) -> Optional[Text]:
        from rasax.community.services.settings_service import SettingsService

        if config.LOCAL_MODE:
            # In local mode Rasa X and Rasa are in the same environment
            from rasa.constants import MINIMUM_COMPATIBLE_VERSION

            return MINIMUM_COMPATIBLE_VERSION

        settings_service = SettingsService(self.session)
        stack_service = settings_service.get_stack_service(self.environment)
        info = await stack_service.status()
        if info:
            return info.get("minimum_compatible_version")
        else:
            logger.debug("Couldn't get a minimum compatible model version.")
            return None

    async def _discover_models(self, project_id: Text = config.project_name) -> None:
        minimum_version = await self.minimum_compatible_version()

        available_model_names = []
        for path in glob.glob(os.path.join(self.model_directory, "*.tar.gz")):
            model_version = self.get_model_version(path)
            if not self.is_model_compatible(
                minimum_version, model_version=model_version
            ):
                print_warning(
                    "Version of model {} version is not compatible. "
                    "The model was trained with Rasa version {} "
                    "but the current Rasa requires a minimum version of {}."
                    "Please retrain your model with a more recent Rasa "
                    "version."
                    "".format(os.path.basename(path), model_version, minimum_version)
                )

            filename = os.path.basename(path)
            model_name = filename.split(".tar.gz")[0]
            available_model_names.append(model_name)
            existing_model = self.get_model_by_name(project_id, model_name)
            if not existing_model:
                _ = await self.add_model(project_id, model_name, path)
                logger.debug("Imported model {}".format(model_name))

        self.delete_not_existing_models_from_db(project_id, available_model_names)

    def delete_not_existing_models_from_db(
        self, project_id: Text, available_models: List[Text]
    ):
        """Delete models from the database which are not available on disk."""

        old_models_in_db = (
            self.query(Model)
            .filter(
                and_(
                    Model.project_id == project_id, Model.name.notin_(available_models)
                )
            )
            .all()
        )

        for m in old_models_in_db:
            logger.info(
                "Deleting model '{}' from database since it could not be found "
                "on disk.".format(m.name)
            )
            self.delete(m)

    async def save(
        self, project: Text, model_name: Text, path: Text
    ) -> Optional[Dict[Text, Any]]:
        """Store a model on disk and its metadata in the database.

        IMPORTANT: the `path` needs to be "safe", e.g. if it is
        a user input it needs to be ensured that it doesn't contain
        malicious names (`../../../.ssh/id_rsa`).
        """

        if not os.path.isfile(path):
            raise Exception("Can only handle model files, no dirs.")

        path = os.path.abspath(path)
        if path.startswith(os.path.abspath(self.model_directory)):
            # no need to move model already in model directory
            stored_path = path
        else:
            stored_path = self._store_zipped_model(model_name, path)
            logger.debug("Saved zipped model file at {}".format(stored_path))

        return await self.add_model(project, model_name, stored_path)

    async def add_model(
        self, project: Text, model_name: Text, path: Text
    ) -> Optional[Dict[Text, Any]]:
        model_hash = utils.get_file_hash(path)

        existing = self.get_model_by_name(project, model_name)
        if existing:
            # no need to add, we already got this one
            return existing

        model_version = self.get_model_version(path)
        training_time = self.get_training_time_from_file(path)

        # in server mode, inject domain and training data from first model
        await self.inject_data_from_first_model(project, path)

        return self._save_model_data(
            project, model_name, path, model_hash, model_version, training_time
        )

    @staticmethod
    def get_model_server_url(tag: Text = "production") -> Text:
        """Creates the model server url for a given tag."""

        model_server_host = os.environ.get("RASA_X_HOST", "http://rasa-x:5002")
        model_server_url = endpoints.concat_url(
            model_server_host, "/api/projects/default/models/tags/{}"
        )

        return model_server_url.format(tag)

    async def _inject_domain_from_model(self, project: Text, domain_path: Text) -> None:
        from rasax.community.services.domain_service import DomainService

        domain_service = DomainService(self.session)

        # do not inject if domain_service already contains a domain
        if not domain_service.has_empty_or_no_domain(project):
            return

        from rasax.community.services.nlg_service import NlgService
        from rasa.utils.io import read_yaml_file

        data = read_yaml_file(domain_path)

        # store templates if no templates found in NLG service
        _, number_of_templates = NlgService(self.session).fetch_templates()
        should_store_templates = number_of_templates == 0

        domain_service.store_domain(
            data,
            project,
            path=None,
            store_templates=should_store_templates,
            username=config.SYSTEM_USER,
        )

    async def inject_data_from_first_model(self, project: Text, path: Text) -> None:
        """Inject domain into db from first model if in server mode."""

        # skip if in local mode or there already exists a model in db
        if (
            config.LOCAL_MODE
            or (await self.get_models(project, discover_models=False))[1] > 0
        ):
            return

        unpacked_model_path = unpack_model(path)

        # inject domain
        domain_path = os.path.join(unpacked_model_path, "core", "domain.yml")
        await self._inject_domain_from_model(project, domain_path)

    @staticmethod
    def save_model_to_disk(req: Request) -> Optional[Text]:
        rfiles = req.files

        if "model" not in rfiles or not len(rfiles["model"]):
            raise FileNotFoundError("No `model` file found.")

        _file = rfiles["model"][0]  # type: File
        filename = utils.secure_filename(_file.name)
        if not filename.endswith(".tar.gz"):
            raise TypeError("No `.tar.gz` file found.")

        return utils._write_request_file_to_disk(_file, filename)

    def _store_zipped_model(self, model_name, file_path):
        """Moves a zipped model from a temporary to a permanent location."""

        zpath = self._create_model_save_path(model_name)

        if os.path.exists(zpath):
            raise FileExistsError

        shutil.move(file_path, zpath)
        return zpath

    def persist_zipped_model(self, content: bytes, project: Text, model_name: Text):
        """Saves a streamed zipped model."""

        path = self._create_model_save_path(model_name)

        with open(path, "wb") as f:
            f.write(content)

        model_hash = utils.get_file_hash(path)
        model_version = self.get_model_version(path)
        training_time = self.get_training_time_from_file(path)

        return self._save_model_data(
            project, model_name, path, model_hash, model_version, training_time
        )

    def _create_model_save_path(self, model_name):
        """Creates a directory to save the model at.

        Returns that directory.
        Example: /app/core-projects/default/models/my_model.tar.gz
        """

        if not os.path.isdir(self.model_directory):
            os.makedirs(self.model_directory)
        return os.path.join(self.model_directory, model_name + ".tar.gz")

    def is_model_compatible(
        self,
        minimum_compatible_version: Text,
        fpath: Optional[Text] = None,
        model_version: Optional[Text] = None,
    ) -> bool:
        """Check if a model on disk is compatible with the connected NLU."""

        if fpath:
            model_version = self.get_model_version(fpath)

        return (
            model_version is not None
            and minimum_compatible_version is not None
            and version.parse(model_version)
            >= version.parse(minimum_compatible_version)
        )

    def _save_model_data(
        self,
        project: Text,
        model_name: Text,
        stored_path: Text,
        model_hash: Text,
        _version: Text,
        training_time: float,
    ) -> Dict[Text, Any]:
        model = Model(
            hash=model_hash,
            name=model_name,
            path=stored_path,
            project_id=project,
            version=_version,
            trained_at=training_time,
        )
        self.add(model)

        return model.as_dict()

    def tag_model(
        self, project: Text, model_name: Text, tag: Text
    ) -> Optional[Dict[Text, Any]]:
        self._remove_tag_from_all_models(project, tag)

        model = (
            self.query(Model)
            .filter(and_(Model.project_id == project, Model.name == model_name))
            .first()
        )

        if not model:
            return None
        else:
            tag = ModelTag(tag=tag)
            model.tags.append(tag)
            return model.as_dict()

    def _remove_tag_from_all_models(self, project: Text, tag: Text) -> None:
        model = (
            self.query(Model)
            .join(ModelTag)
            .filter(and_(Model.project_id == project, ModelTag.tag == tag))
            .first()
        )

        if model:
            self.query(ModelTag).filter(
                and_(ModelTag.tag == tag, ModelTag.model_id == model.id)
            ).delete()

    def delete_model(self, project: Text, model_name: Text) -> Dict[Text, Any]:
        """Delete entry and remove model from path."""
        to_delete = (
            self.query(Model)
            .filter(and_(Model.name == model_name, Model.project_id == project))
            .first()
        )

        if to_delete:
            if os.path.exists(to_delete.path):
                os.remove(to_delete.path)

            self.delete(to_delete)

            return to_delete.as_dict()
        else:
            logger.warning(
                "Model '{}' was already removed from database.".format(model_name)
            )
            return {}

    def model_for_tag(self, project: Text, tag: Text) -> Optional[Dict[Text, Any]]:
        model = (
            self.query(Model)
            .join(ModelTag)
            .filter(and_(ModelTag.tag == tag, Model.project_id == project))
            .first()
        )

        if model:
            return model.as_dict()
        else:
            return None

    def get_model_by_name(
        self, project: Text, model_name: Text
    ) -> Optional[Dict[Text, Any]]:
        model = (
            self.query(Model)
            .filter(and_(Model.project_id == project, Model.name == model_name))
            .first()
        )

        if model:
            return model.as_dict()
        else:
            return None

    def delete_tag(self, project: Text, model_name: Text, tag: Text) -> None:
        model = (
            self.query(Model)
            .filter(
                and_(
                    Model.project_id == project,
                    Model.name == model_name,
                    Model.tags.any(ModelTag.tag == tag),
                )
            )
            .first()
        )

        if not model:
            raise ValueError(
                "No model '{}' found for project '{}'.".format(model_name, project)
            )

        for t in model.tags:
            if t.tag == tag:
                self.delete(t)

    def get_model_metadata(self, path: Text) -> Optional[Dict[Text, Any]]:
        tdir = tempfile.mkdtemp()

        tar = tarfile.open(path)
        tar.extractall(tdir)
        tar.close()

        try:
            metadata_path = os.path.join(tdir, FINGERPRINT_FILE_PATH)
            return rasa.utils.io.read_json_file(metadata_path)
        except (FileNotFoundError, ValueError) as e:
            logger.warning(e)
            return None
        finally:
            shutil.rmtree(tdir)

    def get_model_version(self, file_path: Text) -> Text:
        metadata = self.get_model_metadata(file_path)
        if metadata:
            return metadata.get(self.version_key)

        return "0.0.0"

    def get_training_time_from_file(self, file_path: Text) -> float:
        metadata = self.get_model_metadata(file_path)
        if metadata:
            trained_at = None
            try:
                trained_at = metadata.get("trained_at")
                dt = datetime.datetime.strptime(trained_at, "%Y%m%d-%H%M%S")
                trained_at = time.mktime(dt.timetuple())
            except (TypeError, ValueError):
                trained_at = float(metadata.get("trained_at"))
            except (TypeError, ValueError):
                logger.error(
                    "Could not convert `trained_at` time "
                    "from metadata: {}\nUsing file "
                    "modification time instead with "
                    "os.path.getctime().".format(trained_at)
                )
                trained_at = os.path.getctime(file_path)
        else:
            trained_at = time.time()

        return trained_at

    async def get_models(
        self,
        project: Text,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        discover_models=True,
    ) -> QueryResult:

        if discover_models:
            await self._discover_models()

        models = self.query(Model).filter(Model.project_id == project)

        total_number_models = models.count()

        # Order by name and trained at in case two models were trained at the same time
        models = (
            models.order_by(Model.trained_at.desc(), Model.name.asc())
            .offset(offset)
            .limit(limit)
            .all()
        )

        minimum_compatible_version = await self.minimum_compatible_version()

        out = []
        for m in models:
            model_version = m.version
            model = m.as_dict()
            model["is_compatible"] = self.is_model_compatible(
                minimum_compatible_version, model_version=model_version
            )
            out.append(model)

        return QueryResult(out, total_number_models)

    @staticmethod
    def extract_domain_from_model(model_path: Text) -> Optional[Dict[Text, Any]]:
        from rasa.model import unpack_model
        from rasa.utils.io import read_yaml_file
        from rasa.constants import DEFAULT_DOMAIN_PATH

        temp_model_dir = unpack_model(model_path)
        domain_path = os.path.join(temp_model_dir, "core", DEFAULT_DOMAIN_PATH)

        try:
            return read_yaml_file(domain_path)
        except (FileNotFoundError, UnicodeDecodeError) as e:
            logger.error(
                "Could not read domain file for model at "
                "'{}'. Details:\n{}".format(model_path, e)
            )
        finally:
            shutil.rmtree(temp_model_dir, ignore_errors=True)
