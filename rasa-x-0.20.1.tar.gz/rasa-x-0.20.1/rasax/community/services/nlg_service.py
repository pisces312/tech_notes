import json
import logging
import time
from typing import Optional, Tuple, Set
from typing import Text, List, Dict, Any

from sqlalchemy import or_

from rasax.community import config
from rasax.community.database import Template
from rasax.community.database.service import DbService
from rasax.community.utils import (
    get_columns_from_fields,
    get_query_selectors,
    query_result_to_dict,
    QueryResult,
)

logger = logging.getLogger(__name__)


class NlgService(DbService):
    def save_template(
        self,
        template: Dict[Text, Any],
        username: Optional[Text] = None,
        domain_id: Optional[Text] = None,
        project_id: Text = config.project_name,
    ) -> Dict[Text, Any]:

        if domain_id is None:
            logger.warning("Template could not be saved since domain id is None.")
            return {}

        if not username:
            username = config.default_username

        new_template = Template(
            template=template["template"],
            text=template.get("text"),
            content=json.dumps(template),
            annotated_at=time.time(),
            annotator_id=username,
            project_id=project_id,
        )

        if domain_id:
            new_template.domain_id = domain_id

        self.add(new_template)

        self._add_actions_to_domain([template["template"]], project_id=project_id)
        return new_template.as_dict()

    def fetch_templates(
        self,
        text_query: Optional[Text] = None,
        template_query: Optional[Text] = None,
        fields_query: List[Tuple[Text, bool]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> QueryResult:
        templates_to_query = template_query.split(",") if template_query else []
        columns = get_columns_from_fields(fields_query)
        if not text_query and not template_query:
            query = True
        else:
            query = or_(
                Template.template.in_(templates_to_query),
                Template.text.ilike("%{}%".format(text_query)),
            )

        templates = self.query(*get_query_selectors(Template, columns)).filter(query)

        total_number_of_results = templates.count()

        templates = templates.offset(offset).limit(limit).all()

        if columns:
            results = [query_result_to_dict(r, fields_query) for r in templates]
        else:
            results = [t.as_dict() for t in templates]

        return QueryResult(results, total_number_of_results)

    def fetch_all_template_names(self) -> Set[Text]:
        """Fetch a list of all template names in db."""

        return set(t["template"] for t in self.fetch_templates()[0])

    def delete_template(self, _id: Text) -> bool:
        delete_result = self.query(Template).filter(Template.id == _id).delete()

        return delete_result

    def delete_all_templates(self) -> None:
        self.query(Template).delete()

    def update_template(
        self, _id: Text, template: Dict[Text, Any], user: Dict[Text, Any]
    ) -> Optional[Dict[Text, Any]]:
        old_template = self.query(Template).filter(Template.id == _id).first()

        if old_template:
            old_template.text = template["text"]
            old_template.template = template["template"]
            old_template.annotated_at = time.time()
            old_template.content = json.dumps(template)
            old_template.annotator_id = user["username"]

            self._add_actions_to_domain([template["template"]])

            return old_template.as_dict()

        return None

    def replace_templates(
        self,
        new_templates: List[Dict[Text, Any]],
        username: Optional[Text] = None,
        domain_id: Optional[Text] = None,
    ) -> int:
        """Deletes all responses and adds responses from template_list.

        Returns the number of inserted templates.
        """

        self.delete_all_templates()
        insertions = 0
        for template in new_templates:
            inserted = self.save_template(template, username, domain_id=domain_id)
            if inserted:
                insertions += 1

        return insertions

    def _add_actions_to_domain(
        self, actions: List[Text], project_id: Text = config.project_name
    ) -> None:
        from rasax.community.services.domain_service import DomainService

        DomainService(self.session).add_items_to_domain(
            actions=actions, project_id=project_id, origin="responses"
        )
