from setuptools import setup, find_packages

tests_requires = [
    "python-coveralls",
    "pytest-cov",
    "pytest-pycodestyle~=1.4",
    "pytest-services",
    "pytest-cov",
    "pytest",
    "pytest-sanic",
    "aioresponses~=0.6.0",
]

install_requires = [
    "pyjwt",  # no version pinning needed due to sanic-jwt
    "python-dateutil~=2.8",
    "isodate~=0.6.0",
    "jsonschema~=2.6.0",
    "SQLAlchemy~=1.3.0",
    "alembic~=1.0.10",
    "pika~=1.0.0",
    "requests~=2.22",
    "sanic~=19.3.1",
    "sanic-cors~=0.9.6",
    "sanic-jwt~=1.3",
    "aiohttp~=3.5",
    "simplejson~=3.16",
    "apscheduler~=3.5",
    "questionary>=1.1.0",
    "mixpanel~=4.3",
    "setuptools-scm~=3.3",
    # if version is updated, `.env` in the root folder needs to be updated!
    "rasa~=1.2.0",
]

extras_requires = {"test": tests_requires, "sql": ["psycopg2~=2.8"]}

# we need to where as there is no __init__.py in `rasax` because of the
# multi package build. the resulting package name will miss the
# `rasax.community` prefix, which we need to add manually
sub_packages = find_packages(where="rasax/community", exclude=["tests", "tools"])

base_package = "rasax.community"

packages = [base_package + "." + p for p in sub_packages]

setup(
    name="rasa-x",
    packages=packages + [base_package],
    package_data={"": ["alembic.ini"]},
    zip_safe=False,
    use_scm_version={"root": "../..", "relative_to": __file__},
    classifiers=[
        "Programming Language :: Python :: 3.5",
        "Programming Language :: Python :: 3.6",
    ],
    install_requires=install_requires,
    tests_require=tests_requires,
    extras_require=extras_requires,
    include_package_data=True,
    description="Rasa X Community Edition",
    author="Rasa Technologies GmbH",
    author_email="hi@rasa.com",
    url="https://rasa.com",
)
