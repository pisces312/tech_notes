import json
import os
import signal
import sys

import pytest
import requests

from rasa.utils.io import read_yaml_file
from rasax.community import config
from rasax.community.services.domain_service import DomainService
from rasax.community.services.user_service import UserService, ADMIN, ANNOTATOR, TESTER
import rasax.community.sql_migrations as migrations


# we need to manually ensure that a crashing docker container
# returns a non-zero exit code. A crashing docker container may
# sends a SIGTERM
def signal_term_handler(sig, frame):
    print("Received signal {}. Exiting.".format(sig))
    sys.exit(1)


# apply handler to SIGERM
signal.signal(signal.SIGTERM, signal_term_handler)

DOMAIN_PATH = "domain.yml"
TEST_USERNAME = "rasa-test-user"


@pytest.fixture(scope="session", autouse=True)
def mark_as_finished():
    """We need this fixture to mark to the outside world that all tests have been run.

    In the docker compose setup, the container might be killed, before all tests ran
    an even though not all tests might have finished, the exit code might be 0.

    Therefore we need another way to make sure that all tests completed."""

    yield True
    # this code will be run at the end of the session
    if not os.path.exists("output"):  # needs to be a separate dir so we can mount
        os.makedirs("output")

    print("writing output to {}".format(os.path.abspath("output")))
    with open(os.path.join("output", "tests_finished.out"), "w") as f:
        f.write("All tests finished")  # travis uses the file name to check


@pytest.fixture(scope="session")
def session():
    from rasax.community.database.utils import get_database_session

    session = get_database_session(is_local=False)
    migrations.run_migrations(session)

    yield session
    session.close()


@pytest.fixture(scope="session")
def user(session):
    # name and password of default user
    u = {"username": TEST_USERNAME, "password": "secure_pw"}

    user_service = UserService(session)
    user_service.create_user(u["username"], u["password"], config.team_name, ADMIN)

    # inject domain
    data = read_yaml_file(DOMAIN_PATH)
    DomainService(session).store_domain(
        data, config.project_name, store_templates=True, username=TEST_USERNAME
    )

    session.commit()

    return u


@pytest.fixture(scope="session")
def tester_role_user(session):
    # name and password of default user
    u = {"username": "another-rasa-test-user", "password": "secure_pw1"}

    user_service = UserService(session)
    user_service.create_user(u["username"], u["password"], config.team_name, TESTER)
    session.commit()

    return u


@pytest.fixture(scope="session")
def annotator_role_user(session):
    # name and password of default user
    u = {"username": "some-annotator", "password": "secure_pw2"}

    user_service = UserService(session)
    user_service.create_user(u["username"], u["password"], config.team_name, ANNOTATOR)
    session.commit()

    return u


@pytest.fixture(scope="session")
def saml_user(session):
    name_id = "saml_name_id"

    user_service = UserService(session)
    user_service.create_saml_user(
        name_id, dict(), config.team_name, role=config.saml_default_role
    )
    session.commit()

    return user_service.fetch_saml_user(name_id)


@pytest.fixture(scope="session")
def annotator_auth_header(annotator_role_user):
    url = "http://rasa-x:5002/api/auth"
    response = requests.post(url, json=annotator_role_user)
    if not response.status_code == 200:
        raise Exception(
            "Failed to retrieve token. Response: "
            "{} - {}".format(response.status_code, response.text)
        )
    token = response.json()["access_token"]

    return {"Authorization": "Bearer " + token}


@pytest.fixture(scope="session")
def token(user):
    url = "http://rasa-x:5002/api/auth"
    response = requests.post(url, json=user)
    if not response.status_code == 200:
        raise Exception(
            "Failed to retrieve token. Response: "
            "{} - {}".format(response.status_code, response.text)
        )

    return response.json()["access_token"]


@pytest.fixture(scope="session")
def auth_header(token):
    return {"Authorization": "Bearer " + token}


@pytest.fixture(scope="session")
def training_data():
    with open("demo-rasa.json") as f:
        data = json.load(f)
    return data


@pytest.fixture(scope="session")
def training_data_with_emojis():
    with open("demo-rasa-with-emojis.json") as f:
        data = json.load(f)
    return data


@pytest.fixture(scope="session")
def training_data_with_additional_features():
    with open("demo-rasa-with-additional-features.json") as f:
        data = json.load(f)
    return data


@pytest.fixture(scope="session")
def training_data_md():
    with open("demo-rasa.md") as f:
        data = f.read()
    return data


@pytest.fixture(scope="session")
def stories():
    with open("stories.md") as f:
        _stories = f.read()
    return _stories


@pytest.fixture(scope="session")
def domain_yaml():
    with open("domain.yml") as f:
        domain = f.read()
    return domain


@pytest.fixture(scope="session")
def naughty_strings():
    """List of naughty strings.

    Source: https://github.com/minimaxir/big-list-of-naughty-strings"""

    with open("blns.json") as f:
        naughty_strings_list = json.load(f)

    return naughty_strings_list


@pytest.fixture(scope="session")
def nlg_request_body():
    return {
        "tracker": {
            "latest_message": {
                "text": "/greet",
                "intent_ranking": [{"confidence": 1.0, "name": "greet"}],
                "intent": {"confidence": 1.0, "name": "greet"},
                "entities": [],
            },
            "sender_id": "22ae96a6-85cd-11e8-b1c3-f40f241f6547",
            "paused": False,
            "latest_event_time": 1531397673.293572,
            "latest_input_channel": "rasa",
            "slots": {"name": None},
            "events": [
                {
                    "timestamp": 1531397673.291998,
                    "event": "action",
                    "name": "action_listen",
                },
                {
                    "timestamp": 1531397673.293572,
                    "parse_data": {
                        "text": "/greet",
                        "intent_ranking": [{"confidence": 1.0, "name": "greet"}],
                        "intent": {"confidence": 1.0, "name": "greet"},
                        "entities": [],
                    },
                    "event": "user",
                    "text": "/greet",
                    "input_channel": None,
                },
            ],
        },
        "arguments": {},
        "template": "utter_something_we_only_have_here",
        "channel": {"name": "collector"},
    }
