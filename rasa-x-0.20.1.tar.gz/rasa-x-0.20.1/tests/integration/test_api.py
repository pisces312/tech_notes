import datetime
import hashlib
import os
from uuid import uuid4

import pytest
import requests
import time

from rasa.utils.io import read_yaml
from rasax.community import config
from rasax.community.services.role_service import RoleService
from rasax.community.services.user_service import UserService, ADMIN, ANNOTATOR, TESTER

pytest.TRAINED_MODEL_NAME = ""

RASA_TOKEN = os.environ.get("RASA_TOKEN", "")

TEST_STACK_MODEL = "test_model"

DEV_TEST_STACK_MODEL = "test_dev_model"


def test_status():
    url = "http://httpstat.us/200"
    response = requests.get(url)
    assert response.status_code == 200


def repeat(f, attempts=5):
    """Repeats f multiple times, catching exceptions in first failed attempts."""

    while attempts > 1:
        try:
            return f()
        except (AssertionError, requests.exceptions.RequestException):
            time.sleep(5)
            attempts -= 1

    return f()


def test_api_health():
    url = "http://rasa-x:5002/api/health"

    def check():
        assert requests.get(url).status_code == 200

    repeat(check, attempts=20)


@pytest.mark.parametrize(
    "service", ["rasa-production", "rasa-development", "rasa-worker"]
)
def test_stack_health(service):
    url = "http://{}:5005/".format(service)

    def check():
        assert requests.get(url).status_code == 200

    repeat(check, attempts=20)


def test_app_health():
    url = "http://app:5055/health"
    response = requests.get(url)
    assert response.status_code == 200


def test_user_was_created(session, user):
    user_service = UserService(session)
    users = user_service.fetch_all_users(config.team_name)

    assert users
    assert any(u["username"] == user["username"] for u in users)


def test_api_login(user):
    url = "http://rasa-x:5002/api/auth"
    response = requests.post(url, json=user)
    assert response.status_code == 200
    _token = response.json()
    assert "access_token" in _token

    verify_url = "http://rasa-x:5002/api/auth/verify"
    access_token = _token["access_token"]
    auth_header = {"Authorization": "Bearer " + access_token}
    response = requests.get(verify_url, headers=auth_header)
    assert response.status_code == 200


def test_get_versions():
    response = requests.get("http://rasa-x:5002/api/version")
    assert response.status_code == 200

    rjs = response.json()
    assert rjs["rasa-x"]
    assert set(rjs["rasa"].keys()) == {"production", "worker", "development"}


def test_environments_upload_errors(auth_header):
    url = "http://rasa-x:5002/api/environments"
    # base config
    base_config = """
    rasa:
      production:
        url: http://rasa-production:5005
        token: {token}
      development:
        url: http://rasa-development:5005
        token: {token}
      worker:
        url: http://rasa-worker:5005
        token: {token}
    """.format(
        token=os.environ.get("RASA_TOKEN")
    )

    # make sure standard config is ok
    response = requests.get(url, headers=auth_header)
    default_config = response.json()["environments"]
    save_response = requests.put(
        url, headers=auth_header, json={"environments": default_config}
    )
    assert save_response.status_code == 200

    # uploading base_config should pass
    save_response = requests.put(
        url, headers=auth_header, json={"environments": base_config}
    )
    assert save_response.status_code == 200

    # removing `worker` or `production` service should not be possible
    for service in ("worker", "production"):
        save_response = requests.put(
            url,
            headers=auth_header,
            json={"environments": base_config.replace(service, "OTHER")},
        )
        assert save_response.status_code == 400


def test_environments(auth_header):
    url = "http://rasa-x:5002/api/environments"

    test_strings = ["production:", "development:", "worker:"]

    # test if default config is present
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200

    environments_config = response.json().get("environments")
    assert environments_config
    assert all(s in environments_config for s in test_strings)

    # update config
    _config = """
    rasa:
      production:
        url: http://rasa-production:5005
        token: {token}
      development:
        url: http://rasa-development:5005
        token: {token}
      worker:
        url: http://rasa-worker:5005
        token: {token}
      rasa-new-service:
        url: http://rasa-new-service:5005
        token: {token}
    """.format(
        token=os.environ.get("RASA_TOKEN")
    )

    # make sure update config was saved
    save_response = requests.put(
        url, headers=auth_header, json={"environments": _config}
    )
    fetch_response = requests.get(url, headers=auth_header)
    for response in (save_response, fetch_response):
        assert response.status_code == 200
        _config = response.json().get("environments")
        assert all(s in _config for s in test_strings)
        assert all(
            s in _config for s in ["rasa-new-service:", "http://rasa-new-service:5005"]
        )


def test_get_profile(user, auth_header):
    response = requests.get("http://rasa-x:5002/api/user", headers=auth_header)
    assert response.status_code == 200
    _user = response.json()
    assert user["username"] == _user["username"]


def test_single_use_token_login(saml_user, session):
    from secrets import token_urlsafe

    user_service = UserService(session)

    name_id = saml_user["name_id"]

    # make sure SAML user has single-use token with lifetime of 60 s
    token = token_urlsafe(64)
    user_service.update_single_use_token(name_id, token, 60)
    session.commit()  # commit so next request uses updated token

    # test enterprise login
    payload = {"single_use_token": token}
    response = requests.post(
        "http://rasa-x:5002/api/auth/enterpriseTokenLogin", json=payload
    )
    assert response.status_code == 200

    # update token to shorter lifetime and wait
    user_service.update_single_use_token(name_id, token, 0.001)
    session.commit()  # commit so next request uses updated token

    time.sleep(0.01)

    # login should be unsuccessful since token has expired
    response = requests.post(
        "http://rasa-x:5002/api/auth/enterpriseTokenLogin", json=payload
    )
    assert response.status_code == 401


def test_list_users(auth_header):
    response = requests.get("http://rasa-x:5002/api/users", headers=auth_header)
    assert response.status_code == 200
    assert response.json()
    assert set(response.json()[0].keys()) == {
        "username",
        "roles",
        "projects",
        "team",
        "permissions",
        "authentication_mechanism",
    }


def test_get_user_roles(user, auth_header):
    response = requests.get(
        "http://rasa-x:5002/api/users/{}/roles".format(user["username"]),
        headers=auth_header,
    )
    assert response.status_code == 200
    assert response.json()[0]["role"] == ADMIN


def test_update_user_role(tester_role_user, auth_header):
    # assign `annotator`
    roles = [ANNOTATOR]
    response = requests.put(
        "http://rasa-x:5002/api/users/{}/roles" "".format(tester_role_user["username"]),
        headers=auth_header,
        json=roles,
    )
    assert response.status_code == 200

    # check user has `annotator`
    response = requests.get(
        "http://rasa-x:5002/api/users/{}/roles".format(tester_role_user["username"]),
        headers=auth_header,
    )

    assert response.status_code == 200
    assert response.json()[0]["role"] == ANNOTATOR

    # reassign `tester` role
    roles = [TESTER]
    response = requests.put(
        "http://rasa-x:5002/api/users/{}/roles" "".format(tester_role_user["username"]),
        headers=auth_header,
        json=roles,
    )
    assert response.status_code == 200
    assert response.json()["roles"] == [TESTER]


def test_delete_tester_role(tester_role_user, auth_header):
    # delete `tester` role
    response = requests.delete(
        "http://rasa-x:5002/api/users/{}/roles/{}".format(
            tester_role_user["username"], TESTER
        ),
        headers=auth_header,
    )
    assert response.status_code == 200

    # check user has no role
    response = requests.get(
        "http://rasa-x:5002/api/users/{}/roles".format(tester_role_user["username"]),
        headers=auth_header,
    )
    assert response.status_code == 200
    assert len(response.json()) == 0

    # reassign `tester` role
    roles = [TESTER]
    response = requests.put(
        "http://rasa-x:5002/api/users/{}/roles".format(tester_role_user["username"]),
        headers=auth_header,
        json=roles,
    )
    assert response.status_code == 200
    assert response.json()["roles"] == [TESTER]


def test_get_logs(auth_header):
    response = requests.get("http://rasa-x:5002/api/logs", headers=auth_header)
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/zip"


def test_create_new_project(auth_header):
    new_project = "newproject"
    url = "http://rasa-x:5002/api/projects/{}".format(new_project)
    response = requests.post(url, headers=auth_header)
    assert response.status_code == 200
    _project = response.json()
    assert _project["name"] == new_project


def test_create_response(auth_header):
    url = "http://rasa-x:5002/api/templates"
    template = {"template": "utter_greet", "text": "hello hello"}
    response = requests.post(url, json=template, headers=auth_header)
    assert response.status_code == 201
    template = response.json()
    assert template.get("template") is not None


def test_create_second_response_and_query(auth_header):
    template = {"template": "utter_goodbye", "text": "so long :("}
    response = requests.post(
        "http://rasa-x:5002/api/templates", json=template, headers=auth_header
    )
    assert response.status_code == 201
    template = response.json()
    assert template.get("template") is not None

    # limit the responses to one and check the first comes back
    response = requests.get(
        "http://rasa-x:5002/api/templates?limit=1", headers=auth_header
    )
    assert response.status_code == 200

    templates = response.json()
    assert templates is not None
    assert len(templates) == 1

    # there are other responses from the previously injected domain
    assert int(response.headers.get("X-Total-Count")) > 1
    # We know that there are two Responses total and we just
    # added the second one, so just use !=
    assert templates[0]["template"] != template["template"]
    assert templates[0]["text"] != template["text"]

    # query on the text and check only one comes back
    response = requests.get(
        "http://rasa-x:5002/api/templates?q=so+long", headers=auth_header
    )
    assert response.status_code == 200

    templates = response.json()
    assert templates is not None
    assert len(templates) == 1
    assert int(response.headers.get("X-Total-Count")) == 1
    assert templates[0]["template"] == template["template"]
    assert templates[0]["text"] == template["text"]

    # filter on the template name and test that at least one comes back
    url = "http://rasa-x:5002/api/templates?template=utter_goodbye"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200

    templates = response.json()
    assert templates is not None
    assert len(templates) > 0
    assert int(response.headers.get("X-Total-Count")) > 0
    assert templates[0]["template"] == template["template"]

    # filter on the template field and only templates come back
    url = "http://rasa-x:5002/api/templates?fields[template]=true&fields[id]=false"
    response = requests.get(url, headers=auth_header)
    assert set(response.json()[0].keys()) == {"template"}


def test_get_all_responses(auth_header):
    response = requests.get("http://rasa-x:5002/api/templates", headers=auth_header)
    assert response.status_code == 200

    templates = response.json()
    assert templates is not None
    assert len(templates) > 1
    assert int(response.headers.get("X-Total-Count")) > 1


def test_modify_response(auth_header):
    # create a response to modify
    template = {"template": "utter_test", "text": "some text"}
    response = requests.post(
        "http://rasa-x:5002/api/templates", json=template, headers=auth_header
    )
    assert response.status_code == 201

    template = response.json()
    id_to_modify = template.get("id")

    # modify this ID
    modify_body = {"template": "utter_test", "text": "something better than before"}
    modify_url = "http://rasa-x:5002/api/templates/{}".format(id_to_modify)
    response = requests.put(modify_url, json=modify_body, headers=auth_header)
    assert response.status_code == 200

    modified = response.json()
    assert modified["template"] == modify_body["template"]
    assert modified["text"] == modify_body["text"]


def test_delete_response(auth_header):
    # create a response to delete
    url = "http://rasa-x:5002/api/templates"
    template = {"template": "utter_anything", "text": "some text"}
    response = requests.post(url, json=template, headers=auth_header)
    assert response.status_code == 201

    rjs = response.json()
    id_to_delete = rjs.get("id")

    # delete this ID
    delete_url = "{}/{}".format(url, id_to_delete)
    response = requests.delete(delete_url, headers=auth_header)
    assert response.status_code == 204


def test_save_stories(auth_header):
    md_story = """
## my-test-story
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* mood_deny
  - utter_goodbye
"""
    response = requests.post(
        "http://rasa-x:5002/api/stories", data=md_story, headers=auth_header
    )
    assert response.status_code == 200
    assert len(response.json()) > 0

    story = response.json()[0]
    assert story.get("story")
    assert story.get("id")
    assert story.get("name") == "my-test-story"

    # and another one
    md_story_2 = """
## another-story
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
  - utter_happy
* mood_deny
  - utter_goodbye
"""
    response = requests.post(
        "http://rasa-x:5002/api/stories", data=md_story_2, headers=auth_header
    )
    assert response.status_code == 200
    assert len(response.json()) > 0

    story = response.json()[0]
    assert story.get("story")
    assert story.get("id")
    assert story.get("name") == "another-story"


def test_get_stories(auth_header):
    response = requests.get("http://rasa-x:5002/api/stories", headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 2

    # get stories with a text query - should only get the second story back
    response = requests.get(
        "http://rasa-x:5002/api/stories?q=utter_happy", headers=auth_header
    )
    assert response.status_code == 200
    assert len(response.json()) == 1

    # get stories with fields query
    url = "http://rasa-x:5002/api/stories?fields[name]=true&fields[id]=false"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert set(response.json()[0].keys()) == {"name"}


def test_download_stories_bulk(auth_header):
    response = requests.get("http://rasa-x:5002/api/stories.md", headers=auth_header)
    assert response.status_code == 200
    assert b"##" in response.content


def test_download_stories_bulk_with_api_token(auth_header):
    url = "http://rasa-x:5002/api/user"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    api_token = response.json().get("api_token")

    url = "http://rasa-x:5002/api/stories.md?api_token={}".format(api_token)
    response = requests.get(url)
    assert response.status_code == 200
    assert b"##" in response.content


def test_add_story_with_checkpoint_and_comments(auth_header):
    md_story = """
## first story    <!-- comment -->
* hello
    - action_ask_user_question <!-- comment -->
> check_asked_question

## user affirms question   <!-- comment -->
> check_asked_question
* affirm   <!-- comment -->
    - action_handle_affirmation
"""
    response = requests.post(
        "http://rasa-x:5002/api/stories", data=md_story, headers=auth_header
    )
    assert response.status_code == 200
    assert len(response.json()) > 0
    assert response.json()[0].get("name") == "first story"
    assert response.json()[0].get("id")


def test_delete_story(auth_header):
    # create a story to delete
    md_story = """
## story_07715946
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* mood_deny
  - utter_goodbye
"""
    response = requests.post(
        "http://rasa-x:5002/api/stories", data=md_story, headers=auth_header
    )
    assert response.status_code == 200
    assert len(response.json()) > 0

    id_to_delete = response.json()[0].get("id")

    # delete this ID
    delete_url = "http://rasa-x:5002/api/stories/{}".format(id_to_delete)
    response = requests.delete(delete_url, headers=auth_header)
    assert response.status_code == 204

    # delete again and get an error
    delete_url = "http://rasa-x:5002/api/stories/{}".format(id_to_delete)
    response = requests.delete(delete_url, headers=auth_header)
    assert response.status_code == 404


def test_modify_story(auth_header):
    # create a story to modify
    md_story = """
## story_03030393
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* mood_deny
  - utter_goodbye
"""
    response = requests.post(
        "http://rasa-x:5002/api/stories", data=md_story, headers=auth_header
    )

    assert response.status_code == 200
    assert len(response.json()) > 0

    id_to_modify = response.json()[0].get("id")

    md_story_modified = """
## a_better_version
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* mood_deny
  - utter_goodbye
"""

    # modify this story
    delete_url = "http://rasa-x:5002/api/stories/{}".format(id_to_modify)
    response = requests.put(delete_url, data=md_story_modified, headers=auth_header)
    assert response.status_code == 200
    assert "a_better_version" in response.json().get("name")


def test_save_bulk_stories(auth_header, stories):
    url = "http://rasa-x:5002/api/stories"
    response = requests.put(url, data=stories, headers=auth_header)

    assert response.status_code == 200
    rjs = response.json()
    assert int(response.headers.get("X-Total-Count")) == 4

    rjs_names = [s.get("name") for s in rjs]
    rjs_stories = [s.get("story") for s in rjs]

    # there are names and stories in all entries
    assert all(n is not None for n in rjs_names)
    assert all(s is not None for s in rjs_stories)

    # the names and stories of the stories all appear in the uploaded file
    assert all(n in stories for n in rjs_names)
    assert all(s in stories for s in rjs_stories)

    # the names and stories are all distinct
    assert len(set(rjs_names)) == 4
    assert len(set(rjs_stories)) == 4

    # test that stories have been replaced, i.e. these seven stories are
    # all that's returned
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert int(response.headers.get("X-Total-Count")) == 4
    rjs_names_2 = [s.get("name") for s in response.json()]

    # the new names should be the same as the names returned at upload
    assert set(rjs_names) == set(rjs_names_2)


def test_api_change_pw(user, auth_header):
    new_user = {
        "username": user["username"],
        "old_password": user["password"],
        "new_password": "another/secure-pw",
        "new_password_confirm": "another/secure-pw",
    }
    response = requests.post(
        "http://rasa-x:5002/api/user/password", headers=auth_header, json=new_user
    )
    assert response.status_code == 200
    assert response.json()["username"] == user["username"]


def test_create_and_update_training_example(auth_header):
    url = "http://rasa-x:5002/api/projects/default/data"
    # post a training example
    example = {
        "text": "a good example",
        "intent": "testing",
        "entities": [
            {"start": 0, "end": 1, "value": "indefinite", "entity": "article"}
        ],
    }
    response = requests.post(url, headers=auth_header, json=example)
    assert response.status_code == 200
    # remember the id of this example
    example_id = response.json()["id"]

    # change the example's text
    updated_example = response.json()
    updated_example.update({"text": "a fantastic example"})

    # update the example by PUTting to the example id
    response = requests.put(
        "{}/{}".format(url, example_id), headers=auth_header, json=updated_example
    )
    assert response.status_code == 200
    assert response.json()["id"] == example_id
    assert response.json()["text"] == updated_example["text"]

    # uploading the same example is possible
    response = requests.post(url, headers=auth_header, json=updated_example)
    assert response.status_code == 200

    # posting an example with the same text updates the example
    updated_example["entities"] = []
    response = requests.post(url, headers=auth_header, json=updated_example)
    assert response.status_code == 200
    assert response.json()["entities"] == updated_example["entities"]
    assert response.json()["text"] == updated_example["text"]
    assert response.json()["intent"] == updated_example["intent"]
    assert response.json()["id"] == example_id


def test_delete_training_example(auth_header):
    # get a id of a single training example
    response = requests.get(
        "http://rasa-x:5002/api/projects/default/data?limit=1", headers=auth_header
    )
    assert response.status_code == 200
    _id = response.json()[0]["id"]

    url = "http://rasa-x:5002/api/projects/default/data/{}".format(_id)
    response = requests.delete(url, headers=auth_header)
    assert response.status_code == 204


def test_api_nlu_training_data_bulk_md(training_data_md, auth_header):
    url = "http://rasa-x:5002/api/projects/default/data"
    headers = auth_header.copy()
    headers["Content-type"] = "text/markdown"
    response = requests.put(url, headers=headers, data=training_data_md.encode("utf-8"))
    assert response.status_code == 200


def test_api_get_entities(auth_header):
    url = "http://rasa-x:5002/api/projects/default/entities"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert all(
        d in response.json() for d in ({"entity": "location"}, {"entity": "cuisine"})
    )
    assert len(response.json()) == 2


def test_api_nlu_training_data_bulk(training_data, auth_header):
    url = "http://rasa-x:5002/api/projects/default/data"
    response = requests.put(url, headers=auth_header, json=training_data)
    assert response.status_code == 200


def test_api_fetch_training_example_by_hash(training_data, auth_header):
    example = training_data["rasa_nlu_data"]["common_examples"][0]
    text = example["text"]
    _hash = hashlib.md5(text.encode()).hexdigest()
    url = "http://rasa-x:5002/api/projects/default/data/{}".format(_hash)
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert response.json()["text"] == text


def test_api_get_nlu_training_data(training_data, auth_header):
    response = requests.get(
        "http://rasa-x:5002/api/projects/default/data", headers=auth_header
    )
    assert response.status_code == 200
    rjs = response.json()
    assert len(rjs) > 0
    assert set(rjs[0].keys()) >= {"text", "intent"}
    assert int(response.headers.get("X-Total-Count")) == len(rjs)

    # check that a query with an intent filter only returns `intent` as a key
    url = (
        "http://rasa-x:5002/api/projects/default/data?fields[intent]=true&"
        "fields[id]=false"
    )
    response = requests.get(url, headers=auth_header)
    assert set(response.json()[0].keys()) == {"intent"}
    # should only have distinct intents
    distinct_intents = set(
        [ex["intent"] for ex in training_data["rasa_nlu_data"]["common_examples"]]
    )
    assert len(response.json()) == len(distinct_intents)

    # check non-distinct results
    # should have all intents
    url = (
        "http://rasa-x:5002/api/projects/default/data?fields[intent]=true&"
        "fields[id]=false&distinct=false"
    )
    response = requests.get(url, headers=auth_header)
    assert len(response.json()) == len(
        training_data["rasa_nlu_data"]["common_examples"]
    )


def test_api_get_nlu_training_data_totals(auth_header):
    url = "http://rasa-x:5002/api/projects/default/data?limit=1"
    response = requests.get(url, headers=auth_header)
    examples = response.json()
    assert response.status_code == 200
    assert len(examples) == 1
    assert int(response.headers.get("X-Total-Count")) > 1


def test_api_get_nlu_training_data_query(training_data, token):
    auth_header = {"Authorization": "Bearer " + token}
    example = training_data["rasa_nlu_data"]["common_examples"][0]
    text = example["text"]
    intent = example["intent"]
    url = ("http://rasa-x:5002/api/projects/default/data?q={}&intent={}").format(
        text, intent
    )
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    rjs = response.json()
    assert len(rjs) > 0
    assert set(rjs[0].keys()) >= {"text", "intent"}
    assert int(response.headers.get("X-Total-Count")) == len(rjs)
    assert all(ex["text"] == text for ex in rjs)
    assert all(ex["intent"] == intent for ex in rjs)

    # random query should not return anything
    text = "this is definitely not in the data"
    intent = "unrealistic_intent"
    url = ("http://rasa-x:5002/api/projects/default/data?q={}&intent={}").format(
        text, intent
    )
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert response.json() == []
    assert int(response.headers.get("X-Total-Count")) == 0

    # text and intent query should be a logical AND:

    # 1. text query without intent should yield results
    text = example["text"]
    url = ("http://rasa-x:5002/api/projects/default/data?q={}").format(text)
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert all(ex["text"] == text for ex in response.json())
    assert int(response.headers.get("X-Total-Count")) > 0

    # 2. the same text query with a random intent should yield no results
    intent = "random_nonsense_intent"
    url = ("http://rasa-x:5002/api/projects/default/data?q={}&intent={}").format(
        text, intent
    )
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert response.json() == []
    assert int(response.headers.get("X-Total-Count")) == 0


def test_api_get_nlu_training_data_api_token(auth_header):
    url = "http://rasa-x:5002/api/user"
    response = requests.get(url, headers=auth_header)
    api_token = response.json().get("api_token")
    url = ("http://rasa-x:5002/api/projects/default/data.json?api_token={}").format(
        api_token
    )
    response = requests.get(url)
    assert response.status_code == 200
    assert set(response.json()["rasa_nlu_data"]["common_examples"][0].keys()) == {
        "text",
        "intent",
        "entities",
    }


def test_api_get_nlu_training_data_jwt_header(auth_header):
    url = "http://rasa-x:5002/api/projects/default/data.json"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert set(response.json()["rasa_nlu_data"]["common_examples"][0].keys()) == {
        "text",
        "intent",
        "entities",
    }


def test_api_train_stack_model(auth_header, training_data_md):
    # upload full NLU data
    url = "http://rasa-x:5002/api/projects/default/data"
    headers = auth_header.copy()
    headers["Content-type"] = "text/markdown"
    response = requests.put(url, headers=headers, data=training_data_md.encode("utf-8"))
    assert response.status_code == 200

    import concurrent.futures

    with concurrent.futures.ProcessPoolExecutor() as x:
        t_before = time.time()
        train = x.submit(
            requests.post,
            "http://rasa-x:5002/api/projects/default/models/jobs",
            headers=auth_header,
        )

        time_after_status_result = time.time()
        assert train.result().status_code == 200
        assert "new model trained" in train.result().json()["info"]
        pytest.TRAINED_MODEL_NAME = train.result().json()["model"]

        # ensure the requests don't take too long
        assert (time_after_status_result - t_before) < 1

    # get models and ensure new model is listed
    response = requests.get(
        "http://rasa-x:5002/api/projects/default/models", headers=auth_header
    )
    assert response.status_code == 200
    assert response.json()[0]["model"] == pytest.TRAINED_MODEL_NAME


@pytest.mark.parametrize("environment", ["production", "development"])
def test_api_set_environment_models(auth_header, environment):
    # set model
    url = ("http://rasa-x:5002/api/projects/default/models/{}/tags/{}").format(
        pytest.TRAINED_MODEL_NAME, environment
    )
    response = requests.put(url, headers=auth_header)
    assert response.status_code == 204

    # ensure tag is present
    url = ("http://rasa-x:5002/api/projects/default/models/tags/{}").format(environment)
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert response.headers.get("ETag") is not None
    assert pytest.TRAINED_MODEL_NAME in response.headers.get("filename")


@pytest.mark.parametrize(
    "service", ["rasa-production", "rasa-development", "rasa-worker"]
)
def test_stack_services_automatically_fetch_model(service):
    url = "http://{}:5005/status?token={}".format(service, RASA_TOKEN)

    def check():
        response = requests.get(url)
        assert response.status_code == 200
        assert response.json().get("fingerprint")
        assert response.json().get("model_file")

    repeat(check, attempts=30)


def test_api_nlu_status_2(auth_header):
    response = requests.get("http://rasa-x:5002/api/health", headers=auth_header)
    assert response.status_code == 200


def test_api_get_nlu_training_data_warnings(auth_header):
    response = requests.get(
        "http://rasa-x:5002/api/projects/default/dataWarnings", headers=auth_header
    )
    assert response.status_code == 200
    rjs = response.json()
    assert rjs == []
    bad_intent = "test1290812893"
    example = {"text": "a gosdfsdfsdfsod example", "intent": bad_intent, "entities": []}

    response = requests.post(
        "http://rasa-x:5002/api/projects/default/data",
        headers=auth_header,
        json=example,
    )
    assert response.status_code == 200
    bad_id1 = response.json().get("id")

    example = {"text": "another gosdfsdfsdfsod example", "intent": "", "entities": []}
    response = requests.post(
        "http://rasa-x:5002/api/projects/default/data",
        headers=auth_header,
        json=example,
    )

    assert response.status_code == 200
    bad_id2 = response.json().get("id")

    # ensure get warnings
    response = requests.get(
        "http://rasa-x:5002/api/projects/default/dataWarnings", headers=auth_header
    )
    assert response.status_code == 200
    rjs = response.json()

    blank_warning = {"type": "blankIntent", "count": 1, "max": 0, "meta": None}
    bad_warning_1 = {"type": "dataPerIntent", "count": 1, "min": 2, "meta": ""}
    bad_warning_2 = {"type": "dataPerIntent", "count": 1, "min": 2, "meta": bad_intent}

    assert len(rjs) == 3
    assert blank_warning in rjs
    assert bad_warning_1 in rjs
    assert bad_warning_2 in rjs

    # remove bad examples
    url = "http://rasa-x:5002/api/projects/default/data/{}".format(bad_id1)
    response = requests.delete(url, headers=auth_header)
    assert response.status_code == 204
    url = "http://rasa-x:5002/api/projects/default/data/{}".format(bad_id2)
    response = requests.delete(url, headers=auth_header)
    assert response.status_code == 204


def test_api_nlu_parse_query(auth_header):
    url = "http://rasa-x:5002/api/projects/default/logs?q=hey"
    response = requests.post(url, headers=auth_header)
    assert response.status_code == 200
    rjs = response.json()
    assert set(response.json().keys()) == {
        "id",
        "model",
        "project_id",
        "team",
        "time",
        "user_input",
        "hash",
    }
    assert rjs["team"] == "rasa"
    assert rjs["project_id"] == "default"
    assert rjs["user_input"]["text"] == "hey"
    assert set(rjs.keys()) >= {"project_id", "model", "user_input"}
    assert set(rjs["user_input"].keys()) == {
        "entities",
        "intent_ranking",
        "intent",
        "text",
    }


def test_api_nlu_available_models_pagination(auth_header):
    # make sure we have a second model
    train = requests.post(
        "http://rasa-x:5002/api/projects/default/models/jobs", headers=auth_header
    )
    assert train.status_code == 200

    # limit the responses to one and check the first comes back
    url = "http://rasa-x:5002/api/projects/default/models?limit=1"
    response = requests.get(url, headers=auth_header)
    models = response.json()
    assert response.status_code == 200
    assert models is not None
    assert len(models) == 1
    assert int(response.headers.get("X-Total-Count")) > 0
    model1 = models[0]["model"]

    # limit the responses to one, offset by one and check the second comes back
    url = "http://rasa-x:5002/api/projects/default/models?limit=1&offset=1"
    response = requests.get(url, headers=auth_header)
    models = response.json()
    assert response.status_code == 200
    assert models is not None
    assert len(models) == 1
    assert int(response.headers.get("X-Total-Count")) > 1
    # assert that it is different to the first model
    assert models[0]["model"] != model1


def test_api_nlu_suggest(auth_header):
    url = "http://rasa-x:5002/api/projects/default/logs?q=hey+12345"
    response = requests.post(url, headers=auth_header)
    assert response.status_code == 200
    url = "http://rasa-x:5002/api/projects/default/logs"
    response = requests.get(url, headers=auth_header)
    suggestions = response.json()
    assert response.status_code == 200
    count = len(suggestions)
    assert int(response.headers.get("X-Total-Count")) == count
    queries = [s["user_input"]["text"] for s in suggestions]
    assert "hey 12345" in queries

    # check query filtering on intent
    # we expect that the response list only contains the `intent` key
    url = (
        "http://rasa-x:5002/api/projects/default/logs?"
        "fields[user_input][intent][name]=true&"
        "fields[id]=false"
    )
    response = requests.get(url, headers=auth_header)
    rjs = response.json()
    assert set(rjs[0]["user_input"].keys()) == {"intent"}
    assert set(rjs[0]["user_input"]["intent"].keys()) == {"name"}

    # check for both intent and text
    url = (
        "http://rasa-x:5002/api/projects/default/logs?"
        "fields[user_input][intent][name]=true&"
        "fields[user_input][text]=true&"
        "fields[id]=false"
    )
    response = requests.get(url, headers=auth_header)
    rjs = response.json()
    assert set(rjs[0].keys()) == {"user_input"}
    assert "intent" in rjs[0]["user_input"]
    assert "text" in rjs[0]["user_input"]
    assert "name" in rjs[0]["user_input"]["intent"]

    # check id in results
    url = (
        "http://rasa-x:5002/api/projects/default/logs?"
        "fields[user_input][intent][name]=true&"
        "fields[id]=true"
    )
    response = requests.get(url, headers=auth_header)
    rjs = response.json()
    assert "user_input" in rjs[0]
    assert "id" in rjs[0]


def test_api_nlu_suggest_totals(auth_header):
    url = "http://rasa-x:5002/api/projects/default/logs?q=make+sure+there+are+two"
    response = requests.post(url, headers=auth_header)
    assert response.status_code == 200
    url = "http://rasa-x:5002/api/projects/default/logs?limit=1"
    response = requests.get(url, headers=auth_header)
    suggestions = response.json()
    assert response.status_code == 200
    assert len(suggestions) == 1
    assert int(response.headers.get("X-Total-Count")) > 1


def test_api_nlu_suggest_with_query(auth_header):
    # make a query with text `hey`
    text = "hey"
    url = "http://rasa-x:5002/api/projects/default/logs?q={}".format(text)
    response = requests.post(url, headers=auth_header)
    assert response.status_code == 200

    # get the NLU intent of that query
    intent = response.json()["user_input"]["intent"]["name"]

    # get suggestions with the same text and intent
    url = (
        "http://rasa-x:5002/api/projects/default/logs?limit=20&q={}&intent={}"
    ).format(text, intent)
    response = requests.get(url, headers=auth_header)
    suggestions = response.json()
    assert response.status_code == 200
    assert int(response.headers.get("X-Total-Count")) > 0
    assert len(suggestions) > 0

    # archive one of them
    suggestion = suggestions[0]
    _id = suggestion.get("id")
    url = ("http://rasa-x:5002/api/projects/default/logs/{}").format(_id)
    response = requests.delete(url, headers=auth_header)
    assert response.status_code == 204

    # get suggestions again and ensure there is one fewer
    url = (
        "http://rasa-x:5002/api/projects/default/logs?limit=20&q={}&intent={}"
    ).format(text, intent)
    response = requests.get(url, headers=auth_header)
    suggestions_new = response.json()
    assert response.status_code == 200
    assert len(suggestions_new) + 1 == len(suggestions)


def test_api_nlu_message_in_logs(auth_header):
    # make a query with text `49dosdfkjse9q3rjsdflksdofi`
    text = "49dosdfkjse9q3rjsdflksdofi"
    url = "http://rasa-x:5002/api/projects/default/logs?q={}".format(text)
    response = requests.post(url, headers=auth_header)
    assert response.status_code == 200

    # make sure it shows up in the logs
    url = "http://rasa-x:5002/api/projects/default/logs"
    response = requests.get(url, headers=auth_header)
    texts_in_logs = [l["user_input"]["text"] for l in response.json()]
    assert response.status_code == 200
    assert text in texts_in_logs


def test_manually_create_logs(auth_header):
    log = "sth_//random"
    url = "http://rasa-x:5002/api/projects/default/logs"
    response = requests.post(url, headers=auth_header, json=log)
    assert response.status_code == 200
    assert response.json()["user_input"]["text"] == log
    log_id = response.json()["id"]

    # make sure it shows up when getting logs
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    texts = [l["user_input"]["text"] for l in response.json()]
    assert log in texts

    # ensure this log can be fetched by its hash
    _hash = hashlib.md5(log.encode()).hexdigest()
    response = requests.get("{}/{}".format(url, _hash), headers=auth_header)
    assert response.status_code == 200
    assert response.json()["user_input"]["text"] == log

    # posting the same log updates the existing log
    response = requests.post(url, headers=auth_header, json=log)
    assert response.status_code == 200
    assert response.json()["user_input"]["text"] == log
    assert response.json()["id"] == log_id


def test_api_conversations(auth_header):
    url = "http://rasa-x:5002/api/conversations"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert response.json() == []


def test_model_upload(auth_header):
    url = "http://rasa-x:5002/api/projects/default/models"
    with open("{}.tar.gz".format(TEST_STACK_MODEL), "rb") as f:
        response = requests.post(url, headers=auth_header, files={"model": f})
    assert response.status_code == 204

    # tag model as production
    tag_url = (
        "http://rasa-x:5002/api/projects/default/models/"
        "{}/tags/production".format(TEST_STACK_MODEL)
    )
    tag_response = requests.put(tag_url, headers=auth_header)
    assert tag_response.status_code == 204


def test_upload_dev_model(auth_header):
    # copy the default model file so that it has a different name
    import shutil

    shutil.copyfile(
        "{}.tar.gz".format(TEST_STACK_MODEL), "{}.tar.gz".format(DEV_TEST_STACK_MODEL)
    )
    assert os.path.exists("{}.tar.gz".format(DEV_TEST_STACK_MODEL))

    url = "http://rasa-x:5002/api/projects/default/models"
    with open("{}.tar.gz".format(DEV_TEST_STACK_MODEL), "rb") as f:
        response = requests.post(url, headers=auth_header, files={"model": f})
    assert response.status_code == 204

    # tag model as development
    tag_url = (
        "http://rasa-x:5002/api/projects/default/models/"
        "{}/tags/development".format(DEV_TEST_STACK_MODEL)
    )
    tag_response = requests.put(tag_url, headers=auth_header)
    assert tag_response.status_code == 204


@pytest.mark.parametrize("environment_string", ["production", "development"])
def test_api_send_message(auth_header, user, environment_string):
    url = "http://rasa-x:5002/api/conversations/{}/messages?environment={}".format(
        user["username"], environment_string
    )
    payload = {"message": "hello"}
    response = requests.post(url, headers=auth_header, json=payload)
    assert response.status_code == 200


def test_user_role(tester_role_user, user):
    admin_user = user.copy()

    url = "http://rasa-x:5002/api/auth"
    response = requests.post(url, json=tester_role_user)
    access_token = response.json()["access_token"]
    tester_auth_header = {"Authorization": "Bearer " + access_token}

    # send message
    url = "http://rasa-x:5002/api/conversations/{}/messages".format(
        tester_role_user["username"]
    )
    payload = {"message": "hello-from-another-user"}
    response = requests.post(url, headers=tester_auth_header, json=payload)
    assert response.status_code == 200

    time.sleep(4)  # makes sure events get populated to event stream

    # can view only their own conversations
    url = "http://rasa-x:5002/api/conversations"
    response = requests.get(url, headers=tester_auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 1

    # can view own events
    url = "http://rasa-x:5002/api/conversations/{}".format(tester_role_user["username"])
    response = requests.get(url, headers=tester_auth_header)
    assert response.status_code == 200

    # can view own messages
    url = ("http://rasa-x:5002/api/conversations/{}/messages").format(
        tester_role_user["username"]
    )
    response = requests.get(url, headers=tester_auth_header)
    assert response.status_code == 200

    # cannot view others' events
    url = "http://rasa-x:5002/api/conversations/{}".format(admin_user["username"])
    response = requests.get(url, headers=tester_auth_header)
    assert response.status_code == 401

    # cannot view others' messages
    url = ("http://rasa-x:5002/api/conversations/{}/messages").format(
        admin_user["username"]
    )
    response = requests.get(url, headers=tester_auth_header)
    assert response.status_code == 401

    # user's statistics should be empty
    url = "http://rasa-x:5002/api/statistics"
    response = requests.get(url, headers=tester_auth_header)
    rjs = response.json()
    assert response.status_code == 200
    assert set(rjs.keys()) == {
        "user_messages",
        "top_actions",
        "bot_messages",
        "top_intents",
        "top_entities",
        "top_policies",
    }
    # make sure all returned fields are empty lists or zero
    assert all(
        len(value) == 0
        for value in (
            rjs["top_actions"],
            rjs["top_intents"],
            rjs["top_entities"],
            rjs["top_policies"],
        )
    )
    assert all(value == 0 for value in (rjs["user_messages"], rjs["bot_messages"]))


def test_annotator_authenticate(annotator_role_user):
    # authenticate
    auth_url = "http://rasa-x:5002/api/auth"
    response = requests.post(auth_url, json=annotator_role_user)
    assert "access_token" in response.json()


def test_annotator_analytics(annotator_auth_header):
    # cannot see analytics
    analytics_url = "http://rasa-x:5002/api/analytics"
    response = requests.get(analytics_url, headers=annotator_auth_header)
    assert response.status_code == 403


def test_annotator_send_message(annotator_auth_header):
    # send message
    message_url = "http://rasa-production:5005/webhooks/rasa/webhook"
    payload = {"message": "hello-from-another-user"}
    response = requests.post(message_url, headers=annotator_auth_header, json=payload)
    assert response.status_code == 200


def test_annotator_conversations(annotator_auth_header):
    # can view only their own conversations
    conversations_url = "http://rasa-x:5002/api/conversations"

    def check():
        response = requests.get(conversations_url, headers=annotator_auth_header)
        assert response.status_code == 200
        assert len(response.json()) == 1

    # Check repeatedly since Rasa has to first send the events to Rasa X using RabbitMQ
    repeat(check, attempts=3)


def test_annotator_training_examples(annotator_auth_header):
    # can add training example
    example = {
        "text": "a great new example",
        "intent": "testing",
        "entities": [
            {"start": 0, "end": 1, "value": "indefinite", "entity": "article"}
        ],
    }
    data_url = "http://rasa-x:5002/api/projects/default/data"
    response = requests.post(data_url, headers=annotator_auth_header, json=example)
    assert response.status_code == 200

    # can delete example
    example_hash = hashlib.md5(example["text"].encode()).hexdigest()
    fetch_example = requests.get(
        data_url + "/{}".format(example_hash), headers=annotator_auth_header
    )
    example_id = fetch_example.json()["id"]
    deletion = requests.delete(
        data_url + "/{}".format(example_id), headers=annotator_auth_header
    )
    assert deletion.status_code == 204


def test_annotator_train(annotator_auth_header):
    # cannot train
    train_url = "http://rasa-x:5002/api/projects/default/models/jobs"
    response = requests.post(train_url, headers=annotator_auth_header)
    assert response.status_code == 403


def test_annotator_modify_config(annotator_auth_header):
    # cannot modify Stack config
    _config = """
        language: "en"
        pipeline: "tensorflow_embedding"
        """
    config_url = "http://rasa-x:5002/api/projects/default/settings"
    settings = {"config": _config}
    response = requests.put(config_url, headers=annotator_auth_header, json=settings)
    assert response.status_code == 403


def test_annotator_view_models(annotator_auth_header):
    # cannot view models
    url = "http://rasa-x:5002/api/projects/default/models"
    response = requests.get(url, headers=annotator_auth_header)
    assert response.status_code == 403


def test_annotator_responses(annotator_auth_header):
    # can read responses
    responses_url = "http://rasa-x:5002/api/templates"
    responses_view = requests.get(responses_url, headers=annotator_auth_header)
    assert responses_view.status_code == 200

    # can write responses
    template = {"template": "utter_greet", "text": "sup hello"}
    response = requests.post(
        responses_url, json=template, headers=annotator_auth_header
    )
    assert response.status_code == 201


def test_annotator_add_story(annotator_auth_header):
    # can add single story
    stories_url = "http://rasa-x:5002/api/stories"
    md_story = """
## my-test-story
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* mood_deny
  - utter_goodbye
"""
    story_response = requests.post(
        stories_url, data=md_story, headers=annotator_auth_header
    )
    assert story_response.status_code == 200


def test_annotator_bulk_stories(annotator_auth_header, stories):
    # can add bulk stories
    stories_url = "http://rasa-x:5002/api/stories"
    story_response = requests.put(
        stories_url, data=stories, headers=annotator_auth_header
    )
    assert story_response.status_code == 200


def test_annotator_view_stories(annotator_auth_header):
    # can view stories
    stories_url = "http://rasa-x:5002/api/stories"
    story_response = requests.get(stories_url, headers=annotator_auth_header)
    assert story_response.status_code == 200


def test_annotator_set_features(annotator_auth_header):
    # cannot write features
    features_url = "http://rasa-x:5002/api/features"
    payload = {"name": "interactiveLearning", "enabled": True}
    features = requests.post(features_url, json=payload, headers=annotator_auth_header)
    assert features.status_code == 403


def test_api_send_message_should_become_log(auth_header, user):
    message = "e938rwdmsdfs9fis"
    url = "http://rasa-x:5002/api/conversations/{}/messages".format(user["username"])
    payload = {"message": message}
    response = requests.post(url, headers=auth_header, json=payload)
    assert response.status_code == 200

    url = "http://rasa-x:5002/api/projects/default/logs"

    def check():
        response = requests.get(url, headers=auth_header)
        suggestions = response.json()
        queries = [s["user_input"]["text"] for s in suggestions]
        assert message in queries

    repeat(check, attempts=3)


def test_api_send_message_should_become_log_dev_stack(auth_header, user):
    message = "e938rwdmsdfs9fis"
    url = "http://rasa-x:5002/api/conversations/{}/messages?environment={}".format(
        user["username"], "development"
    )
    payload = {"message": message}
    response = requests.post(url, headers=auth_header, json=payload)
    assert response.status_code == 200

    url = "http://rasa-x:5002/api/projects/default/logs"

    def check():
        response = requests.get(url, headers=auth_header)
        suggestions = response.json()
        queries = [s["user_input"]["text"] for s in suggestions]
        assert message in queries

    repeat(check, attempts=3)


def test_api_stack_conversations(auth_header):
    url = "http://rasa-x:5002/api/conversations"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) > 0
    assert set(response.json()[0].keys()) == {
        "latest_event_time",
        "latest_input_channel",
        "sender_id",
        "sender_name",
        "intents",
        "interactive",
        "actions",
        "minimum_action_confidence",
        "in_training_data",
        "n_user_messages",
        "policies",
        "flagged_messages",
        "unflagged_messages",
        "corrected_messages",
    }


def test_api_dev_stack_conversations(auth_header):
    url = "http://rasa-x:5002/api/conversations?environment=development"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) > 0
    assert set(response.json()[0].keys()) == {
        "latest_event_time",
        "latest_input_channel",
        "sender_id",
        "sender_name",
        "intents",
        "interactive",
        "actions",
        "minimum_action_confidence",
        "in_training_data",
        "n_user_messages",
        "policies",
        "unflagged_messages",
        "flagged_messages",
        "corrected_messages",
    }


def test_api_stack_conversations_filtering_queries(auth_header):
    base_url = "http://rasa-x:5002/api/conversation"

    def check():
        response = requests.get(base_url + "Actions", headers=auth_header)
        assert response.status_code == 200
        # contains at least one utterance
        assert response.json()
        assert any(a.startswith("utter") for a in response.json())

        response = requests.get(base_url + "Entities", headers=auth_header)
        assert response.status_code == 200
        assert len(response.json()) == 0

        response = requests.get(base_url + "Intents", headers=auth_header)
        assert response.status_code == 200
        assert response.json()

        response = requests.get(base_url + "Policies", headers=auth_header)
        assert response.status_code == 200

        assert response.json()
        assert all(p.endswith("Policy") for p in response.json())

    # TODO: this check is very model-dependent and fails frequently
    # contains at least one policy whose name ends on `Policy`
    # repeat(check)


def test_send_messages_with_non_standard_characters(auth_header, naughty_strings, user):
    # send message and make sure it's processed
    webhook_url = "http://rasa-x:5002/api/conversations/{}/messages".format(
        user["username"]
    )
    for s in naughty_strings:
        payload = {"message": s}
        response = requests.post(webhook_url, headers=auth_header, json=payload)
        assert response.status_code == 200

    conversation_url = "http://rasa-x:5002/api/conversations/{}".format(
        user["username"]
    )

    def check():
        # check that this message appears in the conversation
        conversation = requests.get(conversation_url, headers=auth_header)
        assert conversation.status_code == 200
        texts = [
            e["text"] for e in conversation.json()["events"] if e["event"] == "user"
        ]
        assert all(s in texts for s in naughty_strings)

    repeat(check, attempts=3)


def test_add_training_examples_with_non_standard_characters(
    auth_header, naughty_strings
):
    url = "http://rasa-x:5002/api/projects/default/data"
    for s in naughty_strings:
        # post example with naughty string
        example = {"text": s, "intent": "some-intent", "entities": []}
        response = requests.post(url, headers=auth_header, json=example)
        assert response.status_code == 200
        assert response.json()["text"] == s

        # ensure it's in training data
        _hash = hashlib.md5(s.encode()).hexdigest()
        response = requests.get(
            url + "/{}".format(_hash), headers=auth_header, json=example
        )
        assert response.status_code == 200
        assert response.json()["text"] == s

        # delete example
        _id = response.json()["id"]
        deletion = requests.delete(url + "/{}".format(_id), headers=auth_header)
        assert deletion.status_code == 204


def test_post_event(auth_header):
    url = "http://rasa-x:5002/api/conversations/myid/events"

    payload = {
        "timestamp": time.time() + 1,  # give buffer of 1 second as
        # this needs to be after the newly created action_listen
        "parse_data": {
            "entities": [],
            "intent": {"confidence": 0.60, "name": "mood_great"},
            "text": "/mood_great",
            "intent_ranking": [
                {"confidence": 0.60, "name": "mood_great"},
                {"confidence": 0.20, "name": "greet"},
                {"confidence": 0.20, "name": "goodbye"},
            ],
        },
        "event": "user",
        "text": "/mood_great",
    }
    response = requests.post(url, headers=auth_header, json=payload)
    assert response.status_code == 200

    def check():
        # check that event is in tracker
        url = "http://rasa-x:5002/api/conversations/myid"
        response = requests.get(url, headers=auth_header)
        assert any(
            payload["timestamp"] == e["timestamp"] for e in response.json()["events"]
        )
        assert any(
            payload["parse_data"] == e.get("parse_data")
            for e in response.json()["events"]
        )

        # check that user shows up in conversations view
        url = "http://rasa-x:5002/api/conversations"
        response = requests.get(url, headers=auth_header)
        assert response.status_code == 200
        assert any("myid" in e["sender_id"] for e in response.json())

    repeat(check)


def test_execute_action(auth_header):
    url = "http://rasa-x:5002/api/conversations/myid/execute"

    payload = {"name": "utter_greet"}

    response = requests.post(url, headers=auth_header, json=payload)

    assert response.status_code == 200
    # check that the bot actually dispatched an utterance
    assert len(response.json().get("messages")) > 0


def test_conversations_queries(auth_header, user):
    # text query
    url = "http://rasa-x:5002/api/conversations?text=/mood_great"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert all("myid" in e["sender_id"] for e in response.json())

    # more than one result without text query
    url = "http://rasa-x:5002/api/conversations"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) > 1
    assert any("myid" in e["sender_id"] for e in response.json())
    assert any(user["username"] in e["sender_id"] for e in response.json())

    # none with random text query
    url = "http://rasa-x:5002/api/conversations?text=49vroiu9rgj"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 0

    # intent query
    url = "http://rasa-x:5002/api/conversations?intent=mood_great"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert any(e["sender_id"] == "myid" for e in response.json())

    # no results for random intent query
    url = "http://rasa-x:5002/api/conversations?intent=random_intent_non_existing"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 0

    # entity query
    url = "http://rasa-x:5002/api/conversations?entity=donthaveanyyet"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 0

    # action query returns results for action_listen
    url = "http://rasa-x:5002/api/conversations?action=action_listen"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) > 0

    # action query returns no results for nonexisting action
    url = "http://rasa-x:5002/api/conversations?action=3490isef9iwe9risdfm"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 0

    # in training data
    url = "http://rasa-x:5002/api/conversations?in_training_data=true"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert all(res["in_training_data"] for res in response.json())

    # not in training data
    url = "http://rasa-x:5002/api/conversations?in_training_data=false"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert all(not res["in_training_data"] for res in response.json())

    # sort by confidence
    url = (
        "http://rasa-x:5002/api/conversations?"
        "in_training_data=false&sort_by_confidence=true"
    )
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    confidences = [res["minimum_action_confidence"] for res in response.json()]
    assert confidences == list(reversed(sorted(confidences)))

    # sort by latest event time
    url = "http://rasa-x:5002/api/conversations?sort_by_latest_event_time=true"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    result_times = [res["latest_event_time"] for res in response.json()]
    assert result_times == list(reversed(sorted(result_times)))

    # start date in the past yields results
    url = "http://rasa-x:5002/api/conversations?start=0"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) > 0

    # until time in the past yields no results
    url = "http://rasa-x:5002/api/conversations?until=0.1"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 0

    # confidence query with 1
    url = "http://rasa-x:5002/api/conversations?maximumConfidence=1"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) > 0

    # confidence query with 0
    url = "http://rasa-x:5002/api/conversations?maximumConfidence=0"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 0

    # user message query
    url = "http://rasa-x:5002/api/conversations?minimumUserMessages=1"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) > 0

    # user message query no results
    url = "http://rasa-x:5002/api/conversations?minimumUserMessages=1000000"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 0

    for policy in ["FallbackPolicy", "KerasPolicy"]:
        url = "http://rasa-x:5002/api/conversations?policies={}".format(policy)
        response = requests.get(url, headers=auth_header)
        assert response.status_code == 200
        assert response.json()

    # no results for non-existing policy
    url = "http://rasa-x:5002/api/conversations?policies=R4ndomPolicy"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 0


def test_update_conversation_evaluations(auth_header):
    url = "http://rasa-x:5002/api/evaluate"
    response = requests.post(url, headers=auth_header)
    assert response.status_code == 204


def test_get_all_conversation_evaluations(auth_header):
    url = "http://rasa-x:5002/api/evaluations"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert any(r.get("myid") for r in response.json())


def test_get_single_conversation_evaluation(auth_header):
    url = "http://rasa-x:5002/api/conversations/myid/evaluation"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert set(response.json().keys()) == {
        "accuracy",
        "precision",
        "report",
        "f1",
        "actions",
        "is_end_to_end_evaluation",
        "in_training_data_fraction",
    }


def test_put_conversation_evaluation(auth_header):
    url = "http://rasa-x:5002/api/conversations/myid/evaluation"
    response = requests.put(url, headers=auth_header)
    assert response.status_code == 200
    assert set(response.json().keys()) == {
        "accuracy",
        "precision",
        "report",
        "f1",
        "actions",
        "is_end_to_end_evaluation",
        "in_training_data_fraction",
    }


def test_api_stack_event_history(auth_header, user):
    url = "http://rasa-x:5002/api/user"
    response = requests.get(url, headers=auth_header)
    api_token = response.json().get("api_token")

    # length of events before restart with jwt header
    jwt_url = "http://rasa-x:5002/api/conversations/{}".format(user["username"])
    response = requests.get(jwt_url, headers=auth_header)
    assert response.status_code == 200
    assert set(response.json().keys()) == {
        "events",
        "latest_event_time",
        "latest_message",
        "paused",
        "followup_action",
        "sender_id",
        "slots",
        "latest_input_channel",
        "latest_action_name",
        "active_form",
        "flagged_messages",
    }

    # length of events before restart with api_token
    api_token_url = jwt_url + "?api_token={}".format(api_token)
    response = requests.get(api_token_url)
    assert response.status_code == 200
    assert set(response.json().keys()) == {
        "events",
        "latest_event_time",
        "latest_message",
        "paused",
        "followup_action",
        "sender_id",
        "slots",
        "latest_input_channel",
        "latest_action_name",
        "active_form",
        "flagged_messages",
    }

    pre_restart_length = len(response.json()["events"])

    # send restart message
    send_url = "http://rasa-x:5002/api/chat"
    payload = {"message": "/restart"}
    response = requests.post(send_url, headers=auth_header, json=payload)
    assert response.status_code == 200

    # make sure events made it through the event stream
    def check():
        # length of events after restart
        # no history param
        response = requests.get(api_token_url)
        events_no_parameter = response.json()["events"]
        post_restart_length = len(events_no_parameter)
        assert post_restart_length > pre_restart_length

        # length of events after restart
        # history=true
        history_url = api_token_url + "&history=true"
        response = requests.get(history_url)
        events_parameter_true = response.json()["events"]
        hist_parameter_true_length = len(events_parameter_true)
        assert hist_parameter_true_length == post_restart_length

        # length of events with history=false in query
        # history=false
        no_history_url = api_token_url + "&history=false"
        response = requests.get(no_history_url)
        no_history_length = len(response.json()["events"])
        assert no_history_length < post_restart_length
        assert no_history_length < pre_restart_length

    # TODO: this check is very model-dependent and fails frequently
    # repeat(check)


def test_api_stack_messages_history(auth_header, user):
    # send message to fill tracker, followed by a /restart
    send_url = "http://rasa-x:5002/api/conversations/{}/messages".format(
        user["username"]
    )
    for msg in ("hello", "/restart"):
        payload = {"message": msg}
        response = requests.post(send_url, headers=auth_header, json=payload)
        assert response.status_code == 200

    def check():
        # list of messages is non-empty
        url = "http://rasa-x:5002/api/conversations/{}/messages".format(
            user["username"]
        )
        response = requests.get(url, headers=auth_header)
        assert response.status_code == 200
        assert set(response.json().keys()) == {
            "events",
            "latest_event_time",
            "latest_message",
            "messages",
            "paused",
            "followup_action",
            "sender_id",
            "slots",
            "latest_input_channel",
            "latest_action_name",
            "active_form",
        }
        messages = response.json().get("messages")
        assert messages

        # history=true
        history_url = url + "?history=true"
        response = requests.get(history_url, headers=auth_header)
        assert response.json().get("messages") == messages

        # list of messages is empty
        # history=false
        history_url = url + "?history=false"
        response = requests.get(history_url, headers=auth_header)
        assert response.json().get("messages") == []

    # TODO: this check is very model-dependent and fails frequently
    # repeat(check)


def test_api_stack_statistics(auth_header):
    url = "http://rasa-x:5002/api/statistics"
    response = requests.get(url, headers=auth_header)
    rjs = response.json()
    assert response.status_code == 200
    assert set(rjs.keys()) == {
        "user_messages",
        "top_actions",
        "bot_messages",
        "top_intents",
        "top_entities",
        "top_policies",
    }

    # make sure ranking fields have non-empty and at most three entries
    assert all(
        0 < len(value) <= 3
        for value in (rjs["top_actions"], rjs["top_intents"], rjs["top_policies"])
    )
    # make sure counter fields have non-zero values
    assert all(value > 0 for value in (rjs["bot_messages"], rjs["user_messages"]))


def test_api_stack_user_analytics(auth_header):
    url = "http://rasa-x:5002/api/analytics"
    cache_control_header = auth_header.copy()
    cache_control_header["Cache-Control"] = "max-age=0"
    analytics_keys = {
        "conversations",
        "new_users",
        "user_messages",
        "bot_messages",
        "total_messages",
        "sessions_per_user",
        "conversation_length",
        "conversation_steps",
    }
    result_keys = analytics_keys.copy()
    result_keys.update({"bin_centers", "bin_width"})

    # receive user analytics
    response = requests.get(url, headers=cache_control_header)
    assert set(response.json().keys()) == result_keys
    assert all(len(v) == 10 for k, v in response.json().items() if k in analytics_keys)
    assert response.headers.get("X-Cache") == "MISS"

    # receive user analytics with good start and end date
    response = requests.get(
        url + "?start=2015-01-01&end=2030-01-25", headers=cache_control_header
    )

    assert all(len(v) == 10 for k, v in response.json().items() if k in analytics_keys)
    assert all(
        any(e != 0 for e in v)
        for k, v in response.json().items()
        if k in analytics_keys
    )
    assert response.headers.get("X-Cache") == "MISS"

    # do not receive user analytics with start date in the future
    response = requests.get(url + "?start=2030-01-01", headers=cache_control_header)
    assert all(len(v) == 10 for k, v in response.json().items() if k in analytics_keys)
    assert all(
        all(e == 0 for e in v)
        for k, v in response.json().items()
        if k in analytics_keys
    )
    assert response.headers.get("X-Cache") == "MISS"

    # do not receive user analytics with end date in the past
    response = requests.get(url + "?end=2000-01-01", headers=cache_control_header)
    assert all(len(v) == 10 for k, v in response.json().items() if k in analytics_keys)
    assert all(
        all(e == 0 for e in v)
        for k, v in response.json().items()
        if k in analytics_keys
    )
    assert response.headers.get("X-Cache") == "MISS"

    # Test the window parameter. The normal request should give us 10 bins,
    # the same request with a 0.01-s window should give us many more.
    response = requests.get(url, headers=cache_control_header)
    assert all(len(v) == 10 for k, v in response.json().items() if k in analytics_keys)
    assert all(
        any(e != 0 for e in v)
        for k, v in response.json().items()
        if k in analytics_keys
    )
    assert response.headers.get("X-Cache") == "MISS"

    response = requests.get(url + "?window=PT0.01S", headers=cache_control_header)
    assert all(len(v) > 10 for k, v in response.json().items() if k in analytics_keys)
    assert response.headers.get("X-Cache") == "MISS"

    # request cached analytics result for 12 months, 30 days and 24 hours
    days_list = [365, 30, 1]
    for days in days_list:
        start_time = datetime.datetime.now() - datetime.timedelta(days=days)
        response = requests.get(
            url + "?start={}".format(start_time.strftime("%Y-%m-%dT%H:%M:%S")),
            headers=auth_header,
        )

        assert response.headers.get("X-Cache") == "HIT"


def test_stack_api_debug_logs(auth_header, user):
    url = "http://rasa-x:5002/api/user"
    response = requests.get(url, headers=auth_header)
    api_token = response.json().get("api_token")
    md_url = ("http://rasa-x:5002/api/conversations/{}?until={}&api_token={}").format(
        user["username"], time.time(), api_token
    )
    # we pass token is query param because it's opened in a new tab
    headers = {"Accept": "text/markdown"}

    response = requests.get(md_url, headers=headers)
    assert response.status_code == 200

    json_url = ("http://rasa-x:5002/api/conversations/{}?until={}&api_token={}").format(
        user["username"], time.time(), api_token
    )

    # we pass token in query param because it's opened in a new tab
    headers = auth_header.copy()
    headers["Accept"] = "application/json"
    response = requests.get(json_url, headers=headers)
    assert response.status_code == 200

    # send message to fill tracker, followed by a /restart
    send_url = "http://rasa-x:5002/api/conversations/{}/messages".format(
        user["username"]
    )
    for msg in ("hello", "/restart"):
        payload = {"message": msg}
        response = requests.post(send_url, headers=auth_header, json=payload)
        assert response.status_code == 200

    def check():
        history_url = json_url + "&history=true"
        response = requests.get(history_url)
        assert response.status_code == 200
        length_with_history = len(response.json()["events"])

        no_history_url = json_url + "&history=false"
        response = requests.get(no_history_url)
        assert response.status_code == 200
        length_without_history = len(response.json()["events"])
        assert length_with_history > length_without_history

    # TODO: this check is very model-dependent and fails frequently
    # repeat(check, attempts=10)


def test_api_run_test_evaluation(auth_header):
    import concurrent.futures

    with concurrent.futures.ProcessPoolExecutor() as x:
        t_before = time.time()
        test = x.submit(
            requests.put,
            "http://rasa-x:5002/api/projects/default/evaluations/{}".format(
                pytest.TRAINED_MODEL_NAME
            ),
            headers=auth_header,
        )

        status = x.submit(
            requests.get, "http://rasa-x:5002/api/health", headers=auth_header
        )

        time_after_status_result = time.time()
        assert (time_after_status_result - t_before) < 0.5

        assert test.result().status_code == 200

        rjs = test.result().json()
        assert set(rjs["intent_evaluation"].keys()) == {
            "report",
            "predictions",
            "precision",
            "f1_score",
            "accuracy",
            "timestamp",
        }


def test_api_evaluation(auth_header):
    evaluation_keys = {
        "report",
        "predictions",
        "precision",
        "f1_score",
        "accuracy",
        "timestamp",
    }
    item_url = "http://rasa-x:5002/api/projects/default/evaluations/{}".format(
        pytest.TRAINED_MODEL_NAME
    )
    response = requests.put(item_url, headers=auth_header)
    assert set(response.json()["intent_evaluation"].keys()) == evaluation_keys

    # do not refresh and use persisted result
    response = requests.get(item_url, headers=auth_header)
    assert response.status_code == 200
    assert set(response.json()["intent_evaluation"].keys()) == evaluation_keys

    # list evaluations
    collection_url = "http://rasa-x:5002/api/projects/default/evaluations"
    response = requests.get(collection_url, headers=auth_header)
    assert len(response.json()) == 1

    # delete evaluation result
    response = requests.delete(item_url, headers=auth_header)
    assert response.status_code == 204


def test_api_evaluation_api_token(auth_header):
    url = "http://rasa-x:5002/api/user"
    response = requests.get(url, headers=auth_header)
    api_token = response.json().get("api_token")

    evaluation_keys = {
        "report",
        "predictions",
        "precision",
        "f1_score",
        "accuracy",
        "timestamp",
    }
    item_url = (
        "http://rasa-x:5002/api/projects/default/evaluations/{}"
        "?api_token={}".format(pytest.TRAINED_MODEL_NAME, api_token)
    )
    response = requests.put(item_url)
    assert set(response.json()["intent_evaluation"].keys()) == evaluation_keys

    # do not refresh and use persisted result
    response = requests.get(item_url)
    assert response.status_code == 200
    assert set(response.json()["intent_evaluation"].keys()) == evaluation_keys

    # list evaluations
    collection_url = (
        "http://rasa-x:5002/api/projects/default/evaluations?"
        "api_token={}".format(api_token)
    )
    response = requests.get(collection_url)
    assert len(response.json()) == 1

    # delete evaluation result
    response = requests.delete(item_url)
    assert response.status_code == 204


def test_modify_config(auth_header):
    # update config to a new pipeline
    test_pipeline = "test_pipeline"
    _config = """
language: en
pipeline: {}
policies:
  - name: MemoizationPolicy
  - name: KerasPolicy
  - name: MappingPolicy
    """.format(
        test_pipeline
    )
    config_url = "http://rasa-x:5002/api/projects/default/settings"
    settings = {"config": _config}
    response = requests.put(config_url, headers=auth_header, json=settings)
    _config = response.json()
    assert response.status_code == 200
    assert "language: en" in _config["config"]
    assert "pipeline: {}".format(test_pipeline) in _config["config"]

    # update again to supervised embeddings
    supervised_embeddings_pipeline = "supervised_embeddings"
    _config = """
language: en
pipeline: {}
policies:
  - name: MemoizationPolicy
  - name: KerasPolicy
  - name: MappingPolicy
        """.format(
        supervised_embeddings_pipeline
    )
    config_url = "http://rasa-x:5002/api/projects/default/settings"
    settings = {"config": _config}
    response = requests.put(config_url, headers=auth_header, json=settings)
    _config = response.json()
    assert response.status_code == 200
    assert "language: en" in _config["config"]
    assert "pipeline: {}".format(supervised_embeddings_pipeline) in _config["config"]

    # train tf_embedding pipeline
    time.sleep(1)
    train_url = "http://rasa-x:5002/api/projects/default/models/jobs"
    response = requests.post(train_url, headers=auth_header)
    train = response.json()
    assert response.status_code == 200
    assert "new model trained" in train["info"]


def test_tag_stack_model(auth_header):
    tag_url = "http://rasa-x:5002/api/projects/default/models/{}/tags/mytag".format(
        TEST_STACK_MODEL
    )
    tag_response = requests.put(tag_url, headers=auth_header)
    assert tag_response.status_code == 204


def test_get_stack_models(auth_header):
    url = "http://rasa-x:5002/api/projects/default/models"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert len(response.json())
    assert set(response.json()[0].keys()) == {
        "version",
        "path",
        "trained_at",
        "hash",
        "project",
        "tags",
        "model",
        "is_compatible",
    }

    # make sure model has version and is compatible
    assert response.json()[0]["is_compatible"]
    assert response.json()[0]["version"]


def test_stack_model_download(auth_header):
    # request model and download it
    url = "http://rasa-x:5002/api/projects/default/models/tags/mytag"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert response.headers.get("ETag") is not None

    # remember this model hash so we can use it in the next request's
    # If-None-Match header
    model_hash = response.headers.get("ETag")
    auth_header.update({"If-None-Match": model_hash})
    response = requests.get(url, headers=auth_header)
    # now we don't expect to get the model back
    assert response.status_code == 204


def test_stack_model_download_fails(auth_header):
    url = "http://rasa-x:5002/api/projects/default/models/tags/nonexistenttag"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 404


def test_stack_model_untag(auth_header):
    delete_tag = (
        "http://rasa-x:5002/api/projects/default/models/"
        "{}/tags/mytag".format(TEST_STACK_MODEL)
    )
    delete_response = requests.delete(delete_tag, headers=auth_header)
    assert delete_response.status_code == 204


def test_delete_stack_model(auth_header):
    delete_url = "http://rasa-x:5002/api/projects/default/models/{}".format(
        TEST_STACK_MODEL
    )
    delete_response = requests.delete(delete_url, headers=auth_header)
    assert delete_response.status_code == 204


def test_api_upload_additional_training_features(
    auth_header, training_data, training_data_with_additional_features
):
    features = {"common_examples", "regex_features", "lookup_tables"}
    # upload training data containing additional features
    response = requests.put(
        "http://rasa-x:5002/api/projects/default/data",
        headers=auth_header,
        json=training_data_with_additional_features,
    )
    assert response.status_code == 200

    # download data and check features are still there
    response = requests.get(
        "http://rasa-x:5002/api/projects/default/data.json", headers=auth_header
    )
    assert response.status_code == 200
    response_rasa_nlu_data = response.json()["rasa_nlu_data"]
    rasa_nlu_data = training_data_with_additional_features["rasa_nlu_data"]
    for feature in features:
        assert len(response_rasa_nlu_data[feature]) == len(rasa_nlu_data[feature])
        for downloaded_feature in response_rasa_nlu_data[feature]:
            assert downloaded_feature in rasa_nlu_data[feature]

    # upload standard data again without features
    response = requests.put(
        "http://rasa-x:5002/api/projects/default/data",
        headers=auth_header,
        json=training_data,
    )
    assert response.status_code == 200

    # download data and make sure features are gone
    response = requests.get(
        "http://rasa-x:5002/api/projects/default/data.json", headers=auth_header
    )
    assert response.status_code == 200
    response_rasa_nlu_data = response.json()["rasa_nlu_data"]
    rasa_nlu_data = training_data["rasa_nlu_data"]
    assert not response_rasa_nlu_data.get("regex_features")
    assert not response_rasa_nlu_data.get("entity_synonyms")
    assert not response_rasa_nlu_data.get("lookup_tables")
    assert len(rasa_nlu_data["common_examples"]) == len(
        response_rasa_nlu_data["common_examples"]
    )
    for ex in rasa_nlu_data["common_examples"]:
        assert ex in response_rasa_nlu_data["common_examples"]


def test_api_nlu_train_with_emojis(auth_header, training_data_with_emojis):
    # upload training data containing emojis
    response = requests.put(
        "http://rasa-x:5002/api/projects/default/data",
        headers=auth_header,
        json=training_data_with_emojis,
    )
    assert response.status_code == 200

    # train model
    train = requests.post(
        "http://rasa-x:5002/api/projects/default/models/jobs", headers=auth_header
    )
    assert train.status_code == 200
    assert "new model trained" in train.json()["info"]


def test_activate_deactivate_feature(auth_header):
    url = "http://rasa-x:5002/api/features"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    features = response.json()

    feature = next((f for f in features if f["enabled"] is False), None)

    if feature is None:
        return

    # set to True
    payload = {"name": feature["name"], "enabled": True}
    response = requests.post(url, json=payload, headers=auth_header)
    assert response.status_code == 200
    assert response.json() == payload

    # check next API call is consistent
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    features = response.json()
    assert payload in features

    # set back to False
    payload = {"name": feature["name"], "enabled": False}
    response = requests.post(url, json=payload, headers=auth_header)
    assert response.status_code == 200
    assert response.json() == payload


def test_empty_flagged_messages(auth_header):
    url = "http://rasa-x:5002/api/conversations/myid"
    response = requests.get(url, headers=auth_header)
    assert response.json()["flagged_messages"] == []


def test_query_for_flagged_conversations_with_no_flagged_messages(auth_header):
    url = "http://rasa-x:5002/api/conversations"
    response = requests.get(url, params={"is_flagged": False}, headers=auth_header)

    assert len(response.json()) > 0

    response = requests.get(url, params={"is_flagged": True}, headers=auth_header)

    assert len(response.json()) == 0


def test_add_conversation_flag(auth_header):
    response = requests.get(
        "http://rasa-x:5002/api/conversations/myid", headers=auth_header
    )
    assert response.status_code == 200
    time_of_first_event = response.json()["events"][0]["timestamp"]
    url = "http://rasa-x:5002/api/conversations/myid/messages/{}/flag".format(
        time_of_first_event
    )

    response = requests.put(url, headers=auth_header)
    assert response.status_code == 201

    def check():
        response = requests.get(
            "http://rasa-x:5002/api/conversations/myid", headers=auth_header
        )
        content = response.json()
        assert abs(content["flagged_messages"][0] - [time_of_first_event][0]) < 0.001

        assert any(e["is_flagged"] for e in content["events"])

        response = requests.get(
            "http://rasa-x:5002/api/conversations", headers=auth_header
        )
        content = response.json()
        conversation = next(filter(lambda c: c["sender_id"] == "myid", content))

        assert (
            abs(conversation["flagged_messages"][0] - [time_of_first_event][0]) < 0.001
        )
        assert conversation["unflagged_messages"] == []

    repeat(check, attempts=10)


def test_query_for_flagged_conversations_with_flagged_messages(auth_header):
    url = "http://rasa-x:5002/api/conversations"
    response = requests.get(url, params={"is_flagged": True}, headers=auth_header)

    assert len(response.json()) == 1


def test_delete_flag(auth_header):
    response = requests.get(
        "http://rasa-x:5002/api/conversations/myid", headers=auth_header
    )
    time_of_first_event = response.json()["events"][0]["timestamp"]

    url = "http://rasa-x:5002/api/conversations/myid/messages/{}/flag".format(
        time_of_first_event
    )

    response = requests.delete(url, headers=auth_header)

    assert response.status_code == 200

    def check():
        response = requests.get(
            "http://rasa-x:5002/api/conversations/myid", headers=auth_header
        )
        content = response.json()

        assert content["flagged_messages"] == []
        assert content["events"][0]["is_flagged"] is False

        response = requests.get(
            "http://rasa-x:5002/api/conversations", headers=auth_header
        )
        content = response.json()
        conversation = next(filter(lambda c: c["sender_id"] == "myid", content))

        assert conversation["flagged_messages"] == []
        assert (
            abs(conversation["unflagged_messages"][0] - [time_of_first_event][0])
            < 0.001
        )

    repeat(check)


def test_query_for_conversations_without_self(user, auth_header):
    url = "http://rasa-x:5002/api/conversations"
    response = requests.get(url, params={"exclude_self": True}, headers=auth_header)

    assert response.status_code == 200
    assert user["username"] not in [e["sender_id"] for e in response.json()]


def test_update_templates(auth_header):
    url = "http://rasa-x:5002/api/templates"
    templates = [
        {"template": "utter_greet", "text": "hello hello"},
        {"template": "utter_goodbye", "text": "peace out"},
    ]

    response = requests.put(url, json=templates, headers=auth_header)
    assert response.status_code == 200

    get_response = requests.get("http://rasa-x:5002/api/templates", headers=auth_header)
    assert get_response.status_code == 200
    updated_templates = get_response.json()

    assert updated_templates is not None

    assert all(
        dict(template=t["template"], text=t["text"]) in templates
        for t in updated_templates
    )


def test_list_roles(auth_header):
    response = requests.get("http://rasa-x:5002/api/roles", headers=auth_header)
    assert response.status_code == 200
    assert set(role["role"] for role in response.json()) == {ADMIN, TESTER, ANNOTATOR}


def test_create_role(auth_header):
    payload = {"role": "meister", "grants": {"conversations": ["read:any"]}}
    response = requests.post(
        "http://rasa-x:5002/api/roles", json=payload, headers=auth_header
    )
    assert response.status_code == 201
    assert response.text == "Role 'meister' created."


def test_update_role(auth_header):
    payload = {
        "role": "chief",
        "grants": {
            "deployment_environment": [
                "create:any",
                "update:any",
                "delete:any",
                "read:any",
            ],
            "test_conversation": ["read:any"],
        },
    }
    response = requests.put(
        "http://rasa-x:5002/api/roles/meister", json=payload, headers=auth_header
    )
    assert response.status_code == 200
    assert response.json()["role"] == payload["role"]
    for k, v in payload["grants"].items():
        assert response.json()["grants"][k] == v


def test_create_user(auth_header):
    payload = {"username": "paula", "password": "superPW100", "roles": [ANNOTATOR]}

    url = "http://rasa-x:5002/api/users"
    response = requests.post(url, json=payload, headers=auth_header)
    assert response.status_code == 201
    assert response.json()["username"] == payload["username"]


def test_get_role_users(auth_header):
    response = requests.get(
        "http://rasa-x:5002/api/roles/annotator/users", headers=auth_header
    )
    assert response.status_code == 200
    assert "paula" in [u["username"] for u in response.json()]


def test_update_role_users(auth_header):
    # create role
    new_role = "new_role"
    payload = {"role": new_role, "grants": {"conversations": ["read:any"]}}
    response = requests.post(
        "http://rasa-x:5002/api/roles", json=payload, headers=auth_header
    )
    assert response.status_code == 201
    assert response.text == "Role 'new_role' created."

    # update users associated with that role
    # we'll use the current annotator users
    response = requests.get(
        "http://rasa-x:5002/api/roles/annotator/users", headers=auth_header
    )
    new_role_users = [u["username"] for u in response.json()]

    response = requests.put(
        "http://rasa-x:5002/api/roles/{}/users".format(new_role),
        json=new_role_users,
        headers=auth_header,
    )
    assert response.status_code == 200
    assert all(new_role in user["roles"] for user in response.json())


def test_get_role_users_fail(auth_header):
    response = requests.get(
        "http://rasa-x:5002/api/roles/HansHase/users", headers=auth_header
    )
    assert response.status_code == 404


def test_get_role(session, auth_header):
    response = requests.get(
        "http://rasa-x:5002/api/roles/annotator", headers=auth_header
    )
    assert response.status_code == 200

    rjs = response.json()
    role_service = RoleService(session)
    expected = role_service.backend_to_frontend_format_roles([ANNOTATOR])[0]

    assert rjs == expected


def test_get_role_fail(auth_header):
    response = requests.get(
        "http://rasa-x:5002/api/roles/HansHase", headers=auth_header
    )
    assert response.status_code == 404


def test_delete_role(auth_header, session):
    response = requests.delete(
        "http://rasa-x:5002/api/roles/chief", headers=auth_header
    )
    assert response.status_code == 204

    # ensure role has been deleted in role service
    assert "chief" not in RoleService(session).roles


def test_delete_role_fail(tester_role_user, auth_header):
    # delete non existing role
    response = requests.delete(
        "http://rasa-x:5002/api/roles/hoppelhase", headers=auth_header
    )
    assert response.status_code == 404

    # can't delete own role
    response = requests.delete(
        "http://rasa-x:5002/api/roles/{}".format(tester_role_user["username"]),
        headers=auth_header,
    )
    assert response.status_code == 404


def test_update_chat_token_and_jwt(auth_header):
    url = "http://rasa-x:5002/api/chatToken"
    payload = {"bot_name": "Karl", "description": "your friendly bot"}
    response = requests.put(url, json=payload, headers=auth_header)
    assert response.status_code == 200
    assert response.json()["bot_name"] == "Karl"

    token = response.json()["chat_token"]
    assert len(token) == len(uuid4().hex)

    # test issue signed jwt
    url = "http://rasa-x:5002/api/auth/jwt"
    payload = {"conversation_id": "Pipi", "chat_token": token}
    response = requests.post(url, json=payload)
    assert response.status_code == 200
    assert response.json().get("access_token") is not None


def test_get_chat_token(auth_header):
    url = "http://rasa-x:5002/api/chatToken"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert response.json()["bot_name"] == "Karl"
    assert len(response.json()["chat_token"]) == len(uuid4().hex)
    assert response.json()["description"] == "your friendly bot"


@pytest.mark.parametrize("environment_string", ["production", "development"])
def test_chat_to_bot(auth_header, environment_string):
    url = "http://rasa-x:5002/api/chat?environment={}".format(environment_string)
    payload = {"message": "hello"}
    response = requests.post(url, headers=auth_header, json=payload)
    assert response.status_code == 200


def test_upload_domain(auth_header, domain_yaml):
    url = "http://rasa-x:5002/api/domain"
    response = requests.put(url, headers=auth_header, data=domain_yaml)
    assert response.status_code == 200


def test_get_domain(auth_header, domain_yaml):
    url = "http://rasa-x:5002/api/domain"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200

    expected = read_yaml(domain_yaml)
    actual = read_yaml(response.text)

    # intents and actions should be the same
    # templates are not as they've been updated in previous tests
    for key in ["intents", "actions"]:
        assert actual[key] == expected[key]


def test_domain_actions(auth_header):
    url = "http://rasa-x:5002/api/projects/default/actions"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert response.json()


def test_create_action(auth_header):
    url = "http://rasa-x:5002/api/projects/default/actions"
    action_name = "my new action"
    action = {"name": action_name}
    response = requests.post(url, json=action, headers=auth_header)

    assert response.status_code == 201
    assert response.json()["id"]

    response = requests.get(url, headers=auth_header)
    assert action_name in response.json()


def test_update_action(auth_header):
    url = "http://rasa-x:5002/api/projects/default/actions"
    action_name = "test_update_action"
    action = {"name": action_name}
    response = requests.post(url, json=action, headers=auth_header)

    action_id = response.json()["id"]
    updated_name = "test_update_action2"
    response = requests.put(
        url + "/" + str(action_id), json={"name": updated_name}, headers=auth_header
    )

    assert response.status_code == 200
    response = requests.get(url, headers=auth_header)

    assert response.status_code == 200
    assert action_name not in response.json()
    assert updated_name in response.json()


def test_delete_action(auth_header):
    url = "http://rasa-x:5002/api/projects/default/actions"
    action_name = "test_delete_action"
    action = {"name": action_name}
    response = requests.post(url, json=action, headers=auth_header)

    action_id = response.json()["id"]
    response = requests.delete(url + "/" + str(action_id), headers=auth_header)
    assert response.status_code == 204

    response = requests.get(url, headers=auth_header)

    assert response.status_code == 200
    assert action_name not in response.json()


def test_domain_warnings(auth_header):
    url = "http://rasa-x:5002/api/domainWarnings"
    response = requests.get(url, headers=auth_header)
    assert response.status_code == 200
    assert all(
        e in response.json()
        for e in [
            "intent_warnings",
            "action_warnings",
            "entity_warnings",
            "slot_warnings",
        ]
    )


def test_create_custom_response_no_text(auth_header):
    url = "http://rasa-x:5002/api/templates"
    template = {
        "custom": [
            {
                "requestedEntity": "None",
                "response": {"message": "Please find the doctors details"},
            }
        ],
        "template": "utter_result",
    }
    response = requests.post(url, json=template, headers=auth_header)
    assert response.status_code == 201
    actual = response.json()
    assert actual.get("template") is not None
    assert all([actual[k] == template[k] for k in template])


def test_create_custom_response_with_text(auth_header):
    url = "http://rasa-x:5002/api/templates"
    template = {
        "custom": [
            {
                "requestedEntity": "None",
                "response": {"message": "Please find the doctors details"},
            }
        ],
        "template": "utter_result",
        "text": "test",
    }
    response = requests.post(url, json=template, headers=auth_header)
    assert response.status_code == 201
    actual = response.json()
    assert actual.get("template") is not None
    assert all([actual[k] == template[k] for k in template])
