import time
from typing import Dict, Text, Any, Optional, List
from uuid import uuid4

import pytest
from sqlalchemy.orm import Session

import rasax.community.config as platform_config
import rasax.community.sql_migrations as migrations
from rasa.core.events import UserUttered
from rasa.utils.endpoints import EndpointConfig
from rasax.community.services.analytics_service import AnalyticsService
from rasax.community.services.data_service import DataService
from rasax.community.services.domain_service import DomainService
from rasax.community.services.event_service import EventService
from rasax.community.services.feature_service import FeatureService
from rasax.community.services.intent_service import IntentService
from rasax.community.services.logs_service import LogsService
from rasax.community.services.model_service import ModelService
from rasax.community.services.nlg_service import NlgService
from rasax.community.services.evaluation_service import EvaluationService
from rasax.community.services.role_service import RoleService
from rasax.community.services.settings_service import SettingsService
from rasax.community.services.stack_service import StackService
from rasax.community.services.story_service import StoryService
from rasax.community.services.user_goal_service import UserGoalService
from rasax.community.services.user_service import UserService, ADMIN
from rasax.community.config import team_name

UUID = uuid4().hex

TEST_USER = "some_user"
NLU_DATA_PATH = "tests/unit/demo-rasa.md"
STORY_PATH = "tests/unit/stories.md"
TEST_STACK_URL = "http://stack-service.com"
TEST_PROJECT = "project"


@pytest.fixture(scope="module")
def session():
    from rasax.community.database.utils import create_session_maker
    import rasax.community.utils

    inmemory_sqlite_database = "sqlite://"
    session_maker = create_session_maker(inmemory_sqlite_database)
    session = session_maker()

    # Allow multiple user creation for tests
    rasax.community.utils.is_enterprise_installed = lambda: True

    migrations.run_migrations(session)

    # Insert general test user which can be used in later tests
    insert_test_user(session, TEST_USER)

    session = session_maker()
    yield session
    session.commit()
    session.close()


@pytest.fixture(scope="module")
def data_service(session):
    # mock data dumping
    DataService._dump_data_in_local_mode = lambda _: True

    data_service = DataService(session)

    return data_service


@pytest.fixture(scope="module")
def role_service(session):
    return RoleService(session)


@pytest.fixture(scope="module")
def user_service(session):
    return UserService(session)


@pytest.fixture(scope="module")
def user_goal_service(session):
    return UserGoalService(session)


@pytest.fixture(scope="module")
def settings_service(session) -> SettingsService:
    return SettingsService(session)


@pytest.fixture(scope="module")
def domain_service(session) -> DomainService:
    return DomainService(session)


@pytest.fixture(scope="module")
def model_service(session) -> ModelService:
    return ModelService("path", session, "production")


@pytest.fixture(scope="module")
def logs_service(session):
    return LogsService(session)


@pytest.fixture(scope="module")
def intent_service(session):
    return IntentService(session)


@pytest.fixture(scope="module")
def event_service(session):
    return EventService(session)


@pytest.fixture(scope="module")
def analytics_service(session):
    return AnalyticsService(session)


@pytest.fixture(scope="module")
def nlg_service(session):
    return NlgService(session)


@pytest.fixture(scope="module")
def story_service(session):
    return StoryService(session)


@pytest.fixture(scope="module")
def feature_service(session):
    return FeatureService(session)


@pytest.fixture(scope="module")
def evaluation_service(session):
    return EvaluationService(None, session)


@pytest.fixture(scope="module")
def stack_service(session) -> StackService:
    # TODO: create an actual Rasa service that runs as a background process
    _config = EndpointConfig(TEST_STACK_URL)
    return StackService(
        _config,
        DataService(session),
        StoryService(session),
        DomainService(session),
        SettingsService(session),
    )


@pytest.fixture(scope="module")
def user(session) -> Dict[Text, Any]:
    user_service = UserService(session)
    user_service.create_user("test user", "password", platform_config.team_name, ADMIN)
    return user_service.fetch_user("test user")


@pytest.fixture(scope="session")
def config():
    return """
    language: "en"
    pipeline: "spacy_sklearn"
    """


def _user_event(
    sender_id: Text,
    timestamp: float = 0,
    intent: Text = "test",
    project: Text = "default",
    text: Text = "hello",
    entities: Optional[List] = None,
) -> Dict[Text, Any]:
    return {
        "sender_id": sender_id,
        "timestamp": timestamp,
        "event": UserUttered.type_name,
        "text": text,
        "input_channel": "rest",
        "parse_data": {
            "intent": {"name": intent},
            "entities": entities or [],
            "project": project,
            "text": text,
        },
    }


def _action_event(
    sender_id,
    timestamp=0,
    action_name="action",
    policy="policy",
    confidence=1.0,
    event_type="action",
):
    return {
        "sender_id": sender_id,
        "policy": policy,
        "confidence": confidence,
        "event": event_type,
        "name": action_name,
        "timestamp": timestamp,
    }


def _bot_event(sender_id, timestamp):
    return _action_event(sender_id, timestamp, event_type="bot")


def insert_test_model(
    project_name, model_name, model_service, stored_path=None, training_time=time.time()
):
    expected = {
        "project": project_name,
        "model_name": model_name,
        "stored_path": stored_path or uuid4().hex,
        "model_hash": "hash",
        "_version": "1.0",
        "training_time": training_time,
    }

    model_service._save_model_data(**expected)

    return expected


def insert_test_user(
    session: Session,
    username: Text,
    team: Text = platform_config.team_name,
    role: Text = ADMIN,
):
    user_service = UserService(session)
    user_service.create_user(username, "password", team, role)
    session.commit()  # commit session in case services using another session rely on it


def user_dict(username=TEST_USER):
    return {"username": username}


@pytest.fixture
def new_project(settings_service: SettingsService):
    project = "{}-{}".format(TEST_PROJECT, uuid4().hex)
    settings_service.init_project(team_name, project)
    return project
