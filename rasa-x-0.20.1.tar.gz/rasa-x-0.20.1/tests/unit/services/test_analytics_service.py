import json
import pytest

from rasax.community.database.analytics import ConversationSession
from rasax.community.services.analytics_service import AnalyticsService
import rasax.community.services.analytics_service as analytics
from rasax.community.services.event_service import EventService
from tests.unit.conftest import _user_event, _bot_event


@pytest.fixture()
def analytics_service(session) -> AnalyticsService:
    session.query(ConversationSession).delete()
    session.commit()
    return AnalyticsService(session)


def test_session_creation(
    analytics_service: AnalyticsService, event_service: EventService
):
    user1 = "test_user"

    # Test initial session creation
    events = [_user_event(user1, 1), _bot_event(user1, 11)]

    for e in events:
        event_service.save_event(json.dumps(e))
        analytics_service.save_analytics(json.dumps(e))

    saved_session = analytics_service._latest_session(user1)

    assert saved_session.session_start == 1
    assert saved_session.user_messages == 1
    assert saved_session.bot_messages == 1
    assert saved_session.session_length == 10

    # Test creation of second session
    events = [
        _user_event(user1, analytics.SESSION_TIMEOUT + 11 + 1),
        _user_event(user1, analytics.SESSION_TIMEOUT + 12 + 1),
    ]

    for e in events:
        event_service.save_event(json.dumps(e))
        analytics_service.save_analytics(json.dumps(e))

    saved_session = analytics_service._latest_session(user1)

    assert saved_session.session_start == analytics.SESSION_TIMEOUT + 12
    assert saved_session.user_messages == 2
    assert saved_session.bot_messages == 0
    assert saved_session.session_length == 1


def test_analytics_calculation(
    analytics_service: AnalyticsService, event_service: EventService
):
    # For testing purposes we set the to sth smaller
    analytics.SESSION_TIMEOUT = 25

    user1 = "test-sender-1"

    # Try analytics with one initial user
    events = [
        _user_event(user1, 1001),
        _bot_event(user1, 1011),
        _user_event(user1, 1015),
        _bot_event(user1, 1021),
    ]

    for e in events:
        event_service.save_event(json.dumps(e))
        analytics_service.save_analytics(json.dumps(e))

    actual = analytics_service.calculate_analytics(start=1001, until=1021, window=10)

    assert actual == {
        "bin_centers": [1006.0, 1016.0],
        "bin_width": 10,
        "new_users": [1, 0],
        "conversations": [1, 0],
        "user_messages": [2, 0],
        "bot_messages": [2, 0],
        "total_messages": [4, 0],
        "sessions_per_user": [1, 0],
        "conversation_length": [20.0, 0],
        "conversation_steps": [2.0, 0],
    }

    # Lets add new users and let the old user start a new session
    user2 = "test-sender-2"
    user3 = "test_sender-3"
    events = [
        _user_event(user2, 1100),
        _bot_event(user2, 1115),
        _bot_event(user2, 1141),
        _user_event(user1, 1100),
        _bot_event(user1, 1149),
        _user_event(user3, 1100),
        _user_event(user3, 1140),
    ]

    for e in events:
        event_service.save_event(json.dumps(e))
        analytics_service.save_analytics(json.dumps(e))

    actual = analytics_service.calculate_analytics(start=1000, until=1150, window=50)
    assert actual == {
        "bin_centers": [1025.0, 1075.0, 1125.0],
        "bin_width": 50,
        "new_users": [1, 0, 2],
        "conversations": [1, 0, 3],
        "user_messages": [2, 0, 4],
        "bot_messages": [2, 0, 3],
        "total_messages": [4, 0, 7],
        "sessions_per_user": [1, 0, 2],
        "conversation_length": [20.0, 0, 2.5],
        "conversation_steps": [2.0, 0, 0.6666666666666666],
    }


def test_analytics_with_excluded_sender_ids(
    analytics_service: AnalyticsService, event_service: EventService
):
    user1 = "to be excluded"
    events = [
        _user_event(user1, 1),
        _bot_event(user1, 11),
        _user_event(user1, 15),
        _bot_event(user1, 21),
    ]

    for e in events:
        event_service.save_event(json.dumps(e))
        analytics_service.save_analytics(json.dumps(e))

    actual = analytics_service.calculate_analytics(
        start=0, until=100, window=50, sender_ids_to_exclude=[user1]
    )

    assert actual == {
        "bin_centers": [25.0, 75.0],
        "bin_width": 50,
        "new_users": [0, 0],
        "conversations": [0, 0],
        "user_messages": [0, 0],
        "bot_messages": [0, 0],
        "total_messages": [0, 0],
        "sessions_per_user": [0, 0],
        "conversation_length": [0, 0],
        "conversation_steps": [0, 0],
    }


def test_analytics_caching(
    analytics_service: AnalyticsService, event_service: EventService
):
    user1 = "test user"
    events = [
        _user_event(user1, 1),
        _bot_event(user1, 11),
        _user_event(user1, 15),
        _bot_event(user1, 21),
    ]

    for e in events:
        event_service.save_event(json.dumps(e))
        analytics_service.save_analytics(json.dumps(e))

    analytics_result = analytics_service.calculate_analytics(
        start=0, until=100, window=50
    )

    test_cache_key = "key"
    analytics_service._persist_analytics(test_cache_key, analytics_result)

    actual = analytics_service.get_cached_analytics_result(test_cache_key)

    assert actual["timestamp"] > 0
    assert actual["key"] == test_cache_key
    assert actual["result"] == analytics_result


def test_excluding_of_events_before_and_after_selected_window(
    analytics_service: AnalyticsService, event_service: EventService
):
    # For testing purposes we set the to sth smaller
    analytics.SESSION_TIMEOUT = 25

    user1 = "test-sender-1"

    # Try analytics with one initial user
    events = [
        _user_event(user1, 900),  # event before the selected window
        _user_event(user1, 1001),
        _bot_event(user1, 1011),
        _user_event(user1, 1015),
        _bot_event(user1, 1021),
        _bot_event(user1, 1100),
    ]  # event after selected window

    for e in events:
        event_service.save_event(json.dumps(e))
        analytics_service.save_analytics(json.dumps(e))

    actual = analytics_service.calculate_analytics(start=1001, until=1021, window=10)

    assert actual == {
        "bin_centers": [1006.0, 1016.0],
        "bin_width": 10,
        "new_users": [0, 0],  # the user is not new anymore
        "conversations": [1, 0],
        "user_messages": [2, 0],
        "bot_messages": [2, 0],
        "total_messages": [4, 0],
        "sessions_per_user": [1, 0],
        "conversation_length": [20.0, 0],
        "conversation_steps": [2.0, 0],
    }
