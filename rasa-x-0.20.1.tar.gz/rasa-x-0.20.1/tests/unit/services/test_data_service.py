from rasa.nlu.training_data.formats import MarkdownReader, RasaReader

from rasax.community import config
from rasax.community.services.data_service import DataService
from rasax.community.services.domain_service import DomainService
from rasax.community.services.intent_service import INTENT_EXAMPLES_KEY
from rasax.community.services.story_service import StoryService
from tests.unit.conftest import NLU_DATA_PATH
from tests.unit.conftest import TEST_USER, user_dict

TEST_PROJECT = config.project_name

TEST_EXAMPLE = {
    "text": "a great example",
    "intent": "testing",
    "entities": [{"start": 0, "end": 1, "value": "indefinite", "entity": "article"}],
    "team": "team",
    "project_id": "my_project",
}

TEST_RESULT = {
    "id": 1,
    "text": TEST_EXAMPLE["text"],
    "entities": TEST_EXAMPLE["entities"],
    "intent": TEST_EXAMPLE["intent"],
    "hash": "51601e6f1383c5bc88ff25bfaa080a20",
    "annotation": {"user": TEST_USER},
}

EXAMPLE_DATA_MD = """
## intent:check_balance
- what is my balance
- how much do I have on my [savings](source_account)
- how much do I have on my [savings account](source_account:savings)
- Could I pay in [yen](currency)?

## intent:greet
- hey
- hello

## synonym:savings
- pink pig

## regex:zipcode
- [0-9]{5}

## lookup:currencies
- Yen
- USD
- Euro
"""


def test_save_example(data_service: DataService):
    save_result = data_service.save_example(
        user_dict()["username"], TEST_PROJECT, TEST_EXAMPLE
    )

    actual, number_examples = data_service.get_training_data(TEST_PROJECT)

    assert number_examples == 1
    assert save_result == actual[0]
    assert actual[0]["annotation"].pop("time") > 0
    assert actual[0] == TEST_RESULT


def test_save_example_if_it_already_exists(data_service: DataService):
    updated_example = TEST_EXAMPLE.copy()
    updated_intent = "another intent"
    updated_example["intent"] = updated_intent

    data_service.save_example(user_dict()["username"], TEST_PROJECT, updated_example)

    expected = TEST_RESULT.copy()
    expected["intent"] = updated_intent

    actual, number_examples = data_service.get_training_data(TEST_PROJECT)

    assert number_examples == 1
    assert actual[0]["annotation"].pop("time") > 0
    assert actual[0] == expected


def test_get_by_hash(data_service: DataService):
    data_service.save_example(user_dict()["username"], TEST_PROJECT, TEST_EXAMPLE)
    actual = data_service.get_example_by_hash(TEST_PROJECT, TEST_RESULT["hash"])

    assert actual["annotation"].pop("time") > 0
    assert actual == TEST_RESULT


def test_get_by_intent_query(data_service: DataService):
    data_service.save_example(user_dict()["username"], TEST_PROJECT, TEST_EXAMPLE)
    intent_query = "some intent,other_intent,{}".format(TEST_EXAMPLE["intent"])

    actual, _ = data_service.get_training_data(TEST_PROJECT, intent_query=intent_query)

    assert actual[0]["annotation"].pop("time") > 0
    assert actual[0] == TEST_RESULT


def test_get_with_text_query(data_service: DataService):
    text_query = "great"

    actual, _ = data_service.get_training_data(TEST_PROJECT, text_query=text_query)

    assert actual[0]["annotation"].pop("time") > 0
    assert actual[0] == TEST_RESULT


def test_first_level_field_query(data_service: DataService):
    actual, _ = data_service.get_training_data(
        TEST_PROJECT, fields_query=[("text", True)]
    )
    assert actual[0] == {"text": TEST_EXAMPLE["text"]}


def test_relationship_field_query(data_service: DataService):
    actual, _ = data_service.get_training_data(
        TEST_PROJECT, fields_query=[("entities", True)]
    )
    assert actual[0] == {"entities": TEST_EXAMPLE["entities"]}


def test_relationship_subfield_query(data_service: DataService):
    actual, _ = data_service.get_training_data(
        TEST_PROJECT, fields_query=[("entities.entity", True)]
    )
    assert actual[0] == {"entities": TEST_EXAMPLE["entities"]}


def test_get_intents(data_service: DataService):
    actual = data_service.get_intents(TEST_PROJECT)

    assert actual == [
        {"intent": TEST_RESULT["intent"], INTENT_EXAMPLES_KEY: [TEST_RESULT["hash"]]}
    ]


def test_get_intents_without_example_hashes(data_service: DataService):
    actual = data_service.get_intents(TEST_PROJECT, include_example_hashes=False)

    assert actual == [{"intent": TEST_RESULT["intent"]}]


def test_update_intent(data_service: DataService):
    new_intent = "new intent"
    data_service.update_intent(new_intent, [TEST_RESULT["hash"]], TEST_PROJECT)

    assert data_service.get_intents(TEST_PROJECT) == [
        {"intent": new_intent, INTENT_EXAMPLES_KEY: [TEST_RESULT["hash"]]}
    ]


def test_replace_example(data_service: DataService):
    updated_example = TEST_EXAMPLE.copy()
    updated_example["text"] = "another text"

    data_service.replace_example(
        user_dict(), TEST_PROJECT, updated_example, TEST_RESULT["id"]
    )

    expected = TEST_RESULT.copy()
    expected["text"] = "another text"
    expected["hash"] = "2275675a128d775f75ea2c4f3ba6be46"

    actual, number_examples = data_service.get_training_data(TEST_PROJECT)

    assert number_examples == 1
    assert actual[0]["annotation"].pop("time") > 0
    assert actual[0] == expected


def test_get_entities(data_service: DataService):
    assert data_service.get_entities(TEST_PROJECT) == [
        {"entity": TEST_RESULT["entities"][0]["entity"]}
    ]


def test_get_warnings(data_service: DataService):
    expected = [
        {"type": "data", "min": 4, "count": 1},
        {"type": "intent", "min": 2, "count": 1, "meta": None},
        {"type": "dataPerIntent", "min": 2, "count": 1, "meta": "testing"},
    ]

    assert data_service.get_training_data_warnings(TEST_PROJECT) == expected


def test_delete_example(data_service: DataService):
    actual = data_service.delete_example(TEST_RESULT["id"])

    assert actual
    assert data_service.get_training_data(TEST_PROJECT) == ([], 0)


def test_delete_example_by_hash(data_service: DataService):
    data_service.save_example(user_dict()["username"], TEST_PROJECT, TEST_EXAMPLE)

    assert data_service.delete_example_by_hash(TEST_PROJECT, TEST_RESULT["hash"])
    assert data_service.get_training_data(TEST_PROJECT) == ([], 0)


def test_replace_additional_training_features(data_service: DataService):
    training_data = MarkdownReader().reads(EXAMPLE_DATA_MD)
    data_service.replace_additional_training_features(TEST_PROJECT, training_data)

    assert data_service.get_regex_features(TEST_PROJECT) == [
        {"name": "zipcode", "pattern": "[0-9]{5}"}
    ]
    assert data_service.get_lookup_tables(TEST_PROJECT) == [
        {"name": "currencies", "elements": ["Yen", "USD", "Euro"]}
    ]

    synonyms = data_service.get_entity_synonyms(TEST_PROJECT)
    assert synonyms[0]["value"] == "savings"
    assert set(synonyms[0]["synonyms"]) == {"pink pig", "savings account"}


def test_format_entity_synonyms(data_service: DataService):
    # insert example data
    training_data = MarkdownReader().reads(EXAMPLE_DATA_MD)
    data_service.replace_additional_training_features(TEST_PROJECT, training_data)

    # get entity synonyms and ensure RasaReader reads them correctly
    formatted_synonyms = data_service.get_entity_synonyms(TEST_PROJECT)
    assert formatted_synonyms
    training_data_json = {"rasa_nlu_data": {"entity_synonyms": formatted_synonyms}}
    training_data = RasaReader().read_from_json(training_data_json)
    assert training_data.entity_synonyms == {
        "savings account": "savings",
        "pink pig": "savings",
    }


def test_domain_items_from_nlu_data(
    data_service: DataService, domain_service: DomainService
):
    from tests.unit.services.test_domain_service import TEST_DOMAIN

    # ensure there is a domain
    domain_service.store_domain(
        TEST_DOMAIN, TEST_PROJECT, username=TEST_USER, store_templates=False
    )

    # add an example
    data_service.save_example(
        TEST_USER, TEST_PROJECT, TEST_EXAMPLE, add_example_items_to_domain=False
    )
    data_service.add_all_intents_and_entities_to_domain(TEST_PROJECT)

    domain_intents = domain_service.get_intents_from_domain(TEST_PROJECT)
    domain_entities = domain_service.get_entities_from_domain(TEST_PROJECT)

    # ensure domain contains example's entity and intent
    assert TEST_EXAMPLE["intent"] in domain_intents
    assert TEST_EXAMPLE["entities"][0]["entity"] in domain_entities


async def test_domain_items_from_story(
    story_service: StoryService, domain_service: DomainService
):
    from tests.unit.services.test_domain_service import TEST_DOMAIN

    # ensure there is a domain
    domain_service.store_domain(
        TEST_DOMAIN, TEST_PROJECT, username=TEST_USER, store_templates=False
    )

    # add a story
    intent = "some_intent1"
    action = "some_action1"
    story = """
    ## story1
    * {}
      - {}
    """.format(
        intent, action
    )
    await story_service.save_stories(
        story,
        "team",
        username=TEST_USER,
        dump_stories_in_local_mode=False,
        add_story_items_to_domain=True,
    )

    domain_actions = domain_service.get_actions_from_domain(TEST_PROJECT)
    domain_intents = domain_service.get_intents_from_domain(TEST_PROJECT)

    # ensure domain contain story action and intent
    assert action in domain_actions
    assert intent in domain_intents


def test_inject_data_from_file(data_service: DataService):
    # delete all data
    data_service.delete_data()
    assert not data_service.get_training_data(TEST_PROJECT)[0]

    # insert data from file
    data_service.save_bulk_data_from_files([NLU_DATA_PATH], TEST_PROJECT, TEST_USER)
    assert data_service.get_training_data(TEST_PROJECT)[0]


def test_entity_extractor_persistence(data_service: DataService):
    extractor = "some_extractor"
    test_example_with_extractor = TEST_EXAMPLE.copy()
    test_example_with_extractor["entities"][0]["extractor"] = extractor
    # modify text so it's saved as a new example
    new_text = "new_text"
    test_example_with_extractor["text"] = new_text

    # save example
    save_result = data_service.save_example(
        user_dict()["username"], TEST_PROJECT, test_example_with_extractor
    )

    # make sure extractor was saved
    actual, number_examples = data_service.get_training_data(
        TEST_PROJECT, text_query=new_text
    )
    assert number_examples == 1
    assert save_result == actual[0]
    assert actual[0]["entities"][0]["extractor"] == extractor
