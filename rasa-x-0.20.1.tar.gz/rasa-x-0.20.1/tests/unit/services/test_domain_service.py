import copy
from pathlib import Path
from typing import Text, Dict

import pytest

from rasa.core.domain import Domain
from rasa.core.slots import TextSlot, UnfeaturizedSlot
from rasax.community.config import team_name
from rasax.community.services.data_service import DataService
from rasax.community.services.nlg_service import NlgService
from rasax.community.services.domain_service import DomainService
from rasax.community.services.settings_service import SettingsService
from rasax.community.database.domain import Domain as DomainModel
from tests.unit.conftest import TEST_USER, TEST_PROJECT
from tests.unit.services.test_data_service import TEST_EXAMPLE

TEST_DOMAIN = {
    "actions": ["utter_1", "utter_2"],
    "config": {"store_entities_as_slots": True},
    "entities": ["number", "person"],
    "forms": ["test_form"],
    "intents": [
        {
            "intent_1": {
                "use_entities": True,
                "ignore_entities": [],
                "triggers": "utter_1",
            }
        },
        {"intent_2": {"use_entities": [], "ignore_entities": ["entity1"]}},
        {
            "intent_3": {
                "use_entities": ["entity1", "entity2"],
                "ignore_entities": ["entity3"],
            }
        },
        "intent_4",
    ],
    "slots": {
        "slot_1": {"auto_fill": True, "type": "rasa_core.slots.UnfeaturizedSlot"},
        "slot_2": {
            "auto_fill": True,
            "initial_value": "value1",
            "type": "rasa.core.slots.CategoricalSlot",
            "values": ["value1", "value2"],
        },
        "slot_3": {
            "auto_fill": True,
            "type": "rasa_core.slots.UnfeaturizedSlot",
            "initial_value": 0,
        },
    },
    "templates": {"utter_1": [{"text": "hello world"}]},
}

EXPECTED_DOMAIN = copy.deepcopy(TEST_DOMAIN)
EXPECTED_DOMAIN["intents"][3] = {
    "intent_4": {"ignore_entities": [], "use_entities": True}
}


def test_storing_of_domain(
    domain_service: DomainService, settings_service: SettingsService, new_project: Text
):
    settings_service.init_project(team_name, TEST_PROJECT)

    domain_service.store_domain(
        TEST_DOMAIN, TEST_PROJECT, username=TEST_USER, store_templates=True
    )

    actual = domain_service.get_domain(TEST_PROJECT)

    assert actual == EXPECTED_DOMAIN
    assert domain_service.get_domain_id(TEST_PROJECT) == 1

    # Save another domain for the same project and check whether old one
    # gets replaced correctly
    another_domain = copy.deepcopy(EXPECTED_DOMAIN)
    another_domain["actions"].append("utter_3")
    domain_service.store_domain(
        another_domain, TEST_PROJECT, username=TEST_USER, store_templates=True
    )

    actual = domain_service.get_domain(TEST_PROJECT)

    assert actual == another_domain


def test_storing_of_domain_without_storing_templates(domain_service: DomainService):
    domain_service.store_domain(
        TEST_DOMAIN, TEST_PROJECT, username=TEST_USER, store_templates=True
    )

    old_domain = domain_service.get_domain(TEST_PROJECT)
    new_domain = old_domain.copy()
    new_domain["templates"] = []

    domain_service.store_domain(new_domain, TEST_PROJECT, store_templates=False)

    actual = domain_service.get_domain(TEST_PROJECT)
    assert actual == old_domain


def test_storing_domain_yaml(domain_service: DomainService, new_project: Text):
    from rasa.core.domain import Domain as RasaDomain
    import copy

    # `Domain.from_dict` changes the passed in Dict.
    # Deepcopy object to avoid affecting other tests
    domain = RasaDomain.from_dict(copy.deepcopy(TEST_DOMAIN))

    domain_service.validate_and_store_domain_yaml(domain.as_yaml(), new_project)

    actual = domain_service.get_domain(new_project)

    expected = domain.cleaned_domain()
    expected.pop("templates")
    assert RasaDomain.from_dict(actual).cleaned_domain() == expected


async def test_no_domain(domain_service: DomainService, new_project: Text):
    assert domain_service.get_domain(new_project) is None
    assert domain_service.get_domain_yaml(new_project) is None
    assert await domain_service.get_domain_warnings(new_project) is None


def test_get_or_create_domain(domain_service: DomainService, new_project: Text):
    actual = domain_service.get_or_create_domain(new_project)
    assert actual is not None


def test_add_item_no_domain(domain_service: DomainService, new_project: Text):
    # add events to domain
    actions_to_add = {"new_action", "hello_1"}
    intents_to_add = {"new_intent", "hellohello"}
    slots_to_add = {"new_slot", "hello123"}
    entities_to_add = {"one", "two"}
    assert domain_service.get_domain(new_project) is None

    # Project does not have a domain - yet.
    domain_service.add_items_to_domain(
        actions=actions_to_add,
        intents=intents_to_add,
        entities=entities_to_add,
        slots=slots_to_add,
        project_id=new_project,
    )

    assert domain_service.get_domain(new_project) is not None

    read_actions = domain_service.get_actions_from_domain(new_project)
    read_intents = domain_service.get_intents_from_domain(new_project)
    read_entities = domain_service.get_entities_from_domain(new_project)
    read_slots = domain_service.get_slots_from_domain(new_project)
    assert actions_to_add == read_actions
    assert intents_to_add == read_intents
    assert entities_to_add == read_entities
    assert slots_to_add == read_slots


def test_empty_or_no_domain(domain_service: DomainService, new_project: Text):
    # Project has no domain
    assert domain_service.has_empty_or_no_domain(new_project)
    assert domain_service.get_domain_id() is None

    # Add an empty domain
    domain_service.get_or_create_domain(new_project)
    assert domain_service.has_empty_or_no_domain(new_project)

    # Add something to the domain
    domain_service.add_items_to_domain(intents={"testing"}, project_id=new_project)
    assert not domain_service.has_empty_or_no_domain(new_project)


def test_add_no_new_items_to_domain(domain_service: DomainService, new_project: Text):
    domain_service.store_domain(TEST_DOMAIN, new_project)
    old = domain_service.get_domain(new_project)

    intents = domain_service.get_intents_from_domain(new_project)
    domain_service.add_items_to_domain(
        TEST_DOMAIN["actions"],
        intents,
        TEST_DOMAIN["entities"],
        TEST_DOMAIN["slots"],
        new_project,
    )

    assert domain_service.get_domain(new_project) == old


def test_empty_domain():
    domain = DomainModel()
    assert domain.is_empty()


def test_upload_domain_without_templates(
    domain_service: DomainService, nlg_service: NlgService
):
    # there are templates
    actual, _ = nlg_service.fetch_templates()
    assert actual

    # upload domain without templates
    domain_without_templates = EXPECTED_DOMAIN.copy()
    domain_without_templates["templates"] = {}
    domain_service.store_domain(
        domain_without_templates, TEST_PROJECT, username=TEST_USER, store_templates=True
    )

    assert domain_service.get_domain(TEST_PROJECT) == domain_without_templates

    # there should be no templates
    actual, _ = nlg_service.fetch_templates()
    assert not actual


def test_store_domain_replaces_templates(
    domain_service: DomainService, nlg_service: NlgService
):
    domain_without_templates = EXPECTED_DOMAIN.copy()
    domain_without_templates["templates"] = {}
    domain_service.store_domain(
        domain_without_templates, TEST_PROJECT, username=TEST_USER, store_templates=True
    )

    domain_service.commit()  # commit since services use different sessions

    assert domain_service.get_domain(TEST_PROJECT) == domain_without_templates

    # insert some templates and make sure they end up in domain
    from tests.unit.services.test_nlg_service import TEST_TEMPLATE

    domain_id = domain_service.get_domain_id(TEST_PROJECT)
    nlg_service.save_template(TEST_TEMPLATE, TEST_USER, domain_id, TEST_PROJECT)

    nlg_service.commit()  # commit since services use different sessions

    # get domain again and check template is there
    actual = domain_service.get_domain(TEST_PROJECT)
    assert len(actual["templates"]) == 1
    assert (
        actual["templates"][TEST_TEMPLATE["template"]][0]["text"]
        == TEST_TEMPLATE["text"]
    )


def test_get_intents(domain_service: DomainService, new_project: Text):
    test_domain = {
        "intents": [
            {"intent_1": {"use_entities": True}},
            {"intent_2": {"use_entities": False}},
        ]
    }

    domain_service.store_domain(test_domain, new_project)
    actual = domain_service.get_intents_from_domain(new_project)

    assert actual == {"intent_1", "intent_2"}


def test_get_entities(domain_service: DomainService, new_project: Text):
    domain_service.store_domain(TEST_DOMAIN, new_project)

    assert domain_service.get_entities_from_domain(new_project) == set(
        TEST_DOMAIN["entities"]
    )


def test_save_and_get_token(domain_service: DomainService):
    from uuid import uuid4

    # sql_migration successfully created token using save_token
    assert len(domain_service._get_token().token) == len(uuid4().hex)
    assert len(str(domain_service._get_token().expires)) == 10


def test_update_token(domain_service: DomainService):
    bot_name = "Ursula"
    description = "Bot that will insult you in many creative ways, be prepared!"
    domain_service.update_token(bot_name, description)
    token = domain_service._get_token()
    assert token.bot_name == bot_name
    assert token.description == description


def test_update_token_from_dict(domain_service: DomainService):
    updated_token = dict(bot_name="Ursula2", description="On fire")
    domain_service.update_token_from_dict(updated_token)
    token = domain_service._get_token()
    assert token.bot_name == updated_token["bot_name"]
    assert token.description == updated_token["description"]


@pytest.mark.parametrize("lifetime, expected", [(-1, True), (10, False)])
def test_is_token_expired(domain_service: DomainService, lifetime: int, expected: bool):
    token = domain_service.generate_and_save_token(lifetime)
    assert domain_service.has_token_expired(token.token) == expected


def test_is_token_expired_if_other_token(domain_service: DomainService):
    assert domain_service.has_token_expired("other token")


async def test_domain_warnings(domain_service: DomainService):
    domain_service.store_domain(
        TEST_DOMAIN, TEST_PROJECT, username=TEST_USER, store_templates=True
    )

    warnings, _ = await domain_service.get_domain_warnings(TEST_PROJECT)

    # actions, intents, slots should be in warnings
    # domain actions are forms and actions
    domain_actions = set(TEST_DOMAIN["actions"])
    domain_actions.update(TEST_DOMAIN["forms"])
    assert set(warnings["action_warnings"]["in_domain"]) <= domain_actions
    assert set(warnings["intent_warnings"]["in_domain"]) == set(
        list(d)[0] for d in EXPECTED_DOMAIN["intents"]
    )

    assert set(warnings["slot_warnings"]["in_domain"]) == set(
        TEST_DOMAIN["slots"].keys()
    )

    # entity warnings should be empty
    assert set(warnings["entity_warnings"]["in_domain"]) == set(TEST_DOMAIN["entities"])
    assert not warnings["entity_warnings"]["in_training_data"]


async def test_domain_warnings_with_extracted_entities(
    domain_service: DomainService, data_service: DataService
):
    domain_service.store_domain(
        TEST_DOMAIN, TEST_PROJECT, username=TEST_USER, store_templates=True
    )

    # add training examples with and without extracted entity
    extractor = "some_extractor"
    entity_name_1 = "a good entity"
    example_with_extractor = TEST_EXAMPLE.copy()
    example_with_extractor["entities"][0]["extractor"] = extractor
    example_with_extractor["entities"][0]["entity"] = entity_name_1
    example_with_extractor["text"] = "example text"
    data_service.save_example(
        TEST_USER,
        TEST_PROJECT,
        example_with_extractor,
        add_example_items_to_domain=False,
    )

    entity_name_2 = "a better entity"
    example_without_extractor = TEST_EXAMPLE.copy()
    example_without_extractor["text"] = "some other text"
    example_without_extractor["entities"][0]["entity"] = entity_name_2
    example_without_extractor["entities"][0].pop("extractor")
    data_service.save_example(
        TEST_USER,
        TEST_PROJECT,
        example_without_extractor,
        add_example_items_to_domain=False,
    )

    # get domain warnings
    warnings, _ = await domain_service.get_domain_warnings(TEST_PROJECT)
    entity_warnings = warnings["entity_warnings"]

    # entity with extractor should not be in warnings
    assert entity_name_1 not in entity_warnings["in_training_data"]

    # entity without extractor should be in warnings
    assert entity_name_2 in entity_warnings["in_training_data"]


def test_adding_domain_events(domain_service: DomainService):
    domain_service.store_domain(
        TEST_DOMAIN, TEST_PROJECT, username=TEST_USER, store_templates=True
    )

    actions = domain_service.get_actions_from_domain(TEST_PROJECT)
    assert actions
    intents = domain_service.get_intents_from_domain(TEST_PROJECT)
    assert actions

    # add events to domain
    actions_to_add = ["new_action", "hello_1"]
    intents_to_add = ["new_intent", "hellohello"]
    slots_to_add = ["new_slot", "hello123"]
    domain_service.add_items_to_domain(
        actions=actions_to_add,
        intents=intents_to_add,
        slots=slots_to_add,
        project_id=TEST_PROJECT,
    )

    # new actions, intents, slots contain both old and new events
    new_actions = domain_service.get_actions_from_domain(TEST_PROJECT)
    new_intents = domain_service.get_intents_from_domain(TEST_PROJECT)
    new_slots = domain_service.get_slots_from_domain(TEST_PROJECT)
    assert all(a in new_actions for a in set(actions_to_add) | actions)
    assert all(i in new_intents for i in set(intents_to_add) | intents)
    assert all(s in new_slots for s in slots_to_add)


def test_remove_unfeaturized_slots(domain_service: DomainService):
    # create domain with a text slot and an unfeaturized slot
    text_slot = TextSlot("slot1")
    unfeaturized_slot = UnfeaturizedSlot("slot2")
    domain = Domain.empty()
    domain.slots = [text_slot, unfeaturized_slot]

    # remove unfeaturized slot from set of those two slots
    slots = domain_service._remove_unfeaturized_slots(
        {text_slot.name, unfeaturized_slot.name}, domain
    )

    # text slot should be there, unfeaturized should not
    assert text_slot.name in slots
    assert unfeaturized_slot.name not in slots


@pytest.mark.parametrize(
    "action",
    [{"name": "test_add_actions"}, {"name": "test_add_actions2", "is_form": False}],
)
def test_add_actions(domain_service: DomainService, action: Dict):
    result = domain_service.add_new_action(action)

    result.pop("id")
    result.pop("domain_id")
    assert result.pop("is_form") == action.pop("is_form", False)
    assert result == action

    domain = domain_service.get_domain()
    assert action["name"] in domain["actions"]


def test_add_form(domain_service: DomainService):
    test_action = {"name": "test_add_form", "is_form": True}
    _ = domain_service.add_new_action(test_action)

    domain = domain_service.get_domain()
    assert test_action["name"] in domain["forms"]


def test_add_action_if_it_already_exists(domain_service: DomainService):
    test_action = {"name": "test_add_action_if_it_already_exists"}
    domain_service.add_new_action(test_action)

    with pytest.raises(ValueError):
        domain_service.add_new_action(test_action)


def test_update_action(domain_service: DomainService, new_project: Text):
    domain_service.store_domain(TEST_DOMAIN, new_project)
    test_action = {"name": "test_update_action"}
    added = domain_service.add_new_action(test_action, new_project)

    updated = {"name": "test_update_action2", "is_form": True}
    domain_service.update_action(added["id"], updated)

    domain = domain_service.get_domain(new_project)

    assert test_action["name"] not in domain["actions"]
    assert updated["name"] in domain["forms"]


def test_update_action_with_invalid_id(domain_service: DomainService):
    with pytest.raises(ValueError):
        domain_service.update_action(-1, {})


def test_delete_action(domain_service: DomainService, new_project: Text):
    domain_service.store_domain(TEST_DOMAIN, new_project)
    test_action = {"name": "test_delete_action"}
    added = domain_service.add_new_action(test_action)
    domain_service.delete_action(added["id"])

    assert test_action["name"] not in domain_service.get_actions_from_domain()


def test_delete_action_with_invalid_id(domain_service: DomainService):
    with pytest.raises(ValueError):
        domain_service.delete_action(-1)


def test_dump_domain(domain_service: DomainService, tmpdir: Path, new_project: Text):
    from rasa.core.domain import Domain as RasaDomain

    target_path = str(tmpdir / "domain.yml")
    domain_service.store_domain(TEST_DOMAIN, new_project)

    domain_service._dump_domain(target_path, new_project)

    assert RasaDomain.load(target_path)
