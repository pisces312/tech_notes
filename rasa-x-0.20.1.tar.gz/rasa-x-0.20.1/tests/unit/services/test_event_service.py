import json
from uuid import uuid4

import pytest
from sqlalchemy.orm import Session

import tests.unit.services.test_data_service as data_test
from rasax.community import config
from rasax.community.config import team_name
from rasax.community.constants import SHARE_YOUR_BOT_CHANNEL_NAME
from rasax.community.database.conversation import Conversation
from rasax.community.services.event_service import EventService, FLAGGED_MESSAGES_KEY
from rasax.community.services.intent_service import (
    INTENT_NAME_KEY,
    INTENT_MAPPED_TO_KEY,
    INTENT_EXAMPLES_KEY,
)
from rasax.community.services.logs_service import LogsService
from rasax.community.services.model_service import ModelService
from tests.unit.conftest import (
    _user_event,
    insert_test_model,
    insert_test_user,
    _action_event,
)


@pytest.fixture
def event_service(event_service: EventService):
    return event_service


def test_get_sender_ids(event_service: EventService):
    assert event_service.sender_ids() == []

    events = [
        _user_event("test_get_sender_ids1"),
        _user_event("test_get_sender_ids2"),
        _user_event("test_get_sender_ids1"),
    ]

    for event in events:
        event_service.save_event(json.dumps(event))

    assert event_service.sender_ids() == [
        "test_get_sender_ids1",
        "test_get_sender_ids2",
    ]


def test_save_user_event(event_service: EventService):
    test_sender = "test save sender"
    test_timestamp = 123456.03423423
    test_intent = "test save intent"
    test_event = _user_event(test_sender, test_timestamp, test_intent)
    test_event_string = json.dumps(test_event)
    event_service.save_event(test_event_string)

    expected = {
        "sender_id": test_sender,
        "sender_name": test_sender,
        "latest_event_time": test_timestamp,
        "intents": [test_intent],
        "actions": [],
        "latest_input_channel": "rest",
        "minimum_action_confidence": 1,
        "in_training_data": True,
        "policies": [],
        "n_user_messages": 1,
        "corrected_messages": [],
        "flagged_messages": [],
        "unflagged_messages": [],
        "interactive": False,
    }

    actual = event_service.get_conversation_metadata_for_client(test_sender)

    assert actual == expected

    # Save second event and check whether conversation is updated correctly.
    test_intent2 = "test save intent 2"
    test_event["parse_data"]["intent"]["name"] = test_intent2
    test_event["input_channel"] = "rest2"
    test_event["timestamp"] = 223456

    event_service.save_event(json.dumps(test_event))

    expected["intents"] = [test_intent, test_intent2]
    expected["latest_input_channel"] = test_event["input_channel"]
    expected["n_user_messages"] = 2
    expected["latest_event_time"] = test_event["timestamp"]

    actual = event_service.get_conversation_metadata_for_client(test_sender)

    assert actual == expected


def test_save_action_event(event_service: EventService):
    event = _action_event(
        "test save action sender", 323456, "test save action", "test save policy", 0.1
    )

    event_service.save_event(json.dumps(event))

    expected = {
        "sender_id": event["sender_id"],
        "sender_name": event["sender_id"],
        "latest_event_time": event["timestamp"],
        "intents": [],
        "actions": [event["name"]],
        "latest_input_channel": None,
        "minimum_action_confidence": event["confidence"],
        "in_training_data": False,
        "policies": [event["policy"]],
        "n_user_messages": 0,
        "corrected_messages": [],
        "flagged_messages": [],
        "unflagged_messages": [],
        "interactive": False,
    }

    actual = event_service.get_conversation_metadata_for_client(event["sender_id"])

    assert actual == expected

    # Save second event and check whether conversation is updated correctly.
    event["confidence"] = 0.0
    event["policy"] = "test save policy 2"

    event_service.save_event(json.dumps(event))

    expected = expected
    expected["minimum_action_confidence"] = event["confidence"]
    expected["policies"] = ["test save policy", event["policy"]]

    actual = event_service.get_conversation_metadata_for_client(event["sender_id"])

    assert actual == expected


def test_get_statistics(event_service: EventService):
    # use statistics of the events in the two tests above
    actual = event_service.get_statistics()
    expected = {
        "user_messages": 5,
        "bot_messages": 0,
        "top_intents": ["test", "test save intent", "test save intent 2"],
        "top_actions": ["test save action"],
        "top_entities": [],
        "top_policies": ["test save policy", "test save policy 2"],
    }
    assert actual == expected

    # insert another user intent with intent to see whether ordering changes
    test_event = _user_event("other user", 99999, "test save intent 2")
    event_service.save_event(json.dumps(test_event))
    expected["user_messages"] = 6
    expected["top_intents"] = ["test", "test save intent 2", "test save intent"]

    actual = event_service.get_statistics()

    assert actual == expected


def test_get_empty_statistics(event_service: EventService):
    non_empty_statistics = event_service.get_statistics()

    assert event_service.user_statistics_dict().keys() == non_empty_statistics.keys()


def test_save_evaluation(event_service: EventService):
    test_evaluation = {
        "accuracy": 0.9,
        "f1": 0.9333333333333333,
        "in_training_data_fraction": 0.8571428571428571,
        "precision": 1,
        "is_end_to_end_evaluation": True,
        "actions": [
            {
                "action": "utter_ask_howcanhelp",
                "confidence": 1,
                "policy": "policy_0_MemoizationPolicy",
                "predicted": "utter_ask_howcanhelp",
            }
        ],
    }
    test_sender = "evaluation sender"

    # Create conversation for user
    event_service.save_event(json.dumps(_user_event(test_sender, 0)))

    event_service.update_evaluation(test_sender, test_evaluation)

    assert event_service.get_evaluation(test_sender) == test_evaluation


def test_save_evaluation_for_invalid_conversation(event_service: EventService):
    with pytest.raises(ValueError):
        event_service.update_evaluation(
            "test_save_evaluation_for_invalid_conversation", {}
        )


def test_delete_evaluation(event_service: EventService):
    test_sender = "evaluation delete sender"
    # Create conversation for user
    event_service.save_event(json.dumps(_user_event(test_sender, 0)))

    event_service.update_evaluation(test_sender, {"eval": "test"})

    assert event_service.get_evaluation(test_sender)

    event_service.delete_evaluation(test_sender)

    assert not event_service.get_evaluation(test_sender)


def test_get_unique_intents(event_service: EventService):
    expected = event_service.get_unique_intents()
    test_intent = "unique intent 1"
    event_service.save_event(json.dumps(_user_event("sender", 0, test_intent)))

    expected.append(test_intent)
    actual = event_service.get_unique_intents()
    assert len(actual) == len(expected)
    assert all([e in actual for e in expected])

    event_service.save_event(json.dumps(_user_event("sender", 0, test_intent)))
    actual = event_service.get_unique_intents()

    assert len(actual) == len(expected)
    assert all([e in actual for e in expected])

    test_intent2 = "unique intent 2"
    expected.append(test_intent2)
    event_service.save_event(json.dumps(_user_event("sender", 0, test_intent2)))
    actual = event_service.get_unique_intents()

    assert len(actual) == len(expected)
    assert all([e in actual for e in expected])


def test_get_unique_policies(event_service: EventService):
    expected = event_service.get_unique_policies()

    test_policy = "unique policy 1"
    event_service.save_event(
        json.dumps(_action_event("unique sender", policy=test_policy))
    )
    expected.append(test_policy)
    actual = event_service.get_unique_policies()
    assert len(actual) == len(expected)
    assert all([e in actual for e in expected])

    event_service.save_event(
        json.dumps(_action_event("unique sender", policy=test_policy))
    )
    actual = event_service.get_unique_policies()

    assert len(actual) == len(expected)
    assert all([e in actual for e in expected])

    test_policy2 = "unique policy 2"
    expected.append(test_policy2)
    event_service.save_event(
        json.dumps(_action_event("unique sender", policy=test_policy2))
    )
    actual = event_service.get_unique_policies()

    assert len(actual) == len(expected)
    assert all([e in actual for e in expected])


def test_get_unique_actions(event_service: EventService):
    expected = event_service.get_unique_actions()

    test_action = "unique action 1"
    event_service.save_event(
        json.dumps(_action_event("unique sender", action_name=test_action))
    )
    expected.append(test_action)
    actual = event_service.get_unique_actions()
    assert len(actual) == len(expected)
    assert all([e in actual for e in expected])

    event_service.save_event(
        json.dumps(_action_event("unique sender", action_name=test_action))
    )
    actual = event_service.get_unique_actions()

    assert len(actual) == len(expected)
    assert all([e in actual for e in expected])

    test_action2 = "unique action 2"
    expected.append(test_action2)
    event_service.save_event(
        json.dumps(_action_event("unique sender", action_name=test_action2))
    )
    actual = event_service.get_unique_actions()

    assert len(actual) == len(expected)
    assert all([e in actual for e in expected])


def test_get_unique_entities(event_service: EventService):
    user_event = _user_event(
        "test_get_unique_entities1",
        entities=[{"entity": "entity1", "value": 2}, {"entity": "entity2", "value": 2}],
    )
    event_service.save_event(json.dumps(user_event))

    user_event = _user_event(
        "test_get_unique_entities2",
        entities=[{"entity": "entity1", "value": 2}, {"entity": "entity3", "value": 2}],
    )
    event_service.save_event(json.dumps(user_event))

    assert event_service.get_unique_entities() == ["entity1", "entity2", "entity3"]


def test_add_flag_without_conversation(event_service):
    test_sender_id = uuid4().hex
    event_service.add_flagged_message(test_sender_id, 0)

    assert not event_service.get_conversation_metadata_for_client(test_sender_id)


def test_no_initial_flag(event_service: EventService):
    test_sender_id = uuid4().hex
    test_event = _action_event(test_sender_id)
    event_service.save_event(json.dumps(test_event))

    actual = event_service.get_conversation_metadata_for_client(test_sender_id)

    assert actual.get("flagged_messages", None) == []
    assert actual.get("unflagged_messages", None) == []


def test_add_flagged_message(event_service):
    test_sender_id = uuid4().hex
    test_timestamp = 5
    test_event = _user_event(test_sender_id, test_timestamp)
    event_service.save_event(json.dumps(test_event))

    event_service.add_flagged_message(test_sender_id, test_timestamp)

    actual = event_service.get_conversation_metadata_for_client(test_sender_id)

    assert actual.get("flagged_messages", None) == [test_timestamp]
    assert actual.get("unflagged_messages", None) == []


def test_remove_flagged_conversation(event_service):
    test_sender_id = uuid4().hex
    test_timestamp = 5
    test_event = _user_event(test_sender_id, test_timestamp)
    event_service.save_event(json.dumps(test_event))
    event_service.add_flagged_message(test_sender_id, test_timestamp)

    test_timestamp2 = 10
    test_event = _user_event(test_sender_id, test_timestamp2)
    event_service.save_event(json.dumps(test_event))
    event_service.add_flagged_message(test_sender_id, test_timestamp2)

    event_service.delete_flagged_message(test_sender_id, test_timestamp)

    actual = event_service.get_conversation_metadata_for_client(test_sender_id)

    assert actual.get("flagged_messages", None) == [test_timestamp2]
    assert actual.get("unflagged_messages", None) == [test_timestamp]


def test_get_all(event_service, session):
    # Remove old conversation from old tests
    old_conversations = session.query(Conversation).all()
    event_service.delete_all(old_conversations)
    session.commit()

    test_event1 = _user_event(uuid4().hex, 0)
    event_service.save_event(json.dumps(test_event1))

    test_event2 = _user_event(uuid4().hex, 0)
    event_service.save_event(json.dumps(test_event2))

    _, total_conversations = event_service.get_conversation_metadata_for_all_clients()

    assert total_conversations == 2


def test_get_all_with_text_query(
    event_service: EventService, logs_service: LogsService, model_service: ModelService
):
    test_sender_id = uuid4().hex
    test_text = "test with text query"
    test_project = "default"
    test_event = json.dumps(
        _user_event(test_sender_id, project=test_project, text=test_text)
    )

    # insert model for logs
    insert_test_model(test_project, "a model", model_service)

    event = event_service.save_event(test_event)
    logs_service.save_nlu_logs_from_event(test_event, event.id)

    actual, total_conversations = event_service.get_conversation_metadata_for_all_clients(
        text_query="text"
    )

    assert total_conversations == 1
    assert actual[0]["sender_id"] == test_sender_id


def test_get_all_with_entity_query(event_service: EventService):
    test_sender_id = uuid4().hex
    test_text = "test with text query"
    test_project = "default"
    test_event = _user_event(
        test_sender_id,
        project=test_project,
        text=test_text,
        entities=[{"entity": "package_manager"}],
    )
    event_service.save_event(json.dumps(test_event))

    actual, total_conversations = event_service.get_conversation_metadata_for_all_clients(
        entity_query="package_manager"
    )

    assert total_conversations == 1
    assert actual[0]["sender_id"] == test_sender_id


def test_get_all_with_intent_query(event_service: EventService):
    test_sender_id = uuid4().hex
    test_text = "test with text query"
    test_project = "default"
    intent = "245i2345p3i4o5"
    test_event = _user_event(
        test_sender_id, project=test_project, text=test_text, intent=intent
    )

    event_service.save_event(json.dumps(test_event))

    actual, total_conversations = event_service.get_conversation_metadata_for_all_clients(
        intent_query=intent
    )

    assert total_conversations == 1
    assert actual[0]["sender_id"] == test_sender_id


def test_get_all_with_action_query(event_service: EventService):
    test_sender_id = uuid4().hex
    test_action = "test_get_all_with_action_query"
    test_event = _action_event(test_sender_id, action_name=test_action)

    event_service.save_event(json.dumps(test_event))

    actual, total_conversations = event_service.get_conversation_metadata_for_all_clients(
        action_query=test_action
    )

    assert total_conversations == 1
    assert actual[0]["sender_id"] == test_sender_id


def test_get_all_with_policy_query(event_service: EventService):
    test_sender_id = uuid4().hex
    test_policy = "special-policy"
    test_event = _action_event(test_sender_id, policy=test_policy)

    event_service.save_event(json.dumps(test_event))

    actual, total_conversations = event_service.get_conversation_metadata_for_all_clients(
        policies=test_policy
    )

    assert total_conversations == 1
    assert actual[0]["sender_id"] == test_sender_id


def test_get_only_flagged(event_service):
    test_sender_id = uuid4().hex
    test_event1 = _user_event(test_sender_id, 0)
    event_service.save_event(json.dumps(test_event1))
    event_service.add_flagged_message(test_sender_id, 0)

    test_event2 = _user_event("another user", 0)
    event_service.save_event(json.dumps(test_event2))

    _, total_conversations = event_service.get_conversation_metadata_for_all_clients(
        only_flagged=True
    )

    assert total_conversations == 1


def test_get_flagged_message_timestamps(event_service):
    test_sender_id = uuid4().hex
    test_event1 = _user_event(test_sender_id, 0)
    event_service.save_event(json.dumps(test_event1))
    event_service.add_flagged_message(test_sender_id, 0)

    test_event1 = _user_event(test_sender_id, 10)
    event_service.save_event(json.dumps(test_event1))
    event_service.add_flagged_message(test_sender_id, 10)

    assert event_service.get_flagged_message_timestamps(test_sender_id) == {0, 10}


def test_empty_initial_correct_messages(event_service):
    test_sender_id = uuid4().hex
    test_event = _action_event(test_sender_id)
    event_service.save_event(json.dumps(test_event))

    actual = event_service.get_conversation_metadata_for_client(test_sender_id)

    assert actual.get("corrected_messages", None) == []


def test_correct_message(event_service, data_service, session):
    test_sender_id = uuid4().hex
    insert_test_user(session, test_sender_id)
    test_timestamp = 5
    test_intent = "intent"
    test_event = _user_event(test_sender_id, test_timestamp, test_intent)
    # Insert user event and create conversations metadata for conversation
    event_service.save_event(json.dumps(test_event))

    # Correct message
    test_project = config.project_name
    test_user = {"username": test_sender_id, "team": team_name}
    event_service.correct_message(
        test_sender_id, test_timestamp, {"intent": test_intent}, test_user, test_project
    )

    # Insert another message into the conversation
    test_intent2 = "intent2"
    test_timestamp2 = 10
    test_event = _user_event(test_sender_id, test_timestamp2, test_intent2)

    # Add permanent intent by inserting a training example
    permanent_intent = "permanent_intent"

    training_data = data_test.TEST_EXAMPLE.copy()
    training_data["intent"] = permanent_intent
    data_service.save_example(test_sender_id, test_project, training_data)

    event_service.save_event(json.dumps(test_event))

    # Correct message with an intent that is mapped to the permanent intent
    event_service.correct_message(
        test_sender_id,
        test_timestamp2,
        {INTENT_NAME_KEY: test_intent2, INTENT_MAPPED_TO_KEY: permanent_intent},
        test_user,
        test_project,
    )

    actual = event_service.get_conversation_metadata_for_client(test_sender_id)

    # Check whether messages were corrected.
    assert actual.get("corrected_messages", None) == [
        {"message_timestamp": test_timestamp, "intent": test_intent},
        {"message_timestamp": test_timestamp2, "intent": test_intent2},
    ]


def test_delete_correct_message(event_service, data_service, intent_service, session):
    # delete old temporary intents
    test_sender_id = uuid4().hex
    insert_test_user(session, test_sender_id)
    test_timestamp = 5
    test_intent = "intent"
    test_event = _user_event(test_sender_id, test_timestamp, test_intent)
    # Insert user event and create conversations metadata for conversation
    event_service.save_event(json.dumps(test_event))

    # add permanent intent by inserting a training example
    permanent_intent = "permanent intent for delete message correction"
    training_data = data_test.TEST_EXAMPLE.copy()
    training_data["intent"] = permanent_intent
    data_service.save_example(test_sender_id, config.project_name, training_data)

    # Correct message
    test_user = {"username": test_sender_id, "team": team_name}
    correct_intent = {
        INTENT_NAME_KEY: test_intent,
        INTENT_MAPPED_TO_KEY: permanent_intent,
    }
    event_service.correct_message(
        test_sender_id, test_timestamp, correct_intent, test_user, config.project_name
    )
    # Delete correction
    event_service.delete_message_correction(
        test_sender_id, test_timestamp, config.project_name
    )

    actual = event_service.get_conversation_metadata_for_client(test_sender_id)

    # Assert message correction was deleted
    assert actual.get("corrected_messages") == []

    training_data, _ = data_service.get_training_data(config.project_name)

    assert len([r for r in training_data if r["intent"] == permanent_intent]) == 1

    assert (
        len(
            intent_service.get_temporary_intent(test_intent, config.project_name)[
                INTENT_EXAMPLES_KEY
            ]
        )
        == 0
    )


def test_create_interactive_learning_conversation_with_random_sender_id(
    event_service: EventService
):
    _dict = {"interactive": True}

    actual = event_service.create_conversation_from(_dict)

    assert actual["interactive"] is True
    assert actual["sender_id"]


def test_create_interactive_learning_conversation_with_sender_id(
    event_service: EventService
):
    _dict = {"interactive": True, "sender_id": "some sender"}

    actual = event_service.create_conversation_from(_dict)

    assert actual["interactive"] is True
    assert actual["sender_id"] == _dict["sender_id"]


def test_create_interactive_learning_conversation_with_existing_sender_id(
    event_service: EventService, session: Session
):
    _dict = {"interactive": True, "sender_id": "test_create_with_existing"}

    _ = event_service.create_conversation_from(_dict)

    with pytest.raises(ValueError):
        event_service.create_conversation_from(_dict)

    # Rollback db error for further tests
    session.rollback()


def test_get_all_without_interactive(event_service: EventService):
    _dict = {"interactive": True, "sender_id": "get_without_interactive"}
    _ = event_service.create_conversation_from(_dict)

    actual, _ = event_service.get_conversation_metadata_for_all_clients()

    assert all([c["sender_id"] != _dict["sender_id"] for c in actual])


def test_get_all_with_interactive(event_service: EventService):
    _dict = {"interactive": True, "sender_id": "get_with_interactive"}
    _ = event_service.create_conversation_from(_dict)

    actual, _ = event_service.get_conversation_metadata_for_all_clients(
        include_interactive=True
    )

    assert any([c["sender_id"] == _dict["sender_id"] for c in actual])


def test_modify_event_time_to_be_larger_than():
    test_sender = "test sender"
    timestamps = [100, 5, 120]
    events = [_action_event(test_sender, t) for t in timestamps]

    minimal_timestamp = 1000

    actual = EventService.modify_event_time_to_be_later_than(minimal_timestamp, events)

    actual_timestamps = [event["timestamp"] for event in actual]

    assert actual_timestamps == [1000.05, 1095.05, 1115.05]


def test_modify_event_time_with_if_no_modification_needed():
    test_sender = "test sender"
    timestamps = [5, 100, 120]
    events = [_action_event(test_sender, t) for t in timestamps]

    minimal_timestamp = 0

    actual = EventService.modify_event_time_to_be_later_than(minimal_timestamp, events)

    actual_timestamps = [event["timestamp"] for event in actual]

    assert actual_timestamps == [5, 100, 120]


def test_modify_event_time_with_empty_list():
    actual = EventService.modify_event_time_to_be_later_than(0, [])

    assert actual == []


def test_remove_leading_action_listen():
    test_sender = "test sender"
    timestamps = [1, 2, 3]

    events = [_action_event(test_sender, t) for t in timestamps]
    action_listen = _action_event(test_sender, 0, action_name="action_listen")
    events = [action_listen] + events

    actual = EventService.remove_leading_action_listen(events)

    assert actual == events[1:]


def test_remove_leading_action_listen_without_action_listen():
    test_sender = "test sender"
    timestamps = [1, 2, 3]

    events = [_action_event(test_sender, t) for t in timestamps]
    action_listen = _action_event(test_sender, 4, action_name="action_listen")
    events.append(action_listen)

    actual = EventService.remove_leading_action_listen(events)

    assert actual == events


def test_get_tracker(event_service: EventService):
    test_sender = "test get tracker"

    events = [_action_event(test_sender, t) for t in [1, 2, 3]]
    events.append(_action_event(test_sender, 4, action_name="action_listen"))
    events += (_user_event(test_sender, t, text=str(t)) for t in [5, 6, 7])

    for event in events:
        event_service.save_event(json.dumps(event))

    actual = event_service.get_tracker_for_conversation(test_sender)

    assert len(actual.events) == 7
    assert actual.latest_message.text == "7"


def test_get_tracker_if_sender_id_not_found(event_service: EventService):
    not_existing_sender = "test_get_tracker_if_sender_id_not_found"

    assert not event_service.get_tracker_for_conversation(not_existing_sender)


def test_tracker_with_since(event_service: EventService):
    test_sender = "test_tracker_with_since"
    events = [_action_event(test_sender, t) for t in [1, 2, 3]]

    for event in events:
        event_service.save_event(json.dumps(event))

    actual = event_service.get_tracker_for_conversation(test_sender, since_time=3)

    assert len(actual.events) == 1


def test_get_story_for_sender_id(event_service: EventService):
    test_sender = "test_get_story_for_sender_id"

    events = [_action_event(test_sender, 1, action_name="action_listen")]
    events.append(_user_event(test_sender, 2))
    events += [_action_event(test_sender, t) for t in [3, 5, 6]]

    for event in events:
        event_service.save_event(json.dumps(event))

    expected = """## test_get_story_for_sender_id
* test
    - action
    - action
    - action
"""

    assert event_service.story_for_sender_id(test_sender) == expected


def test_get_tracker_including_rasax_metadata(event_service: EventService):
    test_sender = "test_get_tracker_including_rasax_metadata"
    events = [_action_event(test_sender, t) for t in [1, 2, 3]]

    for event in events:
        event_service.save_event(json.dumps(event))

    event_service.add_flagged_message(test_sender, 2)

    actual = event_service.get_tracker_with_message_flags(test_sender)

    assert actual[FLAGGED_MESSAGES_KEY] == [2]

    assert all(e["is_flagged"] == (e["timestamp"] == 2) for e in actual["events"])


def test_get_tracker_including_rasax_metadata_with_until_time(
    event_service: EventService
):
    test_sender = "test_get_tracker_including_rasax_metadata_with_until_time"
    events = [_action_event(test_sender, t) for t in [1, 2, 3]]

    for event in events:
        event_service.save_event(json.dumps(event))

    actual = event_service.get_tracker_with_message_flags(test_sender, until_time=1)

    assert len(actual["events"]) == 1


def test_get_tracker_with_correct_order(event_service: EventService):
    test_sender = "test_get_tracker_with_correct_order"
    events = [_action_event(test_sender, t) for t in [10, 9, 8, 7, 11, 1]]

    for event in events:
        event_service.save_event(json.dumps(event))

    actual = event_service.get_tracker_with_message_flags(test_sender, until_time=10)
    actual_timestamps = [e["timestamp"] for e in actual["events"]]

    assert actual_timestamps == [1, 7, 8, 9, 10]


def test_get_messages_with_invalid_sender_id(event_service: EventService):
    test_sender = "test_get_messages_with_invalid_sender_id"

    assert event_service.get_messages_for(test_sender) is None


def test_get_messages_with_no_messages(event_service: EventService):
    test_sender = "test_get_messages_with_no_messages"
    events = [_action_event(test_sender, t) for t in [1, 2, 3]]

    for event in events:
        event_service.save_event(json.dumps(event))

    actual = event_service.get_messages_for(test_sender)

    assert actual["events"]
    assert actual["messages"] == []


def test_get_messages_with_messages(event_service: EventService):
    test_sender = "test_get_messages_with_no_messages"
    events = [_user_event(test_sender, t) for t in [1, 2, 3]]
    events += [_action_event(test_sender, t) for t in [4, 5, 6]]
    events += [_action_event(test_sender, t, event_type="bot") for t in [7, 8, 9]]

    for event in events:
        event_service.save_event(json.dumps(event))

    event_service.add_flagged_message(test_sender, 2)

    actual = event_service.get_messages_for(test_sender)

    assert actual.get(FLAGGED_MESSAGES_KEY) is None
    assert all(e["is_flagged"] == (e["timestamp"] == 2) for e in actual["events"])
    assert len(actual["messages"]) == 6


def test_get_sender_name(event_service: EventService):
    test_sender = "test_get_sender_name"
    # Create conversation by adding events
    event = _user_event(test_sender, 1)
    event_service.save_event(json.dumps(event))

    conversation = event_service._get_conversation(test_sender)

    assert EventService.get_sender_name(conversation) == conversation.sender_id


def test_get_sender_name_with_tester_channel(event_service: EventService):
    test_sender = "test_get_sender_name_with_tester_channel"
    # Create conversation by adding events
    event = _user_event(test_sender, 1)
    event_service.save_event(json.dumps(event))

    conversation = event_service._get_conversation(test_sender)
    conversation.latest_input_channel = SHARE_YOUR_BOT_CHANNEL_NAME

    assert EventService.get_sender_name(conversation) == SHARE_YOUR_BOT_CHANNEL_NAME
