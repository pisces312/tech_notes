from rasax.community import config
from rasax.community.services.feature_service import FeatureService


def test_set_feature(feature_service: FeatureService):
    if len(config.DEFAULT_FEATURE_FLAGS) == 0:
        return

    test_feature = config.DEFAULT_FEATURE_FLAGS[0]
    test_feature["enabled"] = True

    feature_service.set_feature(test_feature)

    assert feature_service.features() == [test_feature, config.DEFAULT_FEATURE_FLAGS[1]]


def test_unset_feature(feature_service: FeatureService):
    if len(config.DEFAULT_FEATURE_FLAGS) == 0:
        return

    feature_service.set_feature(config.DEFAULT_FEATURE_FLAGS[0])

    assert feature_service.features() == config.DEFAULT_FEATURE_FLAGS


def test_set_non_existing_feature(feature_service: FeatureService):
    test_feature = {"name": "print money", "enabled": False}

    feature_service.set_feature(test_feature)

    assert feature_service.features() == config.DEFAULT_FEATURE_FLAGS
