import json
import time
from typing import Text, Tuple, List

from rasax.community import config
from rasax.community.services.data_service import DataService
from rasax.community.services.domain_service import DomainService
from rasax.community.services.intent_service import (
    IntentService,
    INTENT_NAME_KEY,
    INTENT_EXAMPLES_KEY,
    INTENT_IS_TEMPORARY_KEY,
    INTENT_MAPPED_TO_KEY,
)
import tests.unit.services.test_data_service as data_test
import pytest

from rasax.community.services.logs_service import LogsService
from rasax.community.services.model_service import ModelService
from rasax.community.services.settings_service import SettingsService
from rasax.community.services.user_goal_service import UserGoalService
from tests.unit.conftest import _user_event, insert_test_model, user_dict

TEST_PROJECT = config.project_name


def test_add_temporary_intent(intent_service: IntentService):
    test_intent = {"intent": "my intent"}
    intent_service.add_temporary_intent(test_intent, TEST_PROJECT)

    actual = intent_service.get_temporary_intents(TEST_PROJECT)

    assert actual[0].get("intent") == test_intent["intent"]
    assert actual[0].get("is_temporary")
    assert actual[0].get("mapped_to") is None


def test_add_temporary_intent_with_mapping(
    intent_service: IntentService, data_service: DataService
):
    permanent_intent = "permanent_intent"

    training_data = data_test.TEST_EXAMPLE.copy()
    training_data["intent"] = permanent_intent
    data_service.save_example(user_dict()["username"], TEST_PROJECT, training_data)

    temporary_intent = "intent with mapping"
    test_intent = {"intent": temporary_intent, "mapped_to": permanent_intent}
    intent_service.add_temporary_intent(test_intent, TEST_PROJECT)

    actual = intent_service.get_temporary_intent(temporary_intent, TEST_PROJECT)

    assert actual.get("mapped_to") == permanent_intent


def test_add_temporary_intent_with_invalid_mapping(intent_service):
    test_intent = {"intent": "my intent", "mapped_to": "not existing"}

    with pytest.raises(ValueError):
        intent_service.add_temporary_intent(test_intent, TEST_PROJECT)


def test_update_temporary_intent(intent_service: IntentService):
    temporary_intent = "test update temporary intent"
    test_intent = {"intent": temporary_intent, "mapped_to": "permanent_intent"}

    intent_service.add_temporary_intent(test_intent, TEST_PROJECT)

    test_intent["mapped_to"] = None
    intent_service.update_temporary_intent(
        test_intent[INTENT_NAME_KEY], test_intent, TEST_PROJECT
    )

    actual = intent_service.get_temporary_intent(temporary_intent, TEST_PROJECT)

    assert actual.get("mapped_to") is None


def test_update_with_mapped_to_none(
    intent_service: IntentService, data_service: DataService
):
    # Create permanent intent by inserting training example
    permanent_intent = "test update with mapped to none"
    test_hash = data_test.TEST_RESULT["hash"]
    training_data = data_test.TEST_EXAMPLE.copy()
    training_data["intent"] = permanent_intent
    data_service.save_example(user_dict()["username"], TEST_PROJECT, training_data)

    # Add temporary intent including a mapping to the permanent intent
    test_intent_name = "temporary intent for test with mapped to none"
    test_intent = {
        INTENT_NAME_KEY: test_intent_name,
        INTENT_MAPPED_TO_KEY: permanent_intent,
    }
    intent_service.add_temporary_intent(test_intent, TEST_PROJECT)

    # Add a training example to this temporary intent.
    intent_service.add_example_to_temporary_intent(
        test_intent_name, test_hash, TEST_PROJECT
    )

    # Update the temporary intent with the intent mapping being set to `None`
    test_intent[INTENT_MAPPED_TO_KEY] = None
    intent_service.update_temporary_intent(test_intent_name, test_intent, TEST_PROJECT)

    # Assert that the related training example was removed.
    assert not data_service.get_example_by_hash(TEST_PROJECT, test_hash)


def test_update_with_mapped_to_different(
    intent_service: IntentService, data_service: DataService
):
    # Create permanent intent by inserting training example
    permanent_intent = "test update with mapped to different"
    test_hash = data_test.TEST_RESULT["hash"]
    training_data = data_test.TEST_EXAMPLE.copy()
    training_data["intent"] = permanent_intent
    data_service.save_example(user_dict()["username"], TEST_PROJECT, training_data)

    # Create another permanent intent by inserting training example
    permanent_intent2 = "test update with mapped to different2"
    training_data2 = training_data.copy()
    training_data2["intent"] = permanent_intent2
    training_data2["text"] = "some other test"
    data_service.save_example(user_dict()["username"], TEST_PROJECT, training_data2)

    # Add temporary intent with mapping
    test_intent_name = "temporary intent for mapping to other test"
    test_intent = {
        INTENT_NAME_KEY: test_intent_name,
        INTENT_MAPPED_TO_KEY: permanent_intent,
    }
    intent_service.add_temporary_intent(test_intent, TEST_PROJECT)

    # Add a training example to this temporary intent
    intent_service.add_example_to_temporary_intent(
        test_intent_name, test_hash, TEST_PROJECT
    )
    assert (
        data_service.get_example_by_hash(TEST_PROJECT, test_hash)["intent"]
        == permanent_intent
    )

    # Update temporary intent with different mapping
    test_intent[INTENT_MAPPED_TO_KEY] = permanent_intent2
    intent_service.update_temporary_intent(test_intent_name, test_intent, TEST_PROJECT)

    # Assert that the intent in the training data was updated
    assert (
        data_service.get_example_by_hash(TEST_PROJECT, test_hash)["intent"]
        == permanent_intent2
    )


def test_delete_temporary_intent(intent_service: IntentService):
    test_intent = {"intent": "test delete temporary"}
    intent_service.add_temporary_intent(test_intent, TEST_PROJECT)

    intent_service.delete_temporary_intent(test_intent["intent"], TEST_PROJECT)

    assert not intent_service.get_temporary_intent(test_intent["intent"], TEST_PROJECT)


def test_add_example(intent_service: IntentService):
    test_intent = {"intent": "my intent"}
    intent_service.add_temporary_intent(test_intent, TEST_PROJECT)

    intent_service.add_example_to_temporary_intent(
        test_intent[INTENT_NAME_KEY], "hash", TEST_PROJECT
    )

    actual = intent_service.get_temporary_intent(test_intent["intent"], TEST_PROJECT)

    assert actual == {
        INTENT_NAME_KEY: test_intent[INTENT_NAME_KEY],
        INTENT_EXAMPLES_KEY: ["hash"],
        INTENT_IS_TEMPORARY_KEY: True,
        INTENT_MAPPED_TO_KEY: None,
    }


def test_get_temporary_intents_without_example_hashes(intent_service: IntentService):
    test_intent = {"intent": "my intent"}
    intent_service.add_temporary_intent(test_intent, TEST_PROJECT)

    intent_service.add_example_to_temporary_intent(
        test_intent[INTENT_NAME_KEY], "hash", TEST_PROJECT
    )

    actual = intent_service.get_temporary_intents(
        TEST_PROJECT, include_example_hashes=False
    )

    assert {
        INTENT_NAME_KEY: test_intent[INTENT_NAME_KEY],
        INTENT_IS_TEMPORARY_KEY: True,
        INTENT_MAPPED_TO_KEY: None,
    } in actual


def test_remove_example(intent_service: IntentService):
    test_intent = {"intent": "test remove example"}
    test_hash = "hash"
    intent_service.add_temporary_intent(test_intent, TEST_PROJECT)

    intent_service.add_example_to_temporary_intent(
        test_intent[INTENT_NAME_KEY], test_hash, TEST_PROJECT
    )

    intent_service.remove_example_from_temporary_intent(
        test_intent[INTENT_NAME_KEY], test_hash, TEST_PROJECT
    )

    actual = intent_service.get_temporary_intent(test_intent["intent"], TEST_PROJECT)

    assert actual == {
        INTENT_NAME_KEY: test_intent[INTENT_NAME_KEY],
        INTENT_EXAMPLES_KEY: [],
        INTENT_IS_TEMPORARY_KEY: True,
        INTENT_MAPPED_TO_KEY: None,
    }


def test_get_intents(
    intent_service,
    user_goal_service,
    domain_service,
    logs_service,
    settings_service,
    data_service,
    model_service,
):
    # Create permanent intents by inserting training examples
    test_project = "another test project"
    _create_test_data_for_get_intents(
        test_project,
        settings_service,
        model_service,
        data_service,
        domain_service,
        user_goal_service,
        logs_service,
        intent_service,
    )

    # Assert all intents are retrieved
    expected = [
        {"intent": "intent2", "suggestions": []},
        {
            "example_hashes": ["51601e6f1383c5bc88ff25bfaa080a20"],
            "intent": "intent1",
            "suggestions": ["5d41402abc4b2a76b9719d911017c592"],
            "user_goal": "goal1",
        },
        {"intent": "intent3", "suggestions": []},
        {
            "intent": "intent4",
            "example_hashes": [],
            "is_temporary": True,
            "mapped_to": "intent1",
        },
    ]
    actual = intent_service.get_intents(test_project)

    assert len(actual) == 4
    assert all(e in actual for e in expected)


def _create_test_data_for_get_intents(
    test_project: Text,
    settings_service: SettingsService,
    model_service: ModelService,
    data_service: DataService,
    domain_service: DomainService,
    user_goal_service: UserGoalService,
    logs_service: LogsService,
    intent_service: IntentService,
):
    settings_service.init_project("test_team", test_project)
    insert_test_model(test_project, test_project, model_service)

    # Add intent from log
    user_event = _user_event("X", time.time(), "intent1", test_project)
    logs_service.save_nlu_logs_from_event(json.dumps(user_event))

    training_data = data_test.TEST_EXAMPLE.copy()
    training_data["intent"] = "intent1"
    data_service.save_example(user_dict()["username"], test_project, training_data)

    # Add a user goal for one of these
    user_goal_service.create_user_goal("goal1", test_project)
    user_goal_service.add_intent_to_user_goal("goal1", "intent1", test_project)

    # Add a domain which includes some more intents
    test_domain = {
        "intents": [
            {"intent2": {"use_entities": True}},
            {"intent3": {"use_entities": False}},
        ]
    }
    domain_service.store_domain(test_domain, test_project)

    # Add a temporary intent
    temporary_intent = {"intent": "intent4", "mapped_to": "intent1"}
    intent_service.add_temporary_intent(temporary_intent, test_project)


def test_get_intents_with_temporary_intents_excluded(
    intent_service: IntentService,
    user_goal_service: UserGoalService,
    domain_service: DomainService,
    logs_service: LogsService,
    settings_service: SettingsService,
    data_service: DataService,
    model_service: ModelService,
):
    test_project = "test get intents without temporary intents"
    _create_test_data_for_get_intents(
        test_project,
        settings_service,
        model_service,
        data_service,
        domain_service,
        user_goal_service,
        logs_service,
        intent_service,
    )

    expected = [
        {"intent": "intent2", "suggestions": []},
        {
            "example_hashes": ["51601e6f1383c5bc88ff25bfaa080a20"],
            "intent": "intent1",
            "suggestions": ["5d41402abc4b2a76b9719d911017c592"],
            "user_goal": "goal1",
        },
        {"intent": "intent3", "suggestions": []},
    ]
    actual = intent_service.get_intents(test_project, include_temporary_intents=False)

    assert len(actual) == 3
    assert all([e in expected for e in actual])


@pytest.mark.parametrize(
    "fields",
    [[("example_hashes", False)], [("user_goal", False)], [("suggestions", False)]],
)
def test_get_intents_with_fields(
    intent_service: IntentService,
    user_goal_service: UserGoalService,
    domain_service: DomainService,
    logs_service: LogsService,
    settings_service: SettingsService,
    data_service: DataService,
    model_service: ModelService,
    fields: List[Tuple[Text, bool]],
):

    test_project = str(fields)  # individual project for each test variation
    _create_test_data_for_get_intents(
        test_project,
        settings_service,
        model_service,
        data_service,
        domain_service,
        user_goal_service,
        logs_service,
        intent_service,
    )

    actual = intent_service.get_intents(test_project, fields_query=fields)

    for field, _ in fields:
        assert all([field not in intent for intent in actual])
