import json

import pytest
import time

import tests.unit.services.test_data_service as data_test
from rasax.community import config
from rasax.community.database.conversation import MessageLog
from rasax.community.services.data_service import DataService
from rasax.community.services.logs_service import LogsService
from rasax.community.services.model_service import ModelService
from tests.unit.conftest import _user_event, insert_test_model, user_dict

TEST_MODEL_NAME = "log test model"
TEST_PARSE_DATA = {
    "intent": {"name": "greet", "confidence": 0.956811785697937},
    "entities": [],
    "intent_ranking": [
        {"name": "greet", "confidence": 0.956811785697937},
        {"name": "mood_deny", "confidence": 0.06457871943712234},
    ],
    "text": "This is a log test.",
    "project": config.project_name,
    "model": TEST_MODEL_NAME,
}

TEST_EXPECTED = {
    "id": 1,
    "user_input": {
        "text": TEST_PARSE_DATA["text"],
        "intent": {
            "name": TEST_PARSE_DATA["intent"]["name"],
            "confidence": TEST_PARSE_DATA["intent"]["confidence"],
        },
        "entities": TEST_PARSE_DATA["entities"],
        "intent_ranking": TEST_PARSE_DATA["intent_ranking"],
    },
    "hash": "667d00347b7a50d87abfbd5e6b7cddb8",
    "model": TEST_MODEL_NAME,
    "team": config.team_name,
    "project_id": config.project_name,
}


@pytest.fixture(scope="module")
def logs_service(session):
    # remove logs which were stored during previous tests
    session.query(MessageLog).delete()
    session.commit()

    return LogsService(session)


def test_save_log(logs_service: LogsService, model_service: ModelService):
    insert_test_model(config.project_name, TEST_MODEL_NAME, model_service)
    logs_service.create_log_from_parse_data(TEST_PARSE_DATA)

    actual, total_number = logs_service.fetch_logs()

    assert total_number == 1
    assert actual[0]["time"] > 0

    del actual[0]["time"]

    assert actual[0] == TEST_EXPECTED


def test_with_field_query(logs_service: LogsService):
    fields = [("user_input.intent.name", True), ("id", True)]
    actual, _ = logs_service.fetch_logs(fields_query=fields)

    assert actual[0] == {
        "id": 1,
        "user_input": {"intent": {"name": TEST_PARSE_DATA["intent"]["name"]}},
    }


def test_fetch_with_text(logs_service: LogsService):
    other_parse_data = TEST_PARSE_DATA.copy()
    other_parse_data["text"] = "different text"
    other_parse_data["intent"]["name"] = "other intent"
    logs_service.create_log_from_parse_data(other_parse_data)

    actual, total_number = logs_service.fetch_logs("is")
    del actual[0]["time"]

    assert total_number == 1
    assert actual[0] == TEST_EXPECTED


def test_fetch_with_intent(logs_service: LogsService):
    actual, total_number = logs_service.fetch_logs(intent_query="greet")
    del actual[0]["time"]

    assert total_number == 1
    assert actual[0] == TEST_EXPECTED


def test_get_with_hash(logs_service: LogsService):
    actual = logs_service.get_log_by_hash(TEST_EXPECTED["hash"])

    del actual["time"]
    assert actual == TEST_EXPECTED


def test_save_from_event(logs_service: LogsService):
    test_intent = "test save from event intent"
    test_event = _user_event(
        "test sender", time.time(), test_intent, config.project_name
    )

    logs_service.save_nlu_logs_from_event(json.dumps(test_event))
    logs, _ = logs_service.fetch_logs()
    actual = list(
        filter(lambda l: l["user_input"]["intent"]["name"] == test_intent, logs)
    )[0]

    del actual["time"]
    assert actual["project_id"] == config.project_name
    assert actual["user_input"] == {
        "text": test_event["text"],
        "intent": {"name": test_intent, "confidence": 0.0},
        "intent_ranking": [],
        "entities": [],
    }


def test_archive(logs_service: LogsService):
    logs_service.archive("2")

    actual, _ = logs_service.fetch_logs()

    assert not any([l["id"] == 2 for l in actual])


def test_replace_log(logs_service: LogsService):
    existing, _ = logs_service.fetch_logs()[0]
    replacement = TEST_PARSE_DATA.copy()

    other_intent = "replaced intent name"
    replacement["intent"]["name"] = other_intent
    logs_service.replace_log(existing, replacement)

    expected = TEST_EXPECTED.copy()
    expected["id"] = existing["id"]
    expected["user_input"]["intent"]["name"] = other_intent

    actual, _ = logs_service.fetch_logs()
    del actual[0]["time"]

    assert actual[0] == expected


def test_get_suggestions(logs_service: LogsService, data_service: DataService):
    logs_service.create_log_from_parse_data(TEST_PARSE_DATA)

    another_log = TEST_PARSE_DATA.copy()
    another_log["text"] = "This is already in the training data"

    logs_service.create_log_from_parse_data(another_log)

    # Assure suggestions contain `another log`
    actual, _ = logs_service.get_suggestions()
    assert any([l["user_input"]["text"] == another_log["text"] for l in actual])

    # Add log to training data
    existing_data = data_test.TEST_EXAMPLE.copy()
    existing_data["text"] = another_log["text"]

    data_service.save_example(
        user_dict()["username"], config.project_name, existing_data
    )

    # Assure `another log` is not in suggestions since it is already in
    # training data
    actual, _ = logs_service.get_suggestions()
    assert not any([l["user_input"]["text"] == existing_data["text"] for l in actual])


def test_get_suggestions_without_hardcoded_intents(logs_service: LogsService):
    test_log = TEST_PARSE_DATA.copy()
    test_log["text"] = "/intent_trigger"

    logs_service.create_log_from_parse_data(test_log)

    actual, _ = logs_service.get_suggestions()
    assert not any([l["user_input"]["text"] == test_log["text"] for l in actual])


@pytest.mark.parametrize(
    "event, expected",
    [
        ({"parse_data": [], "text": "lala", "event": "user"}, True),
        ({"text": "some text", "data": "data", "event": "bot"}, False),
    ],
)
def test_is_user_event(event, expected):
    assert LogsService.is_user_uttered_event(event) == expected


async def test_create_log_without_model(logs_service: LogsService):
    # create log not created from a Rasa model
    text = "some text"
    log = {"text": text}
    inserted = logs_service.create_log_from_parse_data(log, created_from_model=False)

    assert inserted
    _id = inserted["id"]

    from rasax.community.utils import get_text_hash

    # inserted log should contain text and no model

    log_hash = get_text_hash(text)
    log = logs_service.get_log_by_hash(log_hash)
    assert log
    assert log["id"] == _id
    assert log["hash"] == log_hash
    assert log["user_input"]["text"] == text
    assert not log["model"]
