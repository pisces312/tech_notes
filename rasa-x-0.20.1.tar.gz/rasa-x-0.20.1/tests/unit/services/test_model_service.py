import asyncio
import os
import time
from typing import Text

import pytest

from rasax.community.database.model import Model
from tests.unit.conftest import insert_test_model
from rasax.community.services.model_service import ModelService

TEST_MODEL_NAME = "test model"
TEST_PROJECT = "default"
TEST_TAG = "test tag"


@pytest.fixture(scope="module")
def model_service(session):
    # remove models which were stored during previous tests
    session.query(Model).delete()
    session.commit()

    return ModelService("path", session, "production")


def test_save_model_data(model_service: ModelService):
    expected = insert_test_model(TEST_PROJECT, TEST_MODEL_NAME, model_service)

    actual = model_service.get_model_by_name(TEST_PROJECT, TEST_MODEL_NAME)

    assert actual["project"] == TEST_PROJECT
    assert actual["model"] == TEST_MODEL_NAME
    assert actual["tags"] == []
    assert actual["hash"] == expected["model_hash"]
    assert actual["version"] == expected["_version"]
    assert actual["trained_at"] == expected["training_time"]
    assert actual["path"] == expected["stored_path"]


async def test_get_models(model_service: ModelService):
    model_service.minimum_compatible_version = asyncio.coroutine(lambda: 1)
    model_service.is_model_compatible = lambda _, model_version: True
    model_service._discover_models = asyncio.coroutine(lambda: True)
    _, number_models = await model_service.get_models(TEST_PROJECT)

    assert number_models == 1


async def test_get_models_with_offset_limit(
    model_service: ModelService, new_project: Text
):
    model_service.minimum_compatible_version = asyncio.coroutine(lambda: 1)
    model_service.is_model_compatible = lambda _, model_version: True

    test_model1 = "test_model1"
    training_time = time.time()
    insert_test_model(
        new_project, test_model1, model_service, training_time=training_time
    )
    test_model2 = "test_model2"
    insert_test_model(
        new_project, test_model2, model_service, training_time=training_time
    )
    insert_test_model(
        new_project, "test_model0", model_service, training_time=training_time - 10
    )

    models, number_models = await model_service.get_models(
        new_project, limit=1, offset=None, discover_models=False
    )

    assert number_models == 3
    assert models[0]["model"] == test_model1

    models, number_models = await model_service.get_models(
        new_project, limit=1, offset=1, discover_models=False
    )
    assert len(models) == 1
    assert number_models == 3
    assert models[0]["model"] == test_model2


def test_tag_model(model_service: ModelService):
    model_service.tag_model(TEST_PROJECT, TEST_MODEL_NAME, TEST_TAG)

    assert model_service.model_for_tag(
        TEST_PROJECT, TEST_TAG
    ) == model_service.get_model_by_name(TEST_PROJECT, TEST_MODEL_NAME)


def test_delete_tag(model_service: ModelService):
    model_service.delete_tag(TEST_PROJECT, TEST_MODEL_NAME, TEST_TAG)

    # flush since following tests are in the same transaction
    model_service.commit()

    assert model_service.model_for_tag(TEST_PROJECT, TEST_TAG) is None
    assert model_service.get_model_by_name(TEST_PROJECT, TEST_MODEL_NAME)["tags"] == []


def test_delete_model(model_service: ModelService):
    model_service.delete_model(TEST_PROJECT, TEST_MODEL_NAME)

    assert model_service.get_model_by_name(TEST_PROJECT, TEST_MODEL_NAME) is None


async def test_delete_not_existing_models_from_db(model_service: ModelService):
    insert_test_model(TEST_PROJECT, TEST_MODEL_NAME, model_service)
    insert_test_model(TEST_PROJECT, "should be deleted", model_service)

    available = ["available", TEST_MODEL_NAME]
    model_service.delete_not_existing_models_from_db(TEST_PROJECT, available)

    actual, number_models = await model_service.get_models(TEST_PROJECT)
    assert number_models == 1
    assert actual[0]["model"] == TEST_MODEL_NAME


def test_create_model_server_url():
    host = "http://rasa-x:5002"
    os.environ["RASA_X_HOST"] = host
    tag = "development"

    actual = ModelService.get_model_server_url(tag)

    assert actual == "http://rasa-x:5002/api/projects/default/models/tags/development"
