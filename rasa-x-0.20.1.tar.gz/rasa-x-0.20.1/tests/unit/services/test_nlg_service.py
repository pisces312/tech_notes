from typing import Dict, Text, Any

import time

from rasax.community import config
from rasax.community.services.nlg_service import NlgService
from rasax.community.services.user_service import UserService, ADMIN
from tests.unit.conftest import TEST_USER

TEST_TEMPLATE = {
    "text": "example text",
    "buttons": [{"title": "button title", "payload": "some payload"}],
    "image": "image.png",
    "elements": [{"key": ["value"]}],
    "attachment": {"key": "value"},
    "template": "my_template",
}

TEST_DOMAIN_ID = 0


def test_save_template(nlg_service: NlgService, user: Dict[Text, Any]):
    current_time = time.time()

    nlg_service.save_template(TEST_TEMPLATE, user["username"], TEST_DOMAIN_ID)
    actual, number_results = nlg_service.fetch_templates()

    assert number_results == 1

    actual = actual[0]
    assert all([actual[k] == TEST_TEMPLATE[k] for k in TEST_TEMPLATE])

    assert actual["annotated_at"] > current_time
    assert actual["annotator_id"] == user["username"]


def test_get_with_text_(nlg_service: NlgService):
    actual, _ = nlg_service.fetch_templates(TEST_TEMPLATE["text"])

    actual = actual[0]
    assert all([actual[k] == TEST_TEMPLATE[k] for k in TEST_TEMPLATE])


def test_get_with_template_name(nlg_service: NlgService):
    actual, _ = nlg_service.fetch_templates(None, TEST_TEMPLATE["template"])

    actual = actual[0]
    assert all([actual[k] == TEST_TEMPLATE[k] for k in TEST_TEMPLATE])


def test_field_query(nlg_service: NlgService):
    actual, _ = nlg_service.fetch_templates(
        None, TEST_TEMPLATE["template"], [("id", True)]
    )

    assert actual[0] == {"id": 1}


def test_multiple_field_query(nlg_service: NlgService):
    actual, _ = nlg_service.fetch_templates(
        None,
        TEST_TEMPLATE["template"],
        [("id", True), ("text", True), ("template", False)],
    )

    assert actual[0] == {"id": 1, "text": TEST_TEMPLATE["text"]}


def test_update_template(nlg_service: NlgService, user_service: UserService):
    # prepare template update
    updated_template = TEST_TEMPLATE.copy()
    updated_template["text"] = "different text"
    updated_template["template"] = "different template"
    current_time = time.time()

    # create another user which will be the new annotator for the template
    other_user = "different annotator"
    user_service.create_user(other_user, "password", config.team_name, ADMIN)
    user = user_service.fetch_user(other_user)

    nlg_service.update_template("1", updated_template, user)

    actual, total_number_results = nlg_service.fetch_templates()

    # check whether the template was actually updated and not just added
    assert total_number_results == 1

    # check whether template was updated correctly
    actual = actual[0]
    assert actual["id"] == 1
    assert all([actual[k] == updated_template[k] for k in updated_template])

    assert actual["annotated_at"] > current_time
    assert actual["annotator_id"] == other_user


def test_delete_template(nlg_service: NlgService):
    nlg_service.delete_template("1")

    assert nlg_service.fetch_templates(TEST_TEMPLATE["text"]) == ([], 0)


def test_limit_offset(nlg_service: NlgService, user: Dict[Text, Any]):
    # insert a couple of templates to be able to test limit and offset
    for i in range(5):
        template = TEST_TEMPLATE.copy()
        template["template"] = str(i)
        nlg_service.save_template(template, user["username"], TEST_DOMAIN_ID)

    # test limit
    actual, number_results = nlg_service.fetch_templates(limit=1)
    assert number_results == 5
    assert len(actual) == 1
    assert actual[0]["template"] == "0"

    # test offset
    actual, number_results = nlg_service.fetch_templates(offset=4)
    assert number_results == 5
    assert len(actual) == 1
    assert actual[0]["template"] == "4"

    # test limit + offset
    actual, number_results = nlg_service.fetch_templates(limit=1, offset=1)
    assert number_results == 5
    assert len(actual) == 1
    assert actual[0]["template"] == "1"


def test_delete_all_templates(nlg_service: NlgService):
    _, total_number = nlg_service.fetch_templates()
    assert total_number > 0

    nlg_service.delete_all_templates()

    assert nlg_service.fetch_templates() == ([], 0)


def test_replace_templates(nlg_service):
    template_1 = {"template": "utter_greet", "text": "Hi there!"}
    template_2 = {"template": "utter_bye", "text": "Peace out!"}
    template_3 = {"template": "utter_deny", "text": "No!"}
    nlg_service.save_template(template_1, TEST_USER, TEST_DOMAIN_ID)
    nlg_service.save_template(template_2, TEST_USER, TEST_DOMAIN_ID)

    new_templates = [template_2, template_3]
    inserted_count = nlg_service.replace_templates(
        new_templates, TEST_USER, TEST_DOMAIN_ID
    )
    assert inserted_count == 2

    updated_templates = [t for t in nlg_service.fetch_templates(None, None, None)[0]]

    assert template_1 not in updated_templates

    assert all(
        dict(template=t["template"], text=t["text"]) in new_templates
        for t in updated_templates
    )


def test_save_custom_template(nlg_service: NlgService, user: Dict[Text, Any]):
    custom_template = {
        "custom": [
            {
                "requestedEntity": "None",
                "response": {"message": "Please find the doctors details"},
            }
        ],
        "template": "utter_result",
    }
    current_time = time.time()

    nlg_service.save_template(custom_template, user["username"], 0)
    actual, number_results = nlg_service.fetch_templates()

    assert number_results == 3

    actual = actual[2]
    assert all([actual[k] == custom_template[k] for k in custom_template])

    assert actual["annotated_at"] > current_time
    assert actual["annotator_id"] == user["username"]
