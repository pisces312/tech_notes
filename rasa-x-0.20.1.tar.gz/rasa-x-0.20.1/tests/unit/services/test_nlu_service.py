import time

from sqlalchemy.orm import Session

from rasax.community import config
from rasax.community.database import NluEvaluationPrediction
from rasax.community.services.model_service import ModelService
from rasax.community.services.evaluation_service import EvaluationService

TEST_EVALUATION = {
    "intent_evaluation": {
        "accuracy": 0.19047619047619047,
        "f1_score": 0.06095238095238095,
        "precision": 0.036281179138321996,
        "predictions": [
            {"intent": "greet", "predicted": "greet", "text": "hey", "confidence": 1.0}
        ],
        "report": "test test test",
    },
    "entity_evaluation": {
        "ner_crf": {
            "report": "test test",
            "precision": 0.7606987393295268,
            "f1_score": 0.812633994625117,
            "accuracy": 0.8721804511278195,
        }
    },
}

TEST_MODEL_NAME = "test nlu model"

TEST_MODEL = {
    "project": config.project_name,
    "model_name": TEST_MODEL_NAME,
    "stored_path": "nlu test filepath",
    "model_hash": "hash",
    "_version": "1.0",
    "training_time": time.time(),
}

TEST_RESULT = {
    "intent_evaluation": TEST_EVALUATION["intent_evaluation"],
    "model": TEST_MODEL_NAME,
}


def test_save_evaluation(
    evaluation_service: EvaluationService, model_service: ModelService
):
    model_service._save_model_data(**TEST_MODEL)

    evaluation_service.persist_evaluation(
        config.project_name, TEST_MODEL_NAME, TEST_EVALUATION
    )

    actual = evaluation_service.evaluation_for_model(
        config.project_name, TEST_MODEL_NAME
    )

    timestamp = actual["intent_evaluation"].pop("timestamp")

    assert timestamp > 0
    assert actual == TEST_RESULT


def test_get_evaluations(evaluation_service: EvaluationService):
    actual = evaluation_service.evaluations(config.project_name)
    actual[0]["intent_evaluation"].pop("timestamp")

    assert actual == [TEST_RESULT]


def test_delete_evaluation(evaluation_service: EvaluationService, session: Session):
    actual = evaluation_service.delete_evaluation(config.project_name, TEST_MODEL_NAME)

    assert actual
    assert evaluation_service.evaluations(config.project_name) == []
    assert session.query(NluEvaluationPrediction).all() == []
