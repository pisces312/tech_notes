from typing import Optional, Dict

import pytest

from rasax.community import config
from rasax.community.services.role_service import (
    RoleService,
    permission_from_route_annotation,
)
from rasax.community.services.user_service import UserService, ADMIN, ANNOTATOR, TESTER


@pytest.mark.run(order=1)
def test_save_role(role_service: RoleService):
    test = "awesome role"
    expected = set(role_service.roles)
    expected.add(test)

    role_service.save_role(test)

    assert set(role_service.roles) == expected


@pytest.mark.run(order=2)
def test_delete_role(role_service: RoleService):
    test = "awesome role"
    role_service.delete_role(test)

    assert test not in role_service.roles


def test_deletion_admin_role(role_service: RoleService):
    with pytest.raises(ValueError):
        role_service.delete_role(ADMIN)


def test_save_permissions(role_service: RoleService):
    test_role = "test_role"
    permissions = ["advanced.modify.roles.create", "basic.view.user.get"]

    role_service.save_role(test_role)
    role_service.save_permissions_for_role(test_role, permissions)

    assert set(role_service.get_role_permissions(test_role)) == set(permissions)


def test_get_permissions(role_service: RoleService):
    expected = set(role_service.api_permissions)
    assert set(role_service.get_role_permissions(ADMIN)) == expected


def test_permission_from_annotation():
    # annotation is associated with correct category
    annotation = "clientEvaluation.update"
    expected = "advanced.modify.{}".format(annotation)
    assert permission_from_route_annotation(annotation) == expected

    # non-existing annotation raises ValueError
    non_existing_annotation = "conversations.nonExisting.update"
    with pytest.raises(ValueError):
        permission_from_route_annotation(non_existing_annotation)


def test_backend_to_frontend_format_roles(role_service: RoleService):
    backend_role = ["chat_master"]

    backend_permissions = [
        "basic.*",
        "deployment_environment.modify.*",
        "conversations.view.metadata.*",
        "conversation.view.clientMessages.list",
        "analytics_dashboard.*",
    ]

    frontend_roles = [
        {
            "role": "chat_master",
            "grants": {
                "deployment_environment": [
                    "create:any",
                    "update:any",
                    "delete:any",
                    "read:any",
                ],
                "conversations": ["read:any"],
                "analytics_dashboard": ["read:any"],
                "basic": ["create:any", "update:any", "delete:any", "read:any"],
            },
            "is_default": False,
            "description": None,
        }
    ]
    role_service.save_role(backend_role[0])
    role_service.save_permissions_for_role(backend_role[0], backend_permissions)
    transformed = role_service.backend_to_frontend_format_roles(backend_role)

    assert frontend_roles == transformed


def test_frontend_to_backend_format_permissions(role_service: RoleService):
    frontend_permissions = {
        "deployment_environment": [
            "create:any",
            "update:any",
            "delete:any",
            "read:any",
        ],
        "conversations": ["read:any"],
        "test_conversation": ["read:any"],
    }

    backend_permissions = [
        "conversations.view.metadata.list",
        "conversations.view.conversationPolicies.list",
        "conversations.view.conversationEntities.list",
        "conversations.view.logs.list",
        "conversations.view.conversationIntents.list",
        "conversations.view.conversationActions.list",
        "conversations.view.clientEvaluation.get",
        "test_conversation.view.clientMessages.list",
        "test_conversation.view.clients.get",
        "test_conversation.view.metadata.get",
        "test_conversation.view.messages.create",
        "test_conversation.view.actionPrediction.get",
        "deployment_environment.view.environments.list",
        "deployment_environment.modify.environments.update",
    ]

    transformed = role_service.frontend_to_backend_format_permissions(
        frontend_permissions
    )
    assert set(backend_permissions) == set(transformed)


def test_delete_permissions_for_role(role_service: RoleService):
    assert len(role_service.get_role_permissions("test_role")) == 2
    role_service.delete_permissions_for_role("test_role")
    assert role_service.get_role_permissions("test_role") == []


def test_fetch_role_users(role_service: RoleService, user_service: UserService):
    username = "usr"
    password = "pw"
    team = "team1"
    role = TESTER
    user_service.create_user(username, password, team, role)
    assert role_service.fetch_role_users(role)[0]["username"] == username

    username2 = "usr2"
    password2 = "pw2"
    user_service.create_user(username2, password2, team, role)
    assert role_service.fetch_role_users(role)[0]["username"] == username
    assert role_service.fetch_role_users(role)[1]["username"] == username2


def test_count_role_users(role_service: RoleService, user_service: UserService):
    username2 = "usr200"
    password2 = "pw200"
    team2 = "team12"
    role = TESTER
    user_service.create_user(username2, password2, team2, role)
    assert role_service.count_role_users(role) == 3


def test_count_role_users_without_users(role_service: RoleService):
    no_users_role = "no_users"
    role_service.save_role(no_users_role)
    assert role_service.count_role_users("no_users") == 0


def test_update_role_name(role_service: RoleService, user_service: UserService):
    new_name = "special_guest"
    old_name = TESTER
    expected = set(role_service.roles)
    role_service._update_role_name(new_name, old_name, user_service)
    expected.discard(old_name)
    expected.add(new_name)
    assert set(role_service.roles) == expected

    # old role should no longer exist
    assert not role_service.get_role(old_name)


def test_update_role_changing_name_and_permissions(
    role_service: RoleService, user_service: UserService
):
    role = "special_guest"
    new_name = "vip"
    expected = set(role_service.roles)
    permissions = {
        "deployment_environment": [
            "create:any",
            "update:any",
            "delete:any",
            "read:any",
        ],
        "conversations": ["read:any"],
        "test_conversation": ["read:any"],
    }

    # updating role changing name and permissions
    role_service.update_role(role, new_name, permissions, user_service)
    expected.add(new_name)
    expected.discard(role)
    permissions_expected = role_service.frontend_to_backend_format_permissions(
        permissions
    )
    permissions_expected.extend(role_service.expand_wildcard_permissions(["basic.*"]))
    assert set(role_service.get_role_permissions(new_name)) == set(permissions_expected)
    assert set(role_service.roles) == expected


def test_update_non_existing_role(role_service: RoleService, user_service: UserService):
    # updating role that doesn't exist (create new)
    role = "special_guest"
    expected = set(role_service.roles)
    permissions = {
        "deployment_environment": [
            "create:any",
            "update:any",
            "delete:any",
            "read:any",
        ],
        "conversations": ["read:any"],
        "test_conversation": ["read:any"],
    }

    role_service.update_role(role, role, permissions, user_service)
    expected.add(role)
    permissions_expected = role_service.frontend_to_backend_format_permissions(
        permissions
    )
    permissions_expected.extend(role_service.expand_wildcard_permissions(["basic.*"]))
    assert set(role_service.roles) == expected
    assert set(role_service.get_role_permissions(role)) == set(permissions_expected)


def test_update_role_permissions_only(
    role_service: RoleService, user_service: UserService
):
    permissions2 = {
        "deployment_environment": ["create:any", "update:any", "delete:any", "read:any"]
    }

    role = "special_guest"
    expected = set(role_service.roles)
    # updating role without changing name
    role_service.update_role(role, role, permissions2, user_service)
    assert set(role_service.roles) == expected
    permissions2_expected = role_service.frontend_to_backend_format_permissions(
        permissions2
    )
    permissions2_expected.extend(role_service.expand_wildcard_permissions(["basic.*"]))
    assert set(role_service.get_role_permissions(role)) == set(permissions2_expected)


def test_update_role_name_only(role_service: RoleService, user_service: UserService):
    role = "special_guest"
    expected = set(role_service.roles)
    # updating role name only
    role_service.update_role(role, "super_user", None, user_service)
    expected.add("super_user")
    expected.discard(role)
    assert set(role_service.roles) == expected
    assert set(role_service.get_role_permissions("super_user")) == set()


def test_create_role(role_service: RoleService):
    role = "goofie"
    permissions = {"conversations": ["read:any"], "test_conversation": ["read:any"]}
    expected = set(role_service.roles)
    role_service.create_role(role, permissions)
    permissions = role_service.frontend_to_backend_format_permissions(permissions)
    permissions.extend(role_service.expand_wildcard_permissions(["basic.*"]))
    assert set(role_service.get_role_permissions(role)) == set(permissions)
    expected.add(role)
    assert set(role_service.roles) == expected


def test_update_role_users(role_service: RoleService, user_service: UserService):
    # create random new role
    new_role = "goofie2"
    permissions = {"conversations": ["read:any"], "test_conversation": ["read:any"]}
    role_service.create_role(new_role, permissions)

    # create users with annotator role
    annotator_users = ["user1", "user2", "user3"]
    for user in annotator_users:
        user_service.create_user(user, "pw", "team", ANNOTATOR)

    # create users with new_role
    new_role_users = ["user4", "user5", "user6"]
    for user in new_role_users:
        user_service.create_user(user, "pw", "team", new_role)

    # update annotator role users to be just new_role_users
    role_service.update_role_users(ANNOTATOR, None, new_role_users, user_service)

    # make sure new annotator users are former new_role_users
    new_annotator_users = role_service.fetch_role_users(ANNOTATOR)
    assert [user["username"] for user in new_annotator_users] == new_role_users


def test_get_default_role(role_service: RoleService, user_service: UserService):
    # no default role initially
    assert not role_service.get_default_role()

    # create role and set to default
    new_role = "goofie3"
    permissions = {"conversations": ["read:any"], "test_conversation": ["read:any"]}
    role_service.create_role(new_role, permissions, is_default=True)

    assert role_service.get_default_role() == new_role

    # only `new_role` has `is_default` True
    roles = role_service.roles
    assert new_role in roles
    for role in roles:
        if role == new_role:
            assert role_service.get_role(role).is_default
        else:
            assert not role_service.get_role(role).is_default

    # update the `is_default` tag
    role_service.update_role(
        new_role, new_role, permissions, user_service, is_default=False
    )

    assert not role_service.get_default_role()


def test_role_descriptions(role_service: RoleService):
    # create role and set to default
    new_role = "goofie4"
    description = "test description"
    permissions = {"conversations": ["read:any"], "test_conversation": ["read:any"]}
    role_service.create_role(
        new_role, permissions, description=description, is_default=True
    )

    assert role_service.get_role(new_role).description == description

    # update the description
    new_description = "some new description"
    role_service._update_role_description(new_role, new_description)
    assert role_service.get_role(new_role).description == new_description


@pytest.mark.parametrize(
    "user, is_allowed",
    [
        (None, False),
        ({}, False),
        ({"roles": []}, False),
        ({"roles": ["one", "two"]}, False),
        ({"roles": ["admin"]}, True),
        ({"roles": ["annotator", "user"]}, False),
    ],
)
def test_is_user_allowed_to_view_all_conversations(
    user: Optional[Dict], is_allowed: bool, role_service: RoleService
):
    assert role_service.is_user_allowed_to_view_all_conversations(user) is is_allowed
