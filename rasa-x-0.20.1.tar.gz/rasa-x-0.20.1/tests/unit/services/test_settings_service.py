import json
import os

import pytest

from ruamel.yaml.compat import ordereddict

import rasax.community.utils
from rasax.community import config
from rasax.community.utils import load_yaml
from rasax.community.services.settings_service import (
    SettingsService,
    default_stack_config,
    default_environments_config_local,
    ProjectException,
)
from rasa.nlu.config import InvalidConfigError

TEST_PROJECT = "test project"
TEST_TEAM = "test team"


def default_environments_config():
    stack_config = ordereddict(
        [
            (
                "production",
                ordereddict(
                    [
                        ("url", "http://rasa-production:5005"),
                        ("token", config.rasa_token),
                    ]
                ),
            ),
            (
                "development",
                ordereddict(
                    [
                        ("url", "http://rasa-development:5005"),
                        ("token", config.rasa_token),
                    ]
                ),
            ),
            (
                "worker",
                ordereddict(
                    [("url", "http://rasa-worker:5005"), ("token", config.rasa_token)]
                ),
            ),
        ]
    )

    return {"environments": ordereddict([("rasa", stack_config)])}


def test_project_init(settings_service: SettingsService):
    settings_service.init_project(TEST_TEAM, TEST_PROJECT)

    actual = settings_service.get(TEST_TEAM, TEST_PROJECT)

    assert actual["config"] == default_stack_config()


def test_project_init_already_exists(settings_service: SettingsService):
    # create new project and check it exists
    project = "new project"
    settings_service.init_project(TEST_TEAM, project)
    assert settings_service.get(TEST_TEAM, project)

    # creating the same project again fails
    with pytest.raises(ProjectException):
        settings_service.init_project(TEST_TEAM, project)


def test_save_config(settings_service: SettingsService):
    test_config = default_stack_config()
    test_config["extra"] = "extra value"

    settings_service.save_config(TEST_TEAM, TEST_PROJECT, test_config)

    actual = settings_service.get_config(TEST_TEAM, TEST_PROJECT)

    assert actual == test_config


def test_get_config_for_invalid_project(settings_service: SettingsService):
    test_config = default_stack_config()
    test_config["extra"] = "extra value"

    assert not settings_service.get_config(TEST_TEAM, "not existing project")


def test_get_stack_services(settings_service: SettingsService):
    default_env = default_environments_config()["environments"]["rasa"]

    settings_service.save_environments_config(
        TEST_PROJECT, default_environments_config().get("environments")
    )

    actual = settings_service.stack_services(TEST_PROJECT)

    assert len(actual) == len(default_env)

    for k, v in default_env.items():
        assert actual[k].stack_endpoint.token == v["token"]
        assert actual[k].stack_endpoint.url == v["url"]


@pytest.mark.parametrize(
    "environment_config",
    [default_environments_config(), default_environments_config_local(1234)],
)
def test_inspect_valid_environment_config(environment_config):
    default_env = environment_config["environments"]

    assert SettingsService.inspect_environments_config(default_env) is None


def test_invalid_environment_config_without_rasa_key():
    default_env = default_environments_config()["environments"]
    default_env["other_key"] = default_env.pop("rasa")

    with pytest.raises(ValueError):
        SettingsService.inspect_environments_config(default_env)


@pytest.mark.parametrize("environment", ["production", "worker"])
def test_invalid_environment_config_without_minimal_instances(environment):
    default_env = default_environments_config()["environments"]
    del default_env["rasa"][environment]

    with pytest.raises(ValueError):
        SettingsService.inspect_environments_config(default_env)


def test_extra_environments_with_enterprise():
    default_env = default_environments_config()["environments"]
    default_env["rasa"]["another"] = default_env["rasa"]["production"]

    assert SettingsService.inspect_environments_config(default_env) is None


def test_extra_environments_with_rasa_ce():
    default_env = default_environments_config()["environments"]
    default_env["rasa"]["another"] = default_env["rasa"]["production"]

    # path to pretend we don't have enterprise installed
    rasax.community.utils.is_enterprise_installed = lambda: False

    with pytest.raises(ValueError):
        SettingsService.inspect_environments_config(default_env)

    # revert patch
    rasax.community.utils.is_enterprise_installed = lambda: True


def test_save_environment_config(settings_service: SettingsService):
    default_env = default_environments_config()["environments"]
    test_project = "default"

    settings_service.save_environments_config(test_project, default_env)

    assert settings_service.get_environments_config(test_project)
    assert len(settings_service.stack_services(test_project)) == len(
        default_environments_config()["environments"]["rasa"]
    )


def test_delete_environment_config(settings_service: SettingsService):
    default_env = default_environments_config()["environments"]
    test_project = "default"

    settings_service.save_environments_config(test_project, default_env)

    settings_service.delete_environment_config("production", test_project)

    actual = settings_service.get_environments_config(test_project)

    assert "production" not in actual["environments"]["rasa"]


def test_save_local_password(settings_service: SettingsService):
    password = "my password"

    assert not settings_service.get_local_password()

    settings_service.save_local_password(password)

    assert settings_service.get_local_password() == password


def test_update_local_password(settings_service: SettingsService):
    settings_service.save_local_password("password")

    updated_password = "updated password"
    settings_service.save_local_password(updated_password)

    assert settings_service.get_local_password() == updated_password


def test_inject_environments_config_from_file(settings_service, tmpdir):
    from rasa.utils.io import write_yaml_file

    environments_config = default_environments_config()["environments"]
    environments_file_path = os.path.join(tmpdir, "environments.yml")
    write_yaml_file(environments_config, environments_file_path)

    test_project = config.project_name
    settings_service.inject_environments_config_from_file(
        test_project, environments_file_path
    )

    # Get rid of the `ordereddict` types
    expected = json.loads(json.dumps(environments_config))

    assert (
        settings_service.get_environments_config(test_project)["environments"]
        == expected
    )


def test_failing_inject_environments_config_from_file(settings_service):
    test_project = config.project_name
    old_config = settings_service.get_environments_config(test_project)
    settings_service.inject_environments_config_from_file(
        test_project, "not existing path"
    )

    assert settings_service.get_environments_config(test_project) == old_config


def test_passing_inspect_config(settings_service):
    _config = """
    language: en
    pipeline: supervised_embeddings
    policies:
      - name: MemoizationPolicy
      - name: KerasPolicy
      - name: MappingPolicy
            """
    yaml_config = load_yaml(_config)

    settings_service.inspect_config(yaml_config)


def test_failing_inspect_config(settings_service):
    """Assert inspect_config() fails when config is invalid"""

    _config = """
    language: en
    policies:
      - name: MemoizationPolicy
      - name: KerasPolicy
      - name: MappingPolicy
            """

    yaml_config = load_yaml(_config)

    with pytest.raises(InvalidConfigError):
        settings_service.inspect_config(yaml_config)
