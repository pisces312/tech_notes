import pytest
from aioresponses import aioresponses
from typing import Text, Dict, Optional

from rasax.community.constants import SHARE_YOUR_BOT_CHANNEL_NAME, DEFAULT_CHANNEL_NAME
from rasax.community.services.stack_service import StackService
from rasax.community import utils
from rasax.community.services.user_service import GUEST
from tests.unit.conftest import TEST_STACK_URL


@pytest.mark.parametrize(
    "fingerprint_payload, result", [({}, False), ({"some": "fingerprint"}, True)]
)
async def test_active_model(
    stack_service: StackService, fingerprint_payload: Dict[Text, Text], result: bool
):
    status_url = "{}/status".format(TEST_STACK_URL)
    with aioresponses() as mocked:
        mocked.get(
            status_url, payload={"model": "path", "fingerprint": fingerprint_payload}
        )
        has_active_model = await stack_service.has_active_model()
        assert has_active_model is result


@pytest.mark.parametrize(
    "user, expected_channel",
    [
        ({"user": {"roles": [GUEST]}}, SHARE_YOUR_BOT_CHANNEL_NAME),
        ({"user": {"roles": ["some role", "another role"]}}, DEFAULT_CHANNEL_NAME),
    ],
)
def test_get_input_channel_from_bearer(user: Dict, expected_channel: Optional[Text]):
    bearer_token = utils.bearer_token(user)

    assert StackService._get_input_channel_from_bearer(bearer_token) == expected_channel
