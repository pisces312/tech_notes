from typing import Any, Text, Dict

import time

from rasax.community.config import team_name
from rasax.community.services.domain_service import DomainService
from rasax.community.services.settings_service import SettingsService
from rasax.community.services.story_service import StoryService
from tests.unit.conftest import TEST_USER, STORY_PATH
from tests.unit.services.test_domain_service import TEST_DOMAIN, TEST_PROJECT

TEST_STORY_NAME_1 = "Test Story"
TEST_STORY_NAME_2 = "Test Story 2"
TEST_STORY_NAME_3 = "Test Story 3"
TEST_FILENAME = "test story filename"

TEST_STORY = """
## {}
* intent1
  - action1
  - action2
* intent2
  - action1

## {}
* intent_other
  - action_other
""".format(
    TEST_STORY_NAME_1, TEST_STORY_NAME_2
)


async def test_save_story(story_service: StoryService, user: Dict[Text, Any]):
    current_time = time.time()
    await story_service.save_stories(
        TEST_STORY,
        user["team"],
        TEST_FILENAME,
        username=user["username"],
        dump_stories_in_local_mode=False,
    )

    actual = story_service.fetch_stories()

    assert len(actual) == 2
    assert actual[0]["name"] == TEST_STORY_NAME_1
    assert actual[1]["name"] == TEST_STORY_NAME_2

    for story in actual:
        assert story["story"] in TEST_STORY
        assert story["annotation"]["user"] == user["username"]
        assert story["annotation"]["time"] > current_time


def test_get_story_with_text_query(story_service: StoryService):
    query = "other"
    actual = story_service.fetch_stories(query)

    assert len(actual) == 1
    assert actual[0]["name"] == TEST_STORY_NAME_2


def test_get_story_with_filename(story_service: StoryService):
    actual = story_service.fetch_stories(filename=TEST_FILENAME)

    assert len(actual) == 2


def test_get_story_with_invalid_text_query(story_service: StoryService):
    query = "lorem ipsum"
    actual = story_service.fetch_stories(query)

    assert not actual


def test_get_stories_with_fields(story_service: StoryService, user: Dict[Text, Any]):
    fields = [("id", True), ("annotation.user", True)]

    actual = story_service.fetch_stories(field_query=fields)

    assert len(actual) == 2
    assert actual[0]["id"] == 1
    assert actual[1]["id"] == 2

    assert all(story["annotation"]["user"] == user["username"] for story in actual)


async def test_update_story(story_service: StoryService, user: Dict[Text, Any]):
    other_story_name = "other story"
    other_story = """
    ## {}
    * intent
      - action
    """.format(
        other_story_name
    )

    story_service._dump_stories_in_local_mode = lambda: True

    await story_service.update_story("1", other_story, user)
    actual = story_service.fetch_stories()

    assert len(actual) == 2
    assert actual[0]["story"] in other_story
    assert actual[0]["name"] == other_story_name


async def test_replace_stories(story_service: StoryService, user: Dict[Text, Any]):
    replacement_story = """
    ## replacement
    * intent
      - action
    """
    await story_service.replace_stories(
        replacement_story, user["team"], TEST_FILENAME, username=user["username"]
    )

    actual = story_service.fetch_stories()

    assert len(actual) == 1
    assert actual[0]["name"] == "replacement"


def test_get_filenames(story_service: StoryService, user: Dict[Text, Any]):
    assert story_service.get_filenames(user["team"]) == [TEST_FILENAME]


def test_delete_story(story_service: StoryService):
    assert story_service.delete_story("1")
    assert not story_service.fetch_stories()


async def test_slot_values(story_service: StoryService, user: Dict[Text, Any]):
    string_with_hash = "some_entity_value_with_a_#_in_it"
    story = """
    ## Story 1
    * some_intent{{"some_entity": "{}"}}
      - slot{{"some_slot": "{}"}}
      - action
    """.format(
        string_with_hash, string_with_hash
    )
    # insert story
    inserted_stories = await story_service.save_stories(
        story,
        user["team"],
        TEST_FILENAME,
        username=user["username"],
        dump_stories_in_local_mode=False,
    )
    assert len(inserted_stories) == 1


async def test_domain_items_from_story(
    story_service: StoryService, user: Dict[Text, Any]
):
    story_title = TEST_STORY_NAME_3
    action = "some_action"
    intent = "some_intent"
    slot = "some_slot"
    entity = "some_entity"

    story = """
    ## {}
    * {}{{"{}": "some_entity_value"}}
      - {}
      - slot{{"{}": "some_slot_value"}}
    """.format(
        story_title, intent, entity, action, slot
    )
    # insert story
    inserted_stories = await story_service.save_stories(
        story,
        user["team"],
        TEST_FILENAME,
        username=user["username"],
        dump_stories_in_local_mode=False,
    )

    assert inserted_stories
    story_id = inserted_stories[0]["id"]

    # fetch items from story
    items = await story_service._fetch_domain_items_from_story(story_id)
    for i, item in enumerate((action, intent, slot, entity)):
        assert items[i] == set([item])


async def test_add_domain_items_for_story(
    story_service: StoryService,
    domain_service: DomainService,
    settings_service: SettingsService,
):
    # fetch id of previously inserted story
    story_id = story_service.fetch_stories(TEST_STORY_NAME_3)[0]["id"]

    # make sure there's a domain
    settings_service.init_project(team_name, TEST_PROJECT)
    domain_service.store_domain(
        TEST_DOMAIN, TEST_PROJECT, username=TEST_USER, store_templates=True
    )

    # add this story's items to the domain
    await story_service.add_domain_items_for_story(story_id, project_id=TEST_PROJECT)

    story_items = await story_service._fetch_domain_items_from_story(story_id)

    # make sure all items are in domain
    # check raw domain dict as well as dedicated methods
    domain = domain_service.get_domain(TEST_PROJECT)
    assert domain

    # actions
    action = list(story_items[0])[0]
    assert action in domain["actions"]
    assert action in domain_service.get_actions_from_domain(TEST_PROJECT)

    # intents
    intent = list(story_items[1])[0]
    assert any(intent in _intent.keys() for _intent in domain["intents"])
    assert intent in domain_service.get_intents_from_domain(TEST_PROJECT)

    # slots
    slot = list(story_items[2])[0]
    assert slot in domain["slots"].keys()
    assert slot in domain_service.get_slots_from_domain(TEST_PROJECT)

    # entities
    entity = list(story_items[3])[0]
    assert entity in domain["entities"]
    assert entity in domain_service.get_entities_from_domain(TEST_PROJECT)


async def test_inject_stories_from_file(story_service: StoryService):
    # delete all stories
    await story_service.delete_stories(team_name)
    assert not story_service.fetch_stories()

    # inject stories from file
    await story_service.save_stories_from_files([STORY_PATH], team_name, TEST_USER)
    assert story_service.fetch_stories()


async def test_addition_of_default_actions_to_domain(
    story_service: StoryService, user: Dict[Text, Any]
):
    from rasa.core.actions.action import ActionDefaultFallback

    # save story with default action and another action
    default_action = ActionDefaultFallback().name()
    another_action = "some_other_action"
    story = """
    ## story___1
    * intent1
      - {}
      - {}
    """.format(
        default_action, another_action
    )

    inserted_stories = await story_service.save_stories(
        story, user["team"], add_story_items_to_domain=True
    )
    assert inserted_stories
    story_id = inserted_stories[0]["id"]

    # test that `default_action` is not in domain, but `another_action` is
    domain_actions = (await story_service._fetch_domain_items_from_story(story_id))[0]
    assert default_action not in domain_actions
    assert another_action in domain_actions
