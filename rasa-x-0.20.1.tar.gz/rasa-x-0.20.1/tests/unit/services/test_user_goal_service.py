from rasax.community import config
from rasax.community.services.user_goal_service import UserGoalService, GOAL_INTENTS_KEY

TEST_PROJECT = config.project_name


def test_add_user_goal(user_goal_service: UserGoalService):
    test_user_goal = "test"
    user_goal_service.create_user_goal(test_user_goal, TEST_PROJECT)
    user_goals = user_goal_service.get_user_goals(TEST_PROJECT)

    assert len(user_goals) == 1
    assert user_goals[0][GOAL_INTENTS_KEY] == []


def test_delete_user_goal(user_goal_service: UserGoalService):
    test_user_goal = "test"
    user_goal_service.create_user_goal(test_user_goal, TEST_PROJECT)
    user_goal_service.delete_user_goal(test_user_goal, TEST_PROJECT)

    user_goals = user_goal_service.get_user_goals(TEST_PROJECT)

    assert len(user_goals) == 0


def test_append_intent_to_user_goal(user_goal_service: UserGoalService):
    test_user_goal = "test"
    intent1 = "intent1"
    intent2 = "intent2"
    user_goal_service.create_user_goal(test_user_goal, TEST_PROJECT)
    user_goal_service.add_intent_to_user_goal(test_user_goal, intent1, TEST_PROJECT)
    user_goal_service.add_intent_to_user_goal(test_user_goal, intent2, TEST_PROJECT)

    user_goals = user_goal_service.get_user_goals(TEST_PROJECT)

    assert user_goals[0][GOAL_INTENTS_KEY] == [intent1, intent2]


def test_remove_intent_from_user_goal(user_goal_service: UserGoalService):
    test_user_goal = "test"
    intent1 = "intent1"
    intent2 = "intent2"

    user_goal_service.remove_intent_from_user_goal(
        test_user_goal, intent1, TEST_PROJECT
    )
    user_goals = user_goal_service.get_user_goals(TEST_PROJECT)

    assert user_goals[0][GOAL_INTENTS_KEY] == [intent2]
