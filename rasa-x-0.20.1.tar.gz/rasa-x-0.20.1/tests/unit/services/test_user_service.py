import time

import pytest

from rasax.community import config
from rasax.community.constants import COMMUNITY_USERNAME, COMMUNITY_TEAM_NAME
from rasax.community.services.role_service import (
    RoleService,
    _strip_category_from_permissions,
)
from rasax.community.services.settings_service import SettingsService
from rasax.community.services.user_service import (
    UserException,
    UserService,
    has_role,
    ADMIN,
    ANNOTATOR,
    TESTER,
    RoleException,
)


def test_create_admin(user_service: UserService, role_service: RoleService):
    username = "username"
    password = "password"
    team = "team"
    role = ADMIN
    user_service.create_user(username, password, team, role)
    user = user_service.login(username, password)
    assert user.get("username") == username
    assert user.get("team") == team
    assert user.get("roles") == [role]
    assert user.get("projects") == [{"name": "default", "roles": [ADMIN]}]

    expected = role_service.default_roles[ADMIN]
    expected = role_service.expand_wildcard_permissions(expected)
    expected = _strip_category_from_permissions(expected)
    assert set(user.get("permissions")) == set(expected)


def test_create_existing_user(user_service: UserService):
    username = "username"
    password = "pw2"
    team = "team2"
    role = ADMIN
    with pytest.raises(UserException) as e:
        user_service.create_user(username, password, team, role)
        assert e == username


def test_admin_change_password(user_service: UserService):
    username = "username"
    password = "pass-w0rd"
    user = user_service.admin_change_password(username, password)
    assert user.get("username") == username
    assert user.get("team") == "team"
    assert user.get("projects") == [{"name": "default", "roles": [ADMIN]}]


def test_password_change_updates_local_password(
    user_service: UserService, settings_service: SettingsService
):
    # create community user
    user_service.insert_or_update_user(COMMUNITY_USERNAME, "pw", COMMUNITY_TEAM_NAME)
    assert user_service.fetch_user(COMMUNITY_USERNAME)

    # update password of community user
    password = "pass-w0rd"
    _ = user_service.admin_change_password(COMMUNITY_USERNAME, password)

    # local password row should be updated
    assert settings_service.get_local_password() == password

    # delete community user for future tests
    user_service.delete_user(COMMUNITY_USERNAME)
    assert not user_service.fetch_user(COMMUNITY_USERNAME)


def test_admin_change_password_wrong_user(user_service: UserService):
    username = "USER-NAME"
    password = "pw2"
    with pytest.raises(UserException) as e:
        user_service.admin_change_password(username, password)
        assert e == username


def test_admin_delete_user(user_service: UserService):
    username = "user_to_delete"
    password = "pw123"
    team = "team2"
    role = ADMIN
    user_service.create_user(username, password, team, role)

    # creation is successful
    user = user_service.fetch_user(username)
    assert user.get("username") == username

    # deletion is successful
    user_service.delete_user(username)
    user = user_service.fetch_user(username)
    assert user is None


def test_user_cannot_delete_itself(user_service: UserService):
    username = "some user 111"
    password = "pw123"
    team = "team2"
    role = ADMIN
    user_service.create_user(username, password, team, role)

    # creation is successful
    user = user_service.fetch_user(username)
    assert user.get("username") == username

    # user cannot delete itself
    with pytest.raises(UserException) as e:
        user_service.delete_user(username, requesting_user=username)
        assert e == username

    # delete user
    user_service.delete_user(username)


def test_admin_list_users(user_service: UserService):
    usernames = ["u_name1", "user_alpha", "user_beta"]
    password = "pw123"
    team = "team2"
    role = ADMIN

    for u in usernames:
        user_service.create_user(u, password, team, role)

    users = user_service.fetch_all_users(team)
    assert len(users) == len(usernames)
    assert all(u["username"] in usernames for u in users)


def test_create_normal_user(user_service: UserService, role_service: RoleService):
    username = "usr"
    password = "pw"
    team = "team1"
    role = TESTER
    user_service.create_user(username, password, team, role)
    user = user_service.login(username, password)
    assert user.get("username") == username
    assert user.get("team") == team
    assert user.get("projects") == [{"name": "default", "roles": [TESTER]}]

    expected = role_service.default_roles[TESTER]
    expected = role_service.expand_wildcard_permissions(expected)
    expected = _strip_category_from_permissions(expected)
    assert set(user.get("permissions")) == set(expected)


def test_create_me_user_not_enterprise(user_service: UserService):
    import rasax.community.utils

    # Patch function
    rasax.community.utils.is_enterprise_installed = lambda: False

    username = "me"
    password = "pw"
    team = "team1"
    role = TESTER
    user_service.create_user(username, password, team, role)

    assert user_service.fetch_user(username)

    # Revert patch
    rasax.community.utils.is_enterprise_installed = lambda: True


def test_create_user_not_enterprise(user_service: UserService):
    import rasax.community.utils

    # Patch function
    rasax.community.utils.is_enterprise_installed = lambda: False

    username = "no enterprise user"
    password = "pw"
    team = "team1"
    role = TESTER
    user_service.create_user(username, password, team, role)

    assert not user_service.fetch_user(username)

    # Revert patch
    rasax.community.utils.is_enterprise_installed = lambda: True


def test_update_user_role(user_service: UserService, role_service: RoleService):
    test_user = "user whose role gets updated to admin"
    user_service.create_user(test_user, "password", config.team_name, TESTER)

    user_service.replace_user_roles(test_user, ADMIN)

    actual = user_service.fetch_user(test_user)

    assert actual["roles"] == [ADMIN]

    permissions = role_service.default_roles[ADMIN]
    expected = role_service.expand_wildcard_permissions(permissions)
    expected = _strip_category_from_permissions(expected)
    assert set(actual.get("permissions")) == set(expected)


def test_update_user_with_multiple_roles(user_service: UserService):
    test_user = "user whose role gets updated to multiple roles"
    user_service.create_user(test_user, "password", config.team_name, TESTER)

    user_service.replace_user_roles(test_user, [ADMIN, ANNOTATOR])

    actual = user_service.fetch_user(test_user)

    assert actual["roles"] == [ADMIN, ANNOTATOR]


def test_update_user_role_to_none(user_service: UserService):
    test_user = "user whose role gets updated to none"
    user_service.create_user(test_user, "password", config.team_name, TESTER)

    user_service.replace_user_roles(test_user, None)

    actual = user_service.fetch_user(test_user)

    assert not actual["roles"]
    assert actual.get("permissions") == []


def test_admin_user_removes_admin_role(user_service: UserService):
    test_user = "admin user who tries to remove their own role"
    # user has `admin` and `tester` roles
    user_service.create_user(test_user, "password", config.team_name, [ADMIN, TESTER])

    # `admin` role deletion should fail
    with pytest.raises(RoleException):
        user_service.delete_user_role(test_user, ADMIN, test_user)

    # role replacement without `admin` role should fail
    with pytest.raises(RoleException):
        user_service.replace_user_roles(test_user, [ANNOTATOR], test_user)

    # role replacement with `admin` role works
    user_service.replace_user_roles(test_user, [ADMIN, ANNOTATOR], test_user)


def test_insert_or_update(user_service: UserService):
    test_user = "user who gets inserted using 'insert_or_update'"
    user_service.insert_or_update_user(test_user, "password", config.team_name)

    actual = user_service.fetch_user(test_user)
    assert actual

    updated_password = "updated password"
    user_service.insert_or_update_user(test_user, updated_password, config.team_name)

    assert user_service.login(test_user, updated_password)


def test_delete_user_role(user_service: UserService):
    test_user = "user whose role gets deleted"
    user_service.create_user(test_user, "password", config.team_name, TESTER)

    user_service.delete_user_role(test_user, TESTER)

    actual = user_service.fetch_user(test_user)

    assert not actual["roles"]
    assert actual.get("permissions") == []


def test_add_multiple_roles(user_service):
    test_user = "user with multiple roles"
    user_service.create_user(test_user, "password", config.team_name, TESTER)

    user_service.add_role_to_user(test_user, ADMIN)

    actual = user_service.fetch_user(test_user)

    expected_roles = {TESTER, ADMIN}

    assert set(actual["roles"]) == expected_roles
    assert set(actual["projects"][0]["roles"]) == expected_roles


def test_deletion_of_role(user_service, role_service):
    test_user = "user whose role is deleted"
    user_service.create_user(test_user, "password", config.team_name, TESTER)

    role_service.delete_role(TESTER)
    actual = user_service.fetch_user(test_user)

    assert not actual["roles"]
    assert actual.get("permissions") == []


def test_user_has_role(user_service):
    name_id = "user who has role admin"
    user_service.create_user(name_id, "password", config.team_name, ADMIN)

    actual = user_service.fetch_user(name_id)

    assert has_role(actual, ADMIN)
    assert not has_role(actual, "user")


def test_create_saml_user(user_service):
    test_user = "some saml user"
    user_service.create_saml_user(test_user, dict(), config.team_name, ADMIN)

    actual = user_service.fetch_saml_user(test_user)

    # SAML user should not have single_use_token at this stage
    assert not actual.get("single_use_token")

    assert has_role(actual, ADMIN)
    assert not has_role(actual, "user")
    assert actual["name_id"] == test_user

    # udpate SAML username
    new_username = "new_username"
    user_service.update_saml_username(test_user, new_username)
    actual = user_service.fetch_saml_user(test_user)
    assert actual["username"] == new_username
    assert has_role(actual, ADMIN)
    assert actual["name_id"] == test_user

    # user can be found by new username
    assert user_service.fetch_user(new_username)

    # cannot re-assign username
    test_user = "another saml user"
    user_service.create_saml_user(test_user, dict(), config.team_name, ADMIN)
    with pytest.raises(UserException):
        user_service.update_saml_username(test_user, new_username)


def test_single_use_token(user_service):
    # create SAML user
    name_id = "yet another saml user"
    user_service.create_saml_user(name_id, dict(), config.team_name, ADMIN)

    # assign single-use token with lifetime of 1 second
    token = "some_token_342349i2394"
    user_service.update_single_use_token(name_id, token, 1)

    # SAML user now has token
    user = user_service.fetch_saml_user(name_id)
    initial_expires = user["single_use_token_expires"]
    assert user["single_use_token"] == token

    # log in using single-use token successful
    login = user_service.single_use_token_login(token)
    assert login
    assert login["name_id"] == name_id

    # update token to new expiration in 0.001 s
    user_service.update_single_use_token(name_id, token, 0.01)
    user = user_service.fetch_saml_user(name_id)
    new_expires = user["single_use_token_expires"]
    assert new_expires != initial_expires

    # login unsuccessful after token expiration
    time.sleep(0.1)
    login = user_service.single_use_token_login(token)
    assert not login


def test_fetch_users_with_role_query(user_service):
    # admin user query
    admin_users = user_service.fetch_all_users(config.team_name, role_query=ADMIN)
    for user in admin_users:
        assert ADMIN in user["roles"]

    # annotator or tester query
    annotator_tester_users = user_service.fetch_all_users(
        config.team_name, role_query="annotator,tester"
    )
    for user in annotator_tester_users:
        assert any(role in user["roles"] for role in [ANNOTATOR, TESTER])


def test_fetch_users_with_username_query(user_service):
    # create two new users
    username_1 = "random_name123123"
    username_2 = "another_random_name999"
    user_service.create_user(username_1, "password", config.team_name, ADMIN)
    user_service.create_user(username_2, "password", config.team_name, ADMIN)

    username_queried_users = user_service.fetch_all_users(
        config.team_name, username_query=username_1
    )
    assert len(username_queried_users) == 1
    assert username_queried_users[0]["username"] == username_1
