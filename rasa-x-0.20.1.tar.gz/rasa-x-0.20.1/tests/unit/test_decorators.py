from collections import namedtuple

from sanic.response import HTTPResponse

from rasax.community.api.decorators import validate_schema


async def test_schema_validation():
    @validate_schema("login")
    async def some_function(request):
        return True

    FakeRequest = namedtuple("Request", ["json"])
    fake_request = FakeRequest({"username": "dasdas", "password": "dasd"})

    assert await some_function(fake_request) is True


async def test_failing_schema_validation():
    @validate_schema("login")
    async def some_function(request):
        return True

    FakeRequest = namedtuple("Request", ["json"])
    fake_request = FakeRequest({"dasdas": "dasd"})

    actual = await some_function(fake_request)  # type: HTTPResponse

    assert actual.status == 400
