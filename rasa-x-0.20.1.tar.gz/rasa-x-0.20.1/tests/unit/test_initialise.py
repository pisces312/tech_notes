from unittest.mock import Mock

from sqlalchemy.orm import Session

from rasax.community import initialise, config
from rasax.community.services.settings_service import SettingsService
from rasax.community.services.user_service import UserService


def test_create_community_user(
    settings_service: SettingsService, session: Session, user_service: UserService
):
    from rasax.community.constants import COMMUNITY_USERNAME

    # Change this to `False` for the test to make sure our test password is used
    config.LOCAL_MODE = False

    test_password = "test password"
    settings_service.save_local_password(test_password)

    initialise.create_community_user(session, Mock())

    actual = user_service._fetch_user(COMMUNITY_USERNAME)

    assert actual is not None
    assert actual.password_hash == user_service.hash_pw(test_password)

    # Change it back
    config.LOCAL_MODE = True
