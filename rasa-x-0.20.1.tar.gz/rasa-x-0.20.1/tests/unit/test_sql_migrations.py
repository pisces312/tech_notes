from sqlalchemy.orm import Session

import rasax.community.sql_migrations as migrations
from rasax.community import config, utils
from rasax.community.services.role_service import RoleService
from rasax.community.services.user_service import UserService, ANNOTATOR, ADMIN, TESTER


def test_permission_migration(session: Session, role_service: RoleService):
    new_permission = "advanced.modify.projects.create"
    roles_to_migrate = [ADMIN, ANNOTATOR]

    migrations._migrate_new_permission(session, new_permission, roles_to_migrate)

    for role in roles_to_migrate:
        assert new_permission in role_service.get_role_permissions(role)

    other_roles = [TESTER]
    for role in other_roles:
        assert new_permission not in role_service.get_role_permissions(role)


def test_system_user_exists(session: Session, user_service: UserService):
    # system user should already exist
    assert user_service.fetch_user(config.SYSTEM_USER)

    # delete system user
    existing_user = user_service._fetch_user(config.SYSTEM_USER)
    session.delete(existing_user)
    session.commit()
    assert not user_service.fetch_user(config.SYSTEM_USER)

    # test system user creation
    migrations._create_system_user(session)
    assert user_service.fetch_user(config.SYSTEM_USER)


def test_system_user_creation_community_edition(
    session: Session, user_service: UserService
):
    # delete system user
    existing_user = user_service._fetch_user(config.SYSTEM_USER)
    session.delete(existing_user)
    session.commit()
    assert not user_service.fetch_user(config.SYSTEM_USER)

    # set context to CE
    utils.is_enterprise_installed = lambda: False

    # test system user creation
    migrations._create_system_user(session)
    assert user_service.fetch_user(config.SYSTEM_USER)

    # set context back to EE
    utils.is_enterprise_installed = lambda: True
