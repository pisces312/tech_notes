import pytest
import sqlalchemy.dialects
import sqlalchemy.exc
from sqlalchemy.orm import Session

import rasax.community.database.utils as db_utils
from rasax.community.database import Role
from rasax.community import utils
from tests.unit import conftest
from tests.unit.conftest import insert_test_user


# Overwrite fixture to run per function
@pytest.fixture()
def session():
    return next(conftest.session())


def test_query_result_to_dict():
    query_result = ["zero", "one", "two", "three"]
    fields_query = [("d", True), ("a.c", True), ("a.b", True), ("b.c.d", True)]

    actual = utils.query_result_to_dict(query_result, fields_query)

    assert actual["d"] == query_result[0]
    assert actual["a"]["c"] == query_result[1]
    assert actual["a"]["b"] == query_result[2]
    assert actual["b"]["c"]["d"] == query_result[3]


def test_foreign_keys_constraints(session: Session):
    insert_test_user(session, "some user")

    db_connection = session.connection()
    raw_connection = db_connection.connection.connection

    db_utils.enforce_sqlite_foreign_key_constraints(raw_connection, True)
    with pytest.raises(sqlalchemy.exc.IntegrityError):
        db_connection.execute("DROP table {};".format(Role.__tablename__))


def test_turn_off_foreign_keys_constraints(session: Session):
    insert_test_user(session, "some user")

    db_connection = session.connection()
    raw_connection = db_connection.connection.connection

    db_utils.enforce_sqlite_foreign_key_constraints(raw_connection, False)
    if isinstance(db_connection.dialect, sqlalchemy.dialects.sqlite.dialect):
        db_connection.execute("DROP table {};".format(Role.__tablename__))


def test_turn_off_then_on_foreign_key_constraints(session: Session):
    insert_test_user(session, "some user")

    db_connection = session.connection()
    raw_connection = db_connection.connection.connection

    db_utils.enforce_sqlite_foreign_key_constraints(raw_connection, False)
    db_utils.enforce_sqlite_foreign_key_constraints(raw_connection, True)

    with pytest.raises(sqlalchemy.exc.IntegrityError):
        db_connection.execute("DROP table {};".format(Role.__tablename__))


@pytest.mark.parametrize(
    "before_truncation, expected",
    [(1.0, 1.0), (1.1234, 1.12), (19231231.00, 19231231.00)],
)
def test_truncate_float(before_truncation: float, expected: float):
    assert utils.truncate_float(before_truncation, decimal_places=2) == expected


def test_verify_bearer_token():
    payload = {"test": "test"}
    encoded = utils.bearer_token(payload)

    assert utils.verify_bearer_token(encoded) == payload


@pytest.mark.parametrize(
    "token",
    [
        utils.bearer_token({}, jwt_secret="wrong secret"),
        utils.encode_jwt_token({}),
        "Other prefix " + utils.encode_jwt_token({}),
    ],
)
def test_invalid_bearer_tokens(token):
    with pytest.raises(ValueError):
        utils.verify_bearer_token(token)
